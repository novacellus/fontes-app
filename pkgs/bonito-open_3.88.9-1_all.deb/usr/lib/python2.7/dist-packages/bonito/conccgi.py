# Copyright (c) 2003-2016  Pavel Rychly, Vojtech Kovar, Milos Jakubicek, Milos Husak, Vit Baisa

from usercgi import UserCGI
import corplib, conclib, version
from corplib import corpconf_pairs
import os, re
import sys
import time
import glob
import locale
from types import ListType
from butils import *

def onelevelcrit (prefix, attr, ctx, pos, fcode, icase, bward='', empty=''):
    fromcode = {'lc': '<0', 'rc': '>0', 'kl': '<0', 'kr': '>0'}
    attrpart = '%s%s/%s%s%s ' % (prefix, attr, icase, bward, empty)
    if not ctx:
        ctx = '%i%s' % (pos, fromcode.get (fcode, '0'))
    if '~' in ctx and '.' in attr:
        ctx = ctx.split('~')[0]
    return attrpart + ctx

def nicearg(arg):
    args = arg.split('"');
    niceargs = []
    niceargsset = set()
    for i in range(len(args)):
        if (i % 2):
            tmparg = args[i].strip('\\').replace('(?i)', '')
            if tmparg not in niceargsset:
                niceargs.append(tmparg)
                niceargsset.add(tmparg)
        else:
            if args[i].startswith('within'):
                niceargs.append('within')
    return ', '.join(niceargs)

class ConcError (Exception):
    def __init__ (self, msg):
        self.message = msg


class ConcCGI (UserCGI):

    _global_vars = ['corpname', 'viewmode', 'attrs', 'attr_allpos', 'ctxattrs',
                    'structs', 'refs', 'lemma', 'lpos', 'pagesize',
                    'usesubcorp', 'align', 'copy_icon', 'gdex_enabled',
                    'gdexcnt', 'gdexconf', 'show_gdex_scores', 'iquery',
                    'maincorp', 'complement_subc', 'attr_tooltip']
    error = u''
    fc_lemword_window_type = u'both'
    fc_lemword_type = u'all'
    fc_lemword_wsize=5,
    fc_lemword=u'',
    fc_pos_window_type = u'both'
    fc_pos_type = u'all'
    fc_pos_wsize=5,
    fc_pos=[],
    ml = 0
    concarf = u''
    Aligned = []
    prevlink = u''
    nextlink = u''
    concsize = u''
    samplesize = 10000000 #10M
    Lines = []
    fromp = u'1'
    fromc = u''
    numofpages = u''
    pnfilter = u'p'
    filfl = u'f'
    filfpos = u'-5'
    filtpos = u'5'
    sicase = u''
    sbward = u''
    ml1icase = u''
    ml2icase = u''
    ml3icase = u''
    ml4icase = u''
    ml1bward = u''
    ml2bward = u''
    ml3bward = u''
    freq_sort = u''
    heading = 0
    saveformat = u'text'
    wlattr = u''
    wlpat = u''
    wlpage = 1
    wlcache = u''
    blcache = u''
    simple_n = 1
    usearf = 0
    collpage = 1
    fpage = 1
    fmaxitems = 50
    ftt_include_empty = u''
    subcsize = 0
    processing = 0 
    ref_usesubcorp = u''
    wlsort = u''
    keywords = u''
    Keywords = []
    ref_corpname = u''
    Items = []
    format = u''
    selected = u''
    saved_attrs = 0
                     # save options
    pages = 0
    leftctx = u''
    rightctx = u''
    numbering = 0
    align_kwic = 0
    righttoleft = False
    stored = u''
    # end

    add_vars = {}
    corpname = u'susanne'
    corplist = [u'susanne', u'bnc']
    compatible_corpora = None
    tagset_compatible_corpora = None
    usesubcorp = u''
    obsolete_subcorp = ''
    obsolete_has_subcdef = False
    subcname = u''
    subcpath = []
    _conc_dir = u''
    _home_url = u'../index.html'
    files_path = u'..'
    css_prefix = u''
    logo_prefix = u''
    iquery = u''
    queryselector = u'iqueryrow'
    lemma = u''
    lpos = u''
    phrase = u''
    char = u''
    word = u''
    wpos = u''
    cql = u''
    default_attr = None
    save = 1
    async = 1
    spos = 3
    skey = u'rc'
    qmcase = 0
    rlines = u'250'
    attrs = u'word'
    ctxattrs = u'word'
    attr_allpos = u'kw'
    allpos = u'kw'
    attr_tooltip = 'nott'
    structs = u'p,g,err,corr'
    q = []
    pagesize = 20
    gdexconf = u''
    gdexpath = [] # [('confname', '/path/to/gdex.conf'), ...]
    gdexcnt = 100
    gdex_enabled = 0
    show_gdex_scores = 0
    alt_gdexconf = None
    copy_icon = 0
    _avail_tbl_templates = u''
    multiple_copy = 0
    use_noflash = 0
    select_lines = 0
    line_numbers = 0
    show_permalink = 1
    wlsendmail = u''
    cup_hl = u'q'

    sortlevel=1
    flimit = 0
    freqlevel=1
    ml1pos = 1
    ml2pos = 1
    ml3pos = 1
    ml4pos = 1
    ml1ctx = u'0~0>0'
    ml2ctx = u'0~0>0'
    ml3ctx = u'0~0>0'
    ml4ctx = u'0~0>0'
    tbl_template = u'none'
    errcodes_link = u''
    hidenone = 1
    shorten_refs = 0
    err_types_select = False
    helpsite = u'https://www.sketchengine.co.uk/'
    user_guide_url = u'https://www.sketchengine.co.uk/documentation'
    _majorversionerr = []
    _minorversionerr = []
    registry = ''

    # annotations
    can_annotate = 0
    enable_sadd = 0
    annotconc = u''
    annotconc_init_labels = (u'x', u'u')
    annotconc_num_label_suffixes = (u'.a',u'.f',u'.a')
    #annotconc_info_umask = 022
    annotconc_info_umask = 0111  #XXX renumbering from CPA editor
    alpha_features = 0

    # trends
    trends_re = ''
    trends_maxp = 0.01
    trends_method = 'mkts_all'
    trends_sort_by = 't'
    trends_minfreq = 5
    trends_attr = 'word'
    filter_nonwords = 1
    filter_capitalized = 1

    add_vars['wsketch_form'] = [u'LastSubcorp', u'auto_pos']
    add_vars['wsketch'] = [u'LastSubcorp']
    add_vars['wsdiff'] = [u'LastSubcorp']
    add_vars['thes'] = [u'auto_pos']
    add_vars['save_ws_options'] = [u'LastSubcorp']
    add_vars['save_wsdiff_options'] = [u'LastSubcorp']
    add_vars['findx_upload'] = [u'LastSubcorp']
    
    def __init__ (self):
        self.cm = corplib.CorpusManager (self.corplist, self.subcpath, 
                                         self.gdexpath, self._job,
                                         abs_corpname=self.abs_corpname)
        self._curr_corpus = None
        if self._request_method == 'POST':
            self.show_permalink = 0

    def abs_corpname(self, corpname):
        return corpname

    def preprocess_values(self, form):
        cn, rcn, usr, api_key = '', '', '', ''
        if form.has_key ('json'):
            import simplejson
            jsondata = simplejson.loads(form.getvalue('json'))
            cn = str(jsondata.get('corpname', ''))
            rcn = str(jsondata.get('ref_corpname', ''))
#            usr = str(jsondata.get('username', '')) # username only in CGI
            api_key = str(jsondata.get('api_key', ''))
        if form.has_key('corpname') and not cn:
            cn = form.getvalue('corpname')
        if form.has_key('ref_corpname') and not rcn:
            rcn = form.getvalue('ref_corpname')
        if form.has_key('api_key') and not api_key:
            api_key = form.getvalue('api_key')
        if form.has_key('username') and not usr:
            usr = form.getvalue('username')
        if cn:
            if isinstance(cn, ListType):
                cn = cn[-1]
            self.corpname = cn
        if rcn: self.ref_corpname = rcn
        self.api_key = api_key
        self.url_username = usr

    def self_encoding(self):
        enc = self._corp().get_conf('ENCODING')
        if enc:
            return enc
        else:
            return 'iso-8859-1'

    def _corp (self):
        if (not self._curr_corpus or
            (self.usesubcorp and not hasattr(self._curr_corpus, 'subcname'))):
            self._curr_corpus = self.cm.get_Corpus (self.corpname,
                                         self.usesubcorp, self.complement_subc)
            if self.cm.obsolete_subcorp:
                self.obsolete_subcorp = self.cm.obsolete_subcorp
                self.obsolete_has_subcdef = self.cm.obsolete_has_subcdef
            if self.cm.missing_subc_error:
                self.usesubcorp = ''
                self.exceptmethod = 'first_form'
                raise RuntimeError(self.cm.missing_subc_error)
            # XXX opravit poradne!
            self._curr_corpus._conc_dir = self._conc_dir
        return self._curr_corpus

    def _set_defaults (self):
        if not self.__dict__.has_key('refs'):
            if self._corp().get_conf('SHORTREF'):
                self.refs = self._corp().get_conf('SHORTREF')
            else:
                sal = self._corp().get_conf('STRUCTATTRLIST').split(',')
                docs = self._corp().get_conf('DOCSTRUCTURE')
                if docs + '.urldomain' in sal:
                    self.refs = '=' + docs + '.urldomain'
                else:
                    self.refs = '#'

    def _correct_parameters (self):
        if self.annotconc.startswith('--NONE--'):
            if self._annotconc_locked(self.annotconc[8:]):
                if self._user == self._annotconc_locked(self.annotconc[8:]):
                    self._annotconc_unlock(self.annotconc[8:])
            self._cookieattrs.append ('annotconc')
            self.annotconc = ''
    
    def _add_globals (self, result):
        UserCGI._add_globals (self, result)

        if self.maincorp: thecorp = conclib.manatee.Corpus(self.maincorp)
        else: thecorp = self._corp()
        result['q'] = self.urlencode ([('q', q) for q in self.q])
        result['Q'] = [{'q': q} for q in self.q]
        result['corpname_url'] = 'corpname=' + self.corpname
        global_var_val = [(n,val) for n in self._global_vars
                          for val in [getattr (self,n)]
                          if getattr (self.__class__, n, None) is not val]
        result['uilang'] = self.uilang or self.get_uilang()
        result['globals'] = self.urlencode (global_var_val)
        result['Globals'] = [{'name':n,'value':v} for n,v in global_var_val]
        result['has_wsketch'] = (getattr (self, 'wsketch', '')
                                 and thecorp.get_conf('WSDEF')
                                 and thecorp.get_conf('WSBASE') != 'none')
        result['has_diacran'] = thecorp.get_conf('DIACHRONIC')
        result['struct_ctx'] = thecorp.get_conf('STRUCTCTX')
        result['can_wseval'] = getattr(self, '_can_wseval', '')
        result['corp_doc'] = thecorp.get_conf('DOCUMENTATION')
        result['Corplist'] = self.cm.corplist_with_names()
        result['corplist_size'] = min (len(result['Corplist']), 20)
        if not 'corp_full_name' in result:
            result['corp_full_name'] = thecorp.get_conf('NAME') or self.corpname
        attrlist = thecorp.get_conf('ATTRLIST').split(',')
        sref = thecorp.get_conf('SHORTREF')
        result['fcrit_shortref'] = '+'.join([a.strip('=') + '+0'
                                                for a in sref.split(',')])
        result['corpencoding'] = thecorp.get_conf('ENCODING')
        result['_version'] = '%s-%s' % (conclib.manatee.version(),
                                        version.version)
        result['_bonito_version'] = version.version
        manatee_version = conclib.manatee.version().split("-")[-1]
        req_versions = version.manatee_minversion.split(".")
        versions = manatee_version.split(".")
        api = req_api = 2
        if len(versions) == 4:
            api = ".".join(versions[:2])
            versions.pop(0)
        if len(req_versions) == 4:
            req_api = ".".join(req_versions[:2])
            req_versions.pop(0)
        if api != req_api:
            result['_majorversionerr'] = [req_api, manatee_version]
        elif int(re.search(r'\d+', req_versions[1]).group()) > \
             int(re.search(r'\d+', versions[1]).group()):
            result['_minorversionerr'] = [version.manatee_minversion,
                                          manatee_version]
        poslist = corpconf_pairs (thecorp, 'WPOSLIST')
        result['Wposlist'] = [{'n':x[0], 'v':x[1]} for x in poslist]
        poslist = corpconf_pairs (thecorp, 'LPOSLIST')
        if 'lempos' not in attrlist:
            poslist = corpconf_pairs (thecorp, 'WPOSLIST')
        result['Lposlist'] = [{'n':x[0], 'v':x[1]} for x in poslist]
        result['lpos_dict'] = dict([(y, x) for x, y in poslist])
        poslist = corpconf_pairs (thecorp, 'WSPOSLIST')
        result['WSposlist'] = [{'n':x[0], 'v':x[1]} for x in poslist]
        result['has_lemmaattr'] = 'lempos' in attrlist \
                                  or 'lemma' in attrlist
        if not self.default_attr:
            result['default_attr'] = thecorp.get_conf('DEFAULTATTR')
        for listname in ['AttrList', 'StructAttrList']:
            if listname in result: continue
            result [listname] = \
                   [{'label': thecorp.get_conf (n+'.LABEL') or n, 'n': n}
                    for n in thecorp.get_conf (listname.upper()).split(',')
                    if n]
        result['tagsetdoc'] = thecorp.get_conf('TAGSETDOC')
        result['def_filter_link'] = thecorp.get_conf('DEFFILTERLINK')
        ttcrit_attrs = thecorp.get_conf ('FREQTTATTRS') \
                       or thecorp.get_conf ('SUBCORPATTRS').replace('|',',')
        result['ttcrit'] = self.urlencode ([('fcrit', '%s 0' % a)
                                        for a in ttcrit_attrs.split(',') if a])
        if self.annotconc and not result.has_key('GroupNumbers'):
            try:
                labelmap = conclib.get_conc_labelmap(self._storeconc_path()
                        + '.info')
                result['GroupNumbers'] = conclib.format_labelmap(labelmap)
            except IOError, e:
                self._cookieattrs.append('annotconc')
                self.annotconc = ''
        result['commonurl'] = self.urlencode([ ('corpname', self.corpname),
                                               ('lemma', self.lemma),
                                               ('lpos', self.lpos),
                                               ('usesubcorp', self.usesubcorp),
                                             ])
        try:
            doc = self._corp().get_conf("DOCSTRUCTURE")
            self._corp().get_struct(doc)
            result['doc_struct'] = doc
        except:
            result['doc_struct'] = ''
        return result


    def add_undefined (self, result, methodname):
        UserCGI.add_undefined (self, result, methodname)
        result['methodname'] = methodname
        if self.add_vars.has_key (methodname):
            names = self.add_vars[methodname]
        else:
            return

        if 'Desc' in names:
            csize = self._corp().search_size()
            result['Desc'] = [{'op': o, 'arg': a, 'size': s}
                              for o, a, u1, u2, s, f, da in
                              conclib.get_conc_desc (self.q,
                                                     corpname=self.corpname,
                                                     _cache_dir=self._cache_dir,
                                                     subchash=getattr(self._corp(), "subchash", None))]

        if 'TextTypeSel' in names:
            result['TextTypeSel'] = self.texttypes_with_norms(ret_nums=False)
        if 'auto_pos' in names:
            result['auto_pos'] = self.has_auto_pos()
        if 'LastSubcorp' in names:
            result['LastSubcorp'] = self.cm.subcorp_names (self.corpname)
            result['lastSubcorpSize'] = min(len(result['LastSubcorp']) +1, 20)

        if 'orig_query' in names:
           conc_desc = conclib.get_conc_desc (self.q,
                       corpname=self.corpname,
                       _cache_dir=self._cache_dir,
                       subchash=getattr(self._corp(), "subchash", None))
           if len(conc_desc) > 1:
               result['tourl'] = self.urlencode(conc_desc[0][3])
        if methodname.startswith('first'):
            result['show_cup_menu'] = self.is_err_corpus()

    kwicleftctx = '40#'
    kwicrightctx = '40#'
    senleftctx = '-1:s'
    senrightctx = '1:s'
    viewmode = 'kwic'
    align = ''
    sel_aligned = []
    maincorp = ''
    refs_up = 0

    def simple_search (self):
        "simple search result -- all in one"
            # concordance lines
        corp = self._corp()
        conclines = 11 # setable?
        self.viewmode = 'sen'
        self.structs = 'g'
        self.pagesize = conclines
        self.gdex_enabled = 1
        self.gdexcnt = conclines
        self.exceptmethod = "first_form"
        result = self.first()
            # frequencies
        fattrs = []
        subcorpattrs = corp.get_conf ('SUBCORPATTRS') \
                               or corp.get_conf ('FULLREF')
        if subcorpattrs != '#':
            fattrs.extend(subcorpattrs.replace('|',',').split(','))
        wsattr = corp.get_conf ('WSATTR')
        fattrs.append(wsattr)
        fcrits = ['%s 0' % a for a in fattrs]
        self.q.append('r1000') # speeds-up computing frequency
        result['freqs'] = self.freqs(fcrit=fcrits, ml=1)
        for block in result['freqs']['Blocks']:
            block['Items'] = block['Items'][:10]
            #sketches
        self.numoflines = 10
        result ['Sketches'] = []
        if fattrs and fattrs[-1] in ('lemma', 'lempos'):
            try:
                self.gr = ' ' # all relations
                lemma = result['freqs']['Blocks'][-1]['Items'][0]\
                              ['Word'][0]['n'] # most frequent lemma (lempos)
                if wsattr == 'lempos':
                    self.lemma = lemma[:-2]
                    self.lpos = lemma[-2:]
                result['Sketches'] = self.wsketch(lemma=self.lemma,
                                         lpos=self.lpos, structured=0)['Items']
            except:
                result ['Sketches'] = []
        return result
    
    def view (self):
        "kwic view"
        self._cookieattrs.append ('viewmode')
        if self._corp().get_conf('RIGHTTOLEFT') == '1':
            self.righttoleft = True
        if self.viewmode == 'kwic':
            self.leftctx = self.kwicleftctx
            self.rightctx = self.kwicrightctx
        elif self.viewmode == 'align' and self.align:
            self.leftctx = 'a,%s' % os.path.basename(self.corpname)
            self.rightctx = 'a,%s' % os.path.basename(self.corpname)
        else:
            self.leftctx = self.senleftctx
            self.rightctx = self.senrightctx
        # GDEX changing and turning on and off
        if self.gdex_enabled and self.gdexcnt:
            gdex_set = 0
            for i in range(1,len(self.q)):
                if self.q[i][0] == 'e':
                    self.q[i] = 'e%s %s' % (str(self.gdexcnt), self.gdexconf)
                    gdex_set = 1
            if not gdex_set:
                self.q.append('e%s %s' % (str(self.gdexcnt), self.gdexconf))
        else:
            i = 0
            while i < len(self.q):
                if self.q[i].startswith('s*') or self.q[i][0] == 'e':
                    del self.q[i]
                i += 1

        if self.show_gdex_scores:
            self.save = 0
        conc = self.call_function (conclib.get_conc, (self._corp(),))
        if not conc.size():
            if self.exceptmethod == 'PREV-CONC':
                conc = self.call_function (conclib.get_conc, (self._corp(),),
                                                             q=self.q[:-1])
                self.error = 'Nothing found'
            else:
                raise ConcError (_('Empty result'))
        conc.switch_aligned (os.path.basename(self.corpname))
        labelmap = {}
        if self.annotconc:
            if self._selectstored (self.annotconc):
                anot = self._get_annotconc()
                conc.set_linegroup_from_conc (anot)
                labelmap = anot.labelmap
            elif self.can_annotate:
                self.storeconc (self.annotconc)
                labelmap = conclib.get_conc_labelmap (self._storeconc_path()
                                                      + '.info')
            else:
                self._cookieattrs.append ('annotconc')
                self.annotconc = ''
        out = self.call_function(conclib.kwicpage, (conc,), labelmap=labelmap,
                                 pagesize=min(self.pagesize, 1000),
                                 alignlist=[self.cm.get_Corpus(c)
                                           for c in self.align.split(',') if c],
                                 copy_icon=self.copy_icon,
                                 tbl_template=self.tbl_template)
        out['Sort_idx'] = self.call_function (conclib.get_sort_idx, (conc,),
                                                      enc=self.self_encoding())
        if self.annotconc:
            self.annotverb = self.annotconc.split('-')[0]
            lglist = []
            for lg in self.lngroupinfo(self.annotconc)['LineGroups']:
                if lg['freq'] > 0:
                    if lg['name'] == 'Not assigned':
                        lglist.append('_')
                    else:
                        lglist.append(lg['name'])
            out['PosLineGroups'] = lglist
        # get sizes
        out.update({'concsize': not self.error and conc.size() or 0,
                    'finished': int(conc.finished()),
                    'fullsize': conc.fullsize(),
                    'relsize': round(float(1000000.0 * conc.fullsize() / conc.corp().search_size()))})
        if self._corp().get_conf ('ALIGNED'):
            out['Aligned'] = [{'n': w,
                               'label': conclib.manatee.Corpus(w).get_conf(
                                                                  'NAME') or w }
                         for w in self._corp().get_conf ('ALIGNED').split(',')]
        if self.align and not self.maincorp:
            self.maincorp = os.path.basename(self.corpname)
        csize = self._corp().search_size()
        out['Desc'] = []
        for o,a,u1,u2,s,f,da in conclib.get_conc_desc (self.q,
                             corpname=self.corpname, _cache_dir=self._cache_dir,
                             subchash=getattr(self._corp(), "subchash", None)):
            rel = ''
            if s != '':
                if float(s) != float(-1):
                    rel = round(float(s) * 1000000.0 / csize, 2)
                else:
                    rel = round(1000000.0 * conc.fullsize() / csize, 2)
            out['Desc'].append({'op': o, 'arg': a, 'nicearg': nicearg(a),
                                'rel': rel, 'size': s,
                                'tourl': self.urlencode(u2)})
        out['port'] = conc.port
        out['gdex_scores'] = conc.gdex_scores
        out['sc_strcts'] = [(st, self._corp().get_conf(st + '.LABEL') or st)
                for st in self._corp().get_conf('STRUCTLIST').split(',') if st]
        return out
    add_vars['view'] = ['orig_query']

    def first_form(self):
        out = {}
        if self._corp().get_conf ('ALIGNED'):
            out['Aligned'] = []
            for al in self._corp().get_conf ('ALIGNED').split(','):
                alcorp = conclib.manatee.Corpus(al)
                out['Aligned'].append({'label': alcorp.get_conf('NAME') or al,
                                       'n': al})
                attrlist = alcorp.get_conf('ATTRLIST').split(',')
                poslist = corpconf_pairs (alcorp, 'WPOSLIST')
                out['Wposlist_'+al] = [{'n':x[0], 'v':x[1]} for x in poslist]
                if 'lempos' in attrlist:
                    poslist = corpconf_pairs (alcorp, 'LPOSLIST')
                out['Lposlist_'+al] = [{'n':x[0], 'v':x[1]} for x in poslist]
                out['has_lemmaattr_'+al] = 'lempos' in attrlist \
                                           or 'lemma' in attrlist
                out['has_case_'+al] = alcorp.get_conf('NOLETTERCASE') != '1'
            out['Aligned'].sort(key=lambda x: x['label'])
        out['has_case'] = self._corp().get_conf('NOLETTERCASE') != '1'
        if self.is_err_corpus():
            out['err_types'] = self.struct_attr_values('err', 'type')
            out['corr_types'] = self.struct_attr_values('corr', 'type')
        return out
    add_vars['first_form'] = ['TextTypeSel', 'LastSubcorp']

    def struct_attr_values(self, struct, attr):
        try:
            a = self._corp().get_struct(struct).get_attr(attr)
            return sorted([a.id2str(i) for i in range(a.id_range()) if a.freq(i) > 0])
        except:
            return []

    def get_conc_sizes (self, q=[], port=0):
        self._headers['Content-Type']= 'text/plain'
        cs = self.call_function (conclib.get_conc_sizes, (self._corp(),),
                                 q=q or self.q, server_port=port)
        return "\n".join(map(str,[cs["finished"], cs["concsize"],
                                  cs["relconcsize"], cs["fullsize"]]))

    def concdesc (self):
        return {'Desc': [{'op': o, 'arg': a, 'churl': self.urlencode(u1), 'da': da,
                          'tourl': self.urlencode(u2), 'size': s, 'formname': f}
                         for o, a, u1, u2, s, f, da in
                         conclib.get_conc_desc (self.q,
                                                corpname=self.corpname,
                                                _cache_dir=self._cache_dir,
                                                subchash=getattr(self._corp(),
                                                             "subchash", None))]
                }
        
    def viewattrs (self):
        "attrs, refs, structs form"
        out = {}
        if self.maincorp:
            corp = corplib.manatee.Corpus(self.maincorp)
            out['AttrList'] = [{'label': corp.get_conf (n+'.LABEL') or n, 'n':n}
                               for n in corp.get_conf ('ATTRLIST').split(',')
                               if n]
        else:
            corp = self._corp()
        availstruct = corp.get_conf('STRUCTLIST').split(',')
        structlist = self.structs.split(',')
        out['Availstructs'] = [{'n': n,
                                'sel': (((n in structlist)
                                             and 'selected') or ''),
                                'label': corp.get_conf (n+'.LABEL') } 
                                for n in availstruct if n and n != '#']
        
        availref = corp.get_conf('STRUCTATTRLIST').split(',')
        reflist = self.refs.split(',')
        out['Availrefs'] = [{'n': '#',  'label': _('Token number'), 'sel': 
                             ((('#' in reflist) and 'selected') or '')}] + \
                             [{'n': '=' + n,  'sel': 
                               ((('=' + n in reflist) and 'selected') or ''),
                               'label': (corp.get_conf (n+'.LABEL') or n)} 
                              for n in availref if n and n != '#']
        doc = corp.get_conf('DOCSTRUCTURE')
        if doc in availstruct:
            out['Availrefs'].insert(1, {'n': doc, 'label': _('Document number'),
                'sel': (doc in reflist and 'selected' or '')})
        out['newctxsize'] = self.kwicleftctx[:-1]
        out['Availgdexconfs'] = self.cm.gdexdict.keys()
        try:
            from tbl_settings import tbl_labels
            out['tbl_labels'] = tbl_labels
        except ImportError:
            out['tbl_labels'] = {}
        return out

    def set_new_viewattrs (self, setattrs=[], allpos='', setstructs=[],
                    setrefs=[], newctxsize='', gdexcnt=0, gdexconf='',
                    attr_tooltip='nott'):
        self.attrs = ','.join(setattrs) or 'word'
        self.structs = ','.join(setstructs)
        self.refs = ','.join(setrefs)
        self.attr_allpos = allpos
        self.attr_tooltip = attr_tooltip
        if allpos == 'all':
            self.ctxattrs = self.attrs
        else:
            self.ctxattrs = 'word'
        self.gdexcnt = gdexcnt
        self.gdexconf = gdexconf
        self._cookieattrs.extend (['attrs', 'ctxattrs', 'structs',
                                   'pagesize', 'copy_icon', 'multiple_copy',
                                   'gdex_enabled', 'gdexcnt', 'gdexconf',
                                   'show_gdex_scores', 'refs_up', 'select_lines',
                                   'use_noflash', 'line_numbers', 'shorten_refs',
                                   'attr_tooltip'])
        if newctxsize != self.kwicleftctx[:-1]:
            self.kwicleftctx = newctxsize + '#'
            self.kwicrightctx = newctxsize + '#'
            self._cookieattrs.extend (['kwicleftctx', 'kwicrightctx'])

    def viewattrsx (self, setattrs=[], allpos='', setstructs=[], setrefs=[],
                    newctxsize='', gdexcnt=0, gdexconf='', attr_tooltip='nott'):
        self.set_new_viewattrs(setattrs, allpos, setstructs,
                    setrefs, newctxsize, gdexcnt, gdexconf, attr_tooltip)
        if not self._anonymous:
            self._save_options(['attrs', 'ctxattrs', 'structs', 'pagesize',
                            'copy_icon', 'gdex_enabled', 'gdexcnt', 'gdexconf',
                            'show_gdex_scores', 'refs', 'refs_up', 'kwicleftctx',
                            'kwicrightctx', 'multiple_copy', 'tbl_template',
                            'select_lines', 'use_noflash', 'line_numbers',
                            'shorten_refs'],
                            self.corpname)
        return self.view()

    viewattrsx.template = 'view.tmpl'


    def sort (self):
        "sort concordance form"
        return {'Pos_ctxs': conclib.pos_ctxs(1,1)}

    def sortx (self, sattr='word', skey='rc', spos=3, sicase='', sbward=''):
        "simple sort concordance"
        if skey == 'lc':
            ctx = '-1<0~-%i<0' % spos
        elif skey == 'kw':
            ctx = '0<0~0>0'
        elif skey == 'rc':
            ctx = '1>0~%i>0' % spos
        if '.' in sattr:
            ctx = ctx.split('~')[0]
            
        self.q.append ('s%s/%s%s %s' % (sattr, sicase, sbward, ctx))
        return self.view()
    
    sortx.template = 'view.tmpl'

    def mlsortx (self,
          ml1attr='word', ml1pos=1, ml1icase='', ml1bward='', ml1fcode='rc',
          ml2attr='word', ml2pos=1, ml2icase='', ml2bward='', ml2fcode='rc',
          ml3attr='word', ml3pos=1, ml3icase='', ml3bward='', ml3fcode='rc',
          sortlevel=1, ml1ctx='', ml2ctx='', ml3ctx=''):
        "multiple level sort concordance"

        crit = onelevelcrit ('s', ml1attr, ml1ctx, ml1pos, ml1fcode,
                             ml1icase, ml1bward)
        if sortlevel > 1:
            crit += onelevelcrit (' ', ml2attr, ml2ctx, ml2pos, ml2fcode,
                                  ml2icase, ml2bward)
            if sortlevel > 2:
                crit += onelevelcrit (' ', ml3attr, ml3ctx, ml3pos, ml3fcode,
                                      ml3icase, ml3bward)
                                      
        self.q.append (crit)
        return self.view()

    mlsortx.template = 'view.tmpl'

    def is_err_corpus(self):
        availstruct = self._corp().get_conf('STRUCTLIST').split(',')
        if not ('err' in availstruct and 'corr' in availstruct):
            return False
        return True

    def _compile_basic_query (self, qtype=None, suff='', cname=''):
        queryselector = getattr(self, 'queryselector' + suff)
        iquery = ''
        if queryselector == 'iqueryrow':
            iquery = getattr(self, 'iquery' + suff, '').strip()
            if iquery == '\\':
                iquery = '\\\\'
            iquery = re.sub(r'\\([^.?\\*])', r'\1', iquery)
            iquery = iquery.replace('\\.', '\v')
            iquery = iquery.replace('.', '\\.').replace('\v', '\\.')
            iquery = iquery.replace('\\?', '\v').replace('?', '.')
            iquery = iquery.replace('\v', '?').replace('\\*', '\v')
            iquery = iquery.replace('*', '.*').replace('\v', '\\*')
        lemma = getattr(self, 'lemma' + suff, '')
        lpos = getattr(self, 'lpos' + suff, '')
        phrase = getattr(self, 'phrase' + suff, '')
        qmcase = getattr(self, 'qmcase' + suff, '')
        word = getattr(self, 'word' + suff, '')
        wpos = getattr(self, 'wpos' + suff, '')
        char = getattr(self, 'char' + suff, '')
        cql = getattr(self, 'cql' + suff, '')
        queries = {
            'cql': '%(cql)s',
            'lemma': '[lempos="%(lemma)s%(lpos)s"]',
            'wordform': '[%(wordattr)s="%(word)s" & tag="%(wpos)s.*"]',
            'wordformonly': '[%(wordattr)s="%(word)s"]',
            }
        for a in ('iquery', 'word', 'lemma', 'phrase', 'cql', 'char'):
            if queryselector == a + 'row':
                if getattr(self, a+suff, ''):
                    setattr (self, a+suff, getattr (self, a+suff).strip())
                elif suff:
                    return ''
                else:
                    raise ConcError (_('No query entered.'))
        if qtype:
            return queries[qtype] % self.clone_self()
        thecorp = cname and self.cm.get_Corpus (cname) or self._corp()
        attrlist = thecorp.get_conf('ATTRLIST').split(',')
        wposlist = dict (corpconf_pairs (thecorp, 'WPOSLIST'))
        lposlist = dict (corpconf_pairs (thecorp, 'LPOSLIST'))
        if queryselector == 'iqueryrow':
            qitem = thecorp.get_conf('SIMPLEQUERY').replace('%s', '%(q)s')
            if '--' not in iquery:
                return ''.join([qitem % {'q':escape_nonwild(q)}
                                for q in iquery.split()])
            else:
                def split_tridash (word, qitem):
                    if '--' not in word:
                          return qitem % {'q':word}
                    w1,w2 = word.split('--',1)
                    return "( %s | %s %s | %s )" % (qitem % {'q':w1+w2}, 
                                                    qitem % {'q':w1}, 
                                                    qitem % {'q':w2}, 
                                                    qitem % {'q':w1+'-'+w2})
                return ''.join([split_tridash(escape_nonwild(q), qitem)
                                for q in iquery.split()])

        if queryselector == 'lemmarow':
            if not lpos:
                return '[lemma="%s"]' % lemma
            if 'lempos' in attrlist:
                try:
                    if not lpos in lposlist.values():
                        lpos = lposlist [lpos]
                except KeyError:
                    raise ConcError (_('Undefined lemma PoS') + ' "%s"' % lpos)
                return '[lempos="(%s)%s"]' % (lemma, lpos)
            else: # XXX
                try:
                    if lpos in wposlist.values():
                        wpos = lpos
                    else:
                        wpos = wposlist [lpos]
                except KeyError:
                    raise ConcError (_('Undefined word form PoS')
                                                          + ' "%s"' % lpos)
                return '[lemma="%s" & tag="%s"]' % (lemma, wpos)
        if queryselector == 'phraserow':
            return '"' + '" "'.join (phrase.split()) + '"'
        if queryselector == 'wordrow':
            if qmcase:
                wordattr = 'word="%s"' % word
            else:
                if 'lc' in attrlist:
                    wordattr = 'lc="%s"' % word
                else:
                    wordattr = 'word="(?i)%s"' % word
            if not wpos:
                return '[%s]' % wordattr
            try:
                if not wpos in wposlist.values():
                    wpos = wposlist [wpos]
            except KeyError:
                raise ConcError (_('Undefined word form PoS') + ' "%s"' % wpos)
            return '[%s & tag="%s"]' % (wordattr, wpos)
        if queryselector == 'charrow':
            if not char: raise ConcError (_('No char entered'))
            return '[word=".*%s.*"]' % escape(char)
        return cql


    def _compile_query(self, qtype=None, cname=''):
        if not self.is_err_corpus():
            return self._compile_basic_query(qtype, cname=cname)
        self._cookieattrs.append ('cup_hl')
        err_code = getattr(self, 'cup_err_code', '')
        err = getattr(self, 'cup_err', '')
        corr = getattr(self, 'cup_corr', '')
        switch = getattr(self, 'errcorr_switch', '')
        if not err_code and not err and not corr:
            cql = self._compile_basic_query(qtype)
            if self.queryselector != 'cqlrow':
                cql = cql.replace('][', '] (<corr/>)? [')
                cql = cql.replace('](', '] (<corr/>)? (')
                cql = cql.replace('] [', '] (<corr/>)? [')
            return cql
        # compute error query
        # Achtung: Top error lists (method freq) depends on this -- do check it
        # when changing the below
        corr_restr = corr or (err_code and switch == 'c')
        err_restr = err or (err_code and switch == 'e')
        if err_code: corr_within = '<corr type="%s"/>' % err_code
        else: corr_within = '<corr/>'
        if err_code: err_within = '<err type="%s"/>' % err_code
        else: err_within = '<err/>'
        err_containing = ''; corr_containing = ''
        if err:
            self.iquery = err; self.queryselector = 'iqueryrow'
            err_containing = ' containing ' + self._compile_basic_query(qtype)
        if corr:
            self.iquery = corr; self.queryselector = 'iqueryrow'
            corr_containing = ' containing ' + self._compile_basic_query(qtype)
        err_query =  '(%s%s)' % (err_within, err_containing)
        corr_query = '(%s%s)' % (corr_within, corr_containing)
        fullstruct = '(%s%s)' % (err_query, corr_query)
        if self.cup_hl == 'e' or (self.cup_hl == 'q' and err_restr
                                                     and not corr_restr):
            return '%s within %s' % (err_query, fullstruct)
        elif self.cup_hl == 'c' or (self.cup_hl == 'q' and corr_restr
                                                       and not err_restr):
            return '%s within %s' % (corr_query, fullstruct)
        else: # highlight both
            return fullstruct


    def query (self, qtype='cql'):
        "perform query"
        if self.default_attr:
            qbase = 'a%s,' % self.default_attr 
        else:
            qbase = 'q'
        self.q = [qbase + self._compile_query()]
        return self.view()

    query.template = 'view.tmpl'


    def set_first_query (self, fc_lemword_window_type='',
                               fc_lemword_wsize=0,
                               fc_lemword_type='',
                               fc_lemword='',
                               fc_pos_window_type='',
                               fc_pos_wsize=0,
                               fc_pos_type='',
                               fc_pos=[]):
        'first query screen'
        def append_filter (attrname, items, ctx, fctxtype):
            if not items:
                return
            if fctxtype == 'any':
                self.q.append ('P%s [%s]' %
                               (ctx, '|'.join (['%s="%s"' % (attrname, i)
                                                for i in items])))
            elif fctxtype == 'none':
                self.q.append ('N%s [%s]' %
                          (ctx, '|'.join (['%s="%s"' % (attrname, i)
                                           for i in items])))
            elif fctxtype == 'all':
                for i in items:
                    self.q.append ('P%s [%s="%s"]' % (ctx, attrname, i))
                
        if 'lemma' in self._corp().get_conf('ATTRLIST').split(','):
            lemmaattr = 'lemma'
        else:
            lemmaattr = 'word'
        wposlist = dict (corpconf_pairs (self._corp(), 'WPOSLIST'))
        if self.queryselector == 'phraserow':
            self.default_attr = 'word' # XXX to be removed with new first form
        if self.default_attr:
            qbase = 'a%s,' % self.default_attr 
        else:
            qbase = 'q'
        texttypes = self._texttype_query()
        if texttypes:
            ttquery = ' '.join (['within <%s %s />' % nq for nq in texttypes])
        else:
            ttquery = ''
        par_query = ''
        nopq = []
        for al_corpname in self.sel_aligned:
            if getattr(self, 'pcq_pos_neg_' + al_corpname) == 'pos': wnot = ''
            else: wnot = '!'
            pq = self._compile_basic_query(suff='_'+al_corpname,
                                           cname=al_corpname)
            if pq: par_query += ' within%s %s:%s' % (wnot, al_corpname, pq)
            if not pq or wnot: nopq.append(al_corpname)
        self.q = [qbase + self._compile_query() + ttquery + par_query]

        if fc_lemword_window_type == 'left':
            append_filter (lemmaattr,
                           fc_lemword.split(),
                           '-%i -1 -1' % fc_lemword_wsize,
                           fc_lemword_type)
        elif fc_lemword_window_type == 'right':
            append_filter (lemmaattr,
                           fc_lemword.split(),
                           '1 %i 1' % fc_lemword_wsize,
                           fc_lemword_type)
        elif fc_lemword_window_type == 'both':
            append_filter (lemmaattr,
                           fc_lemword.split(),
                           '-%i %i 1' % (fc_lemword_wsize, fc_lemword_wsize),
                           fc_lemword_type)
        if fc_pos_window_type == 'left':
            append_filter ('tag',
                           [wposlist.get(t,'') for t in fc_pos],
                           '-%i -1 -1' % fc_pos_wsize,
                           fc_pos_type)
        elif fc_pos_window_type == 'right':
            append_filter ('tag',
                           [wposlist.get(t,'') for t in fc_pos],
                           '1 %i 1' % fc_pos_wsize,
                           fc_pos_type)
        elif fc_pos_window_type == 'both':
            append_filter ('tag',
                           [wposlist.get(t,'') for t in fc_pos],
                           '-%i %i 1' % (fc_pos_wsize, fc_pos_wsize),
                           fc_pos_type)
        for al_corpname in self.sel_aligned:
            if al_corpname in nopq and getattr(self,
                                         'filter_nonempty_' + al_corpname, ''):
                self.q.append('X%s' % al_corpname)

    def first (self, fc_lemword_window_type='',
                     fc_lemword_wsize=0,
                     fc_lemword_type='',
                     fc_lemword='',
                     fc_pos_window_type='',
                     fc_pos_wsize=0,
                     fc_pos_type='',
                     fc_pos=[]):
        self.set_first_query(fc_lemword_window_type,
                             fc_lemword_wsize,
                             fc_lemword_type,
                             fc_lemword,
                             fc_pos_window_type,
                             fc_pos_wsize,
                             fc_pos_type,
                             fc_pos)
        if self.sel_aligned: self.align = ','.join(self.sel_aligned)
        return self.view()
    
    first.template = 'view.tmpl'
    add_vars['first'] = ['TextTypeSel', 'LastSubcorp']

    def filter_form (self, within=0):
        self.lemma = ''; self.lpos = ''
        out = {'within': within}
        if within and not self.error:
            out['error'] = _('Please specify positive filter to switch')
        return out
    add_vars['filter_form'] = ['TextTypeSel', 'LastSubcorp']

    def filter (self, pnfilter='', filfl='f', filfpos='-5', filtpos='5',
                inclkwic=False, within=0):
        "Positive/Negative filter"
        if pnfilter not in ('p','n'):
            raise ConcError (_('Select positive or negative filter type'))
        if not inclkwic:
            pnfilter = pnfilter.upper()
        rank = {'f':1, 'l':-1}.get (filfl, 1)
        texttypes = self._texttype_query()
        try:
            query = self._compile_query(cname=self.maincorp)
        except ConcError:
            if texttypes: query = '[]'; filfpos='0'; filtpos='0'
            else: raise ConcError (_('No query entered.'))
        query +=  ' '.join (['within <%s %s />' % nq for nq in texttypes])
        if within:
            wquery = ' within %s:(%s)' % (self.maincorp or self.corpname, query)
            self.q[0] += wquery
            self.q.append('x-' + (self.maincorp or self.corpname))
        else:
            self.q.append ('%s%s %s %i %s' % (pnfilter, filfpos, filtpos,
                                              rank, query))
        try:
            return self.view()
        except:
            if within: self.q[0] = self.q[0][:-len(wquery)]
            else: del self.q[-1]
            raise
    filter.template = 'view.tmpl'
    add_vars['filter'] = ['orig_query']

    def reduce (self, rlines='250'):
        "random sample"
        self.q.append ('r' + rlines)
        return self.view()
       
    reduce.template = 'view.tmpl'

    def freq (self):
        "frequency list form"
        result = {'Pos_ctxs': conclib.pos_ctxs(1,1,6)}
        if not self.is_err_corpus():
            return result
        if '((<err' not in self.q[0] or ')(<corr' not in self.q[0]:
            return result # not an error query
        # construct query for top error lists
        err_query = self.q[0].split('((', 1)[-1]
        err_query, within = err_query.split('))', 1)
        err, corr = err_query.split(')(')
        q0 = 'aword,(%s) within ((%s)(%s)) %s' % (err, err, corr, within)
        q1 = 'p1>0 20>0 1 (%s) within ((%s)(%s))' % (corr, err, corr)
        result['new_q'] = self.urlencode( [('q', q0), ('q', q1)]
                                          + [('q', q) for q in self.q[1:]] )
        result['Err_fcrits'] = [
                  ((_('Error code'),), 'err.type/ 0>0'),
                  ((_('Error form'),), 'word/e 0~0>0'),
                  ((_('Correction form'),), 'word/e 0<1~0>1'),
                  ((_('Error code'), _('error form')),
                               'err.type/ 0>0 word/e 0~0>0'),
                  ((_('Error code'), _('correction form')),
                              'err.type/ 0>0 word/e 0<1~0>1'),
                  ((_('Error code'), _('error form'), _('correction form')),
                              'err.type/ 0>0 word/e 0~0>0 word/e 0<1~0>1'),
                  ((_('Error form'), _('correction form')),
                              'word/e 0~0>0 word/e 0<1~0>1'),
                               ]
        return result


    fcrit = []
    examples = 0
    def freqs (self, fcrit=[], flimit=0, freq_sort='', ml=0):
        "display a frequency list"
        self.exceptmethod = 'freq'
        import operator
        def parse_fcrit(fcrit):
            attrs, marks, ranges = [], [], []
            for i, item in enumerate(fcrit.split()):
                if i % 2 == 0: attrs.append(item)
                if i % 2 == 1: ranges.append(item)
            return attrs, ranges

        corp = self._corp()
        conc = self.call_function (conclib.get_conc, (corp, self.samplesize))
        conc.sync()
        result = {'fcrit': self.urlencode ([('fcrit', self.rec_recode(cr))
                                            for cr in fcrit]),
                  'FCrit': [{'fcrit': cr} for cr in fcrit],
                  'Blocks': [conc.xfreq_dist (cr, flimit, freq_sort, 300, ml,
                                   self.ftt_include_empty) for cr in fcrit],
                  'paging': 0,'concsize':conc.size(),'fullsize':conc.fullsize()}
        if not result['Blocks'][0]: raise ConcError(_('Empty list'))
        if len(result['Blocks']) == 1 and not self.examples: # paging
            fstart = (self.fpage - 1) * self.fmaxitems
            self.fmaxitems = self.fmaxitems * self.fpage + 1
            result['paging'] = 1
            if len(result['Blocks'][0]['Items']) < self.fmaxitems:
                result['lastpage'] = 1
            else:
                result['lastpage'] = 0
            result['Blocks'][0]['Items'] = \
               result['Blocks'][0]['Items'][fstart:self.fmaxitems-1]
        for b in result['Blocks']:
            b['Items'] = b['Items'][:5000] # limit number of results
            for item in b['Items']:
                item['pfilter'], item['nfilter'] = '', ''
                item['pfilter_list'] = []
        ## generating positive and negative filter references
        for b_index, block in enumerate(result['Blocks']):
            curr_fcrit = fcrit[b_index]
            attrs, ranges = parse_fcrit(curr_fcrit)
            for level, (attr, range) in enumerate(zip(attrs, ranges)):
                begin = range.split('~')[0]
                if '~' in range: end = range.split('~')[1]
                else: end = begin
                attr = attr.split("/")
                if len(attr) > 1 and "i" in attr[1]: icase = '(?i)'
                else: icase = ''
                attr = attr[0]
                for ii, item in enumerate(block['Items']):
                    if not item['freq']: continue
                    if not '.' in attr:
                        if attr in corp.get_conf('ATTRLIST').split(','):
                            wwords = item['Word'][level]['n'].split('  ') # two spaces
                            fquery = '%s %s 0 ' % (begin, end)
                            fquery += ''.join(['[%s="%s%s"]'
                                % (attr, icase, escape(w)) for w in wwords ])
                        else: # structure number
                            fquery = '0 0<0 1 [] within <%s #%s/>' % \
                                      (attr, item['Word'][0]['n'].split('#')[1])
                    else: # text types
                        structname, attrname = attr.split('.')
                        if corp.get_conf(structname + '.NESTED'):
                            block['unprecise'] = True
                        fquery = '0 0<0 1 [] within <%s %s="%s" />' \
                                 % (structname, attrname,
                                    escape(item['Word'][level]['n']))
                    if not item['freq']: continue
                    efquery = self.urlencode(fquery)
                    item['pfilter'] += ';q=p%s' % efquery
                    item['pfilter_list'].append('p%s' % fquery)
                    if len(attrs) == 1 and item['freq'] <= conc.size():
                        item['nfilter'] += ';q=n%s' % efquery
        # adding no error, no correction (originally for CUP)
        errs, corrs, err_block, corr_block = 0, 0, -1, -1
        for b_index, block in enumerate(result['Blocks']):
           curr_fcrit = fcrit[b_index]
           if curr_fcrit.split()[0] == 'err.type':
               err_block = b_index
               for item in block['Items']: errs += item['freq']
           elif curr_fcrit.split()[0] == 'corr.type':
               corr_block = b_index
               for item in block['Items']: corrs += item['freq']
        freq = conc.size() - errs - corrs
        if freq > 0 and err_block > -1 and corr_block > -1:
            pfilter = ';q=p0 0<0 1 ([] within ! <err/>) within ! <corr/>'
            cc = self.call_function(conclib.get_conc, (corp,),
                                    q=self.q + [pfilter[3:]])
            freq = cc.size()
            err_nfilter, corr_nfilter = '', ''
            if freq != conc.size():
                err_nfilter = ';q=p0 0<0 1 ([] within <err/>) within ! <corr/>'
                corr_nfilter = ';q=p0 0<0 1 ([] within! <err/>) within <corr/>'
            result['Blocks'][err_block]['Items'].append(
                              {'Word': [{'n': 'no error' }], 'freq': freq,
                               'pfilter': pfilter, 'nfilter': err_nfilter,
                               'norel': 1, 'fbar' :0} )
            result['Blocks'][corr_block]['Items'].append(
                         {'Word': [{'n': 'no correction' }], 'freq': freq,
                          'pfilter': pfilter, 'nfilter': corr_nfilter,
                          'norel': 1, 'fbar' :0} )
        return result

    def savefreq_form (self, fcrit=[]):
        return {'FCrit': [{'fcrit': cr} for cr in fcrit]}

    def savefreq (self, fcrit=[], flimit=0, freq_sort='', ml=0,
                  saveformat='text', maxsavelines=1000):
        "save a frequecy list"
        if self.pages:
            if maxsavelines < self.fmaxitems: self.fmaxitems = maxsavelines
        else:
            self.fpage = 1
            self.fmaxitems = maxsavelines
        self.wlwords, self.wlcache = self.get_wl_words()
        self.blacklist, self.blcache = self.get_wl_words(('wlblacklist',
                                                                    'blcache'))
        if self.wlattr: self.make_wl_query() # multilevel wordlist
        result = self.freqs (fcrit, flimit, freq_sort, ml)
        if saveformat == 'xml':
            self._headers['Content-Type'] = 'application/xml'
            self._headers['Content-Disposition'] = 'attachment; filename="freq.xml"'
            for b in result['Blocks']:
                b['blockname'] = b['Head'][0]['n']
        else:
            self._headers['Content-Type'] = 'text/plain'
            self._headers['Content-Disposition'] = 'attachment; filename="freq.txt"'
        if self.examples:
            self.async, self.pagesize = 0, 1
            self.attrs, self.ctxattrs = 'word', 'word'
            self.viewmode, self.structs = 'sen', 'g,err,corr'
            q_common = self.q
            for b in result['Blocks']:
                for item in b.get('Items', []):
                    self.q = q_common + item['pfilter_list'] + ['e100']
                    line = self.view()['Lines'][0]
                    strline = ''.join([s['str'] for s in line['Left']]) \
                              + ''.join([s['str'] for s in line['Kwic']]) \
                              + ''.join([s['str'] for s in line['Right']])
                    item['example'] = strline
        return result
    add_vars['savefreq'] = ['Desc']
    
    def freqml (self, flimit=0, freqlevel=1,
                ml1attr='word', ml1pos=1, ml1icase='', ml1fcode='rc',
                ml2attr='word', ml2pos=1, ml2icase='', ml2fcode='rc',
                ml3attr='word', ml3pos=1, ml3icase='', ml3fcode='rc',
                ml4attr='word', ml4pos=1, ml4icase='', ml4fcode='rc',
                ml1ctx='0', ml2ctx='0', ml3ctx='0', ml4ctx='0'):
        "multilevel frequency list"
        l = locals()
        fcrit = ' '.join([onelevelcrit ('', l['ml%dattr'%i],
                                        l['ml%dctx'%i], l['ml%dpos'%i],
                                        l['ml%dfcode'%i], l['ml%dicase'%i], 'e')
                         for i in range(1, freqlevel+1)])
        result = self.freqs ([fcrit], flimit, '', 1)
        result['ml'] = 1
        return result
    freqml.template = 'freqs.tmpl'

    def freqtt (self, flimit=0, fttattr=[]):
        if not fttattr:
            self.exceptmethod = 'freq'
            raise ConcError(_('No text type selected'))
        return self.freqs (['%s 0' % a for a in fttattr], flimit)
    freqtt.template = 'freqs.tmpl'

    cattr = 'word'
    csortfn = 'd'
    cbgrfns = 'mtd'
    cfromw = -5
    ctow = 5
    cminfreq = 5
    cminbgr = 3
    cmaxitems = 50
    
    def coll (self):
        "collocations form"
        if self.maincorp:
            corp = conclib.manatee.Corpus(self.abs_corpname(self.maincorp))
        else: corp = self._corp()
        colllist = corp.get_conf('ATTRLIST').split(',')
        out = {'Coll_attrlist': [{'n': n,
                                  'label': corp.get_conf (n+'.LABEL') or n}
                                 for n in colllist],
               'Pos_ctxs': conclib.pos_ctxs(1,1)}
        return out

    def collx (self, cattr='', csortfn='d', cbgrfns=['t','m', 'd'], usesubcorp=''):
        "list collocations"
        if self.maincorp:
            corp = conclib.manatee.Corpus(self.abs_corpname(self.maincorp))
        else:
            corp = self._corp()
        if usesubcorp and not corplib.are_subcorp_stats_compiled (corp, cattr):
            out = corplib.compute_freqfile (self._user, corp, cattr,
                                            self.wlnums, self.get_url())
            return { 'processing': out["progress"] == '100' and '99' \
                                   or out["progress"],
                     'bgjob_notification': out['notifyme'] and 'checked' or '',
                     'jobid': out["jobid"], 'esttime': out["esttime"],
                     'new_maxitems': self.wlmaxitems}
        collstart = (self.collpage - 1) * self.cmaxitems
        self.cmaxitems = self.cmaxitems * self.collpage + 1
        self.cbgrfns = ''.join (cbgrfns)
        if not csortfn and cbgrfns:
            self.csortfn = cbgrfns[0]
        conc = self.call_function (conclib.get_conc, (self._corp(),))
        result = self.call_function (conc.collocs, ())
        if len(result['Items']) < self.cmaxitems:
            result['lastpage'] = 1
        else:
            result['lastpage'] = 0;
            result['Items'] = result['Items'][:-1]
        result['Items'] = result['Items'][collstart:]
        for item in result['Items']:
            item["pfilter"] = 'q=' + self.urlencode(item["pfilter"])
            item["nfilter"] = 'q=' + self.urlencode(item["nfilter"])
        result['concsize'] = conc.size()
        return result


    def save_coll_options(self, cbgrfns=['t','m']):
        out = self.coll()
        self.cbgrfns = ''.join(cbgrfns)
        self._save_options(['cattr', 'cfromw', 'ctow', 'cminfreq', 'cminbgr',
                            'cmaxitems', 'cbgrfns', 'csortfn'], self.corpname)
        out['saved_attrs'] = 1
        return out

    save_coll_options.template = 'coll.tmpl'


    def savecoll (self, csortfn='', cbgrfns=['t','m'], saveformat='text',
                  maxsavelines=1000):
        "save collocations"
        if self.pages:
            if maxsavelines < self.cmaxitems:
                self.cmaxitems = maxsavelines
        else:
            self.collpage = 1
            self.cmaxitems = maxsavelines
        result = self.collx(csortfn, cbgrfns)
        if saveformat == 'xml':
            self._headers['Content-Type'] = 'application/xml'
            self._headers['Content-Disposition'] = 'attachment; filename="coll.xml"'
            result['Scores'] = result['Head'][2:]
        else:
            self._headers['Content-Type'] = 'text/plain'
            self._headers['Content-Disposition'] = 'attachment; filename="coll.txt"'
        return result
    add_vars['savecoll'] = ['Desc']


    def structctx (self, pos=0, struct='doc'):
        "display a hit in a context of a structure"
        s = self._corp().get_struct(struct)
        struct_id = s.num_at_pos(pos)
        beg, end = s.beg(struct_id), s.end(struct_id)
        self.detail_left_ctx = pos - beg
        self.detail_right_ctx = end - pos - 1
        result = self.widectx(pos)
        result ['no_display_links'] = True
        return result

    structctx.template = 'widectx.tmpl'

        
    def widectx (self, pos=0):
        "display a hit in a wider context"
        return self.call_function (conclib.get_detail_context, (self._corp(),
                                                                pos))

    def fullref (self, pos=0):
        "display a full reference"
        return self.call_function (conclib.get_full_ref, (self._corp(), pos))

    def freq_distrib(self, fcrit='', flimit=0, res=100, ampl=101, format=''):
        "get data for frequency distribution graph"
        if format == 'json':
            self.format = 'json'
        self.fcrit = fcrit
        conc = self.call_function(conclib.get_conc, (self._corp(),))
        values = conclib.manatee.IntVector([0]*res)
        begs = conclib.manatee.IntVector([0]*res)
        conc.distribution(values, begs, ampl)
        begs = [conc.beg_at(i) for i in begs]
        ends = [i-1 for i in begs[1:]] + [begs[-1] + conc.size()/res]
        return {
                'dots': [{
                    'frq': v[0],
                    'pos': i/float(len(values)),
                    'beg': int(v[1]),
                    'end': int(v[2]),
                    } for i, v in enumerate(zip(values, begs, ends))],
                'granularity': res
        }

    def clear_cache (self, corpname=''):
        if not corpname: corpname = self.corpname
        if '../' in corpname or corpname.startswith('/'):
            return 'This action is not allowed.'
        os.system ('rm -rf %s/%s' % (self._cache_dir, corpname))
        return 'Cache cleared: %s' % corpname

    def check_histogram_processing(self):
        logfile_name = os.path.join(self.subcpath[-1], self.corpname,
                                                                 'hist.build')
        if os.path.isfile(logfile_name):
            logfile = open(logfile_name)
            lines = logfile.readlines()
            if len(lines) > 1:
                try:
                    xxx = int(lines[1].strip());
                    out = (lines[1], lines[-1])
                except:
                    out = (lines[0], lines[-1])
            else:
                out = ('', lines[-1])
            logfile.close()
        else:
            out = ('', '')
        return ':'.join(map(str.strip, out))

    def kill_histogram_processing(self):
        pid = self.check_histogram_processing().split(':')[0]
        if pid:
            try:
                os.kill(int(pid), 9)
                os.remove(os.path.join(self._tmp_dir, 'findx_upload.%s' % self._user))
            except OSError:
                pass
        logfile_name = os.path.join(self.subcpath[-1], self.corpname,
                                                                  'hist.build')
        if os.path.isfile(logfile_name):
            os.rename(logfile_name, logfile_name + '.old')
        tmp_glob = os.path.join(self.subcpath[-1], self.corpname, '*.histtmp')
        for name in glob.glob(tmp_glob):
            os.rename(name, name[:-8])
        return self.wordlist_form()
    kill_histogram_processing.template = 'findx_upload_form.tmpl'
    add_vars['kill_histogram_processing'] = ['LastSubcorp']

    def findx_form (self):
        out = {'Histlist': []}
        try: import genhist
        except: return out
        histpath = self._corp().get_conf('WSHIST')
        histpath_custom = os.path.join(self.subcpath[-1], self.corpname,
                                                             'histograms.def')
        histlist = []
        if os.path.isfile(histpath):
            histlist.extend(genhist.parse_config_file (open(histpath)))
        if os.path.isfile(histpath_custom):
            histlist.extend(genhist.parse_config_file (open(histpath_custom)))
        histlist_ids = []
        for hist in histlist:
            id = hist.get_id()
            if id not in histlist_ids:
                histlist_ids.append(id)
                out['Histlist'].append({'name': hist.get_attr('HR') or id,
                                        'id': id})
        return out 

    wlminfreq = 5
    wlmaxfreq = 0
    wlmaxitems = 100
    wlicase = 0
    wlwords = []
    blacklist = []
    _wordlist_max_size = 0
    tagset_ref_corpus = u''

    def wordlist_form (self, ref_corpname=''):
        "Word List Form"
        nogenhist = 0
        corp = self._corp()
        attrlist = corp.get_conf('ATTRLIST').split(',')
            # set reference corpus and reference subcorp list (for keywords)
        out = {'termdef': corp.get_conf('TERMDEF')}
        if not ref_corpname:
            if self.tagset_ref_corpus: ref_corpname = self.tagset_ref_corpus[0]
            else: ref_corpname = self.corpname
        if not self.compatible_corpora:
            self.compatible_corpora = self.corplist
        if self.compatible_corpora \
		and type(self.compatible_corpora[0]) in (type([]), type((0,))):
            self.compatible_corpora = map(lambda x:x[0],
                                          self.compatible_corpora)
        if not self.corpname in self.compatible_corpora:
            self.compatible_corpora.insert(0, self.corpname)
        out['TagsetCompatible'] = [self.corpname]
        if self.tagset_compatible_corpora:
            if type(self.tagset_compatible_corpora[0]) in (type([]),type((0,))):
                self.tagset_compatible_corpora = map(lambda x:x[0],
                                                self.tagset_compatible_corpora)
            out['TagsetCompatible'] += self.tagset_compatible_corpora
        refcm = corplib.CorpusManager(self.compatible_corpora, self.subcpath,
                                      abs_corpname=self.abs_corpname)
        out['CompatibleCorpora'] = refcm.corplist_with_names()
        out['RefSubcorp'] = refcm.subcorp_names (ref_corpname)
        out['ref_corpname'] = ref_corpname
        if corp.get_conf('ALIGNED'):
            biterm_corpora = []
            for acorp in corp.get_conf('ALIGNED').split(','):
                if os.path.exists(os.path.join(corp.get_conf('PATH'),\
                        acorp + '.biterms')):
                    ac = corplib.manatee.Corpus(acorp)
                    biterm_corpora.append((acorp, ac.get_conf('LANGUAGE')))
            if biterm_corpora:
                out['biterm_corpora'] = biterm_corpora
        return out
    add_vars['wordlist_form'] = ['LastSubcorp']

    def findx_upload_form(self):
        out = {}
        out['processing'] = self.check_histogram_processing().split(':')[1]
        return out


    def get_wl_words(self, attrnames=('wlfile', 'wlcache')):
            # gets arbitrary list of words for wordlist
        wlfile = getattr(self, attrnames[0], '').encode('utf8')
        wlcache = getattr(self, attrnames[1], '')
        filename = wlcache; wlwords = []
        if wlfile: # save a cache file
            try:
                from hashlib import md5
            except ImportError:
                from md5 import new as md5
            filename = os.path.join(self._cache_dir,
                                    md5(wlfile).hexdigest() + '.wordlist')
            if not os.path.isdir(self._cache_dir): os.makedirs (self._cache_dir)
            cache_file = open(filename, 'w')
            cache_file.write(wlfile)
            cache_file.close()
            wlwords = [w.decode('utf8').strip() for w in wlfile.split('\n')]
        if wlcache: # read from a cache file
            filename = os.path.join(self._cache_dir, wlcache)
            cache_file = open(filename)
            wlwords = [w.decode('utf8').strip() for w in cache_file]
            cache_file.close()
        return wlwords, os.path.basename(filename)


    include_nonwords = 0
    usengrams = 0
    ngrams_n = 2
    ngrams_max_n = 2
    nest_ngrams = 0
    wltype = 'simple'
    wlnums = 'frq'
    complement_subc = 0

    def check_wl_compatibility (self, wltype, ref_subcorp):
        if self.usengrams or ref_subcorp == '== the rest of the corpus ==':
            if self.usengrams and self.wlnums != 'frq':
                raise ConcError(_('N-grams and "rest of corpus" can use only '
                                  'raw hit counts'))
            if wltype == 'multilevel':
                raise ConcError(_('N-grams are not compatible with changing '
                                  'output attribute(s)'))
            if self.wlattr in ('ws_collocations', 'ws_terms') \
                     or '.' in self.wlattr:
                raise ConcError(_('N-grams and "rest of corpus" can use only '
                                  'positional attributes'))
        if self.usengrams and ref_subcorp == '== the rest of the corpus ==':
            raise ConcError(_('N-grams and "rest of corpus" can not be used'
                              'together'))
        if '.' in self.wlattr:
            if wltype != 'simple':
                raise ConcError(_('Text types are limited to simple output'))
            if self.wlnums == 'arf':
                raise ConcError(_('ARF cannot be used with text types'))
            elif self.wlnums == 'frq':
                self.wlnums = 'doc sizes'
            elif self.wlnums == 'docf':
                self.wlnums = 'frq'
        if self.wlattr == 'ws_collocations' and self.wlnums != 'frq':
            raise ConcError(_('Word sketch collocations are available '
                            'with raw hit counts only'))
        if self.wlattr == 'ws_collocations' and self.usesubcorp:
            raise ConcError(_('Word sketch collocations are available '
                            'for the whole corpus only'))
        if self.wlattr == 'ws_terms' and self.wlnums != 'frq':
            raise ConcError(_('Terms are available with raw hit counts only'))

    def wipo (self, single=0):
        from wipo_filters import filter_wipo_terms
        self.exceptmethod = 'first_form'
        self.wlmaxitems = max(1000, self.wlmaxitems)
        self.blacklist, self.blcache = self.get_wl_words(('wlblacklist',
                                                          'blcache'))
        refcorpora = { 'English':  'ententen12_sample40M',
                       'French':   'frtenten_sample',
                       'Chinese Simplified':  'zhtenten_10M',
                       'Japanese': 'jptenten11_luw_sample',
                       'Korean':   'kotenten12_sample',
                       'Portuguese': 'pttenten11_lempos_sample',
                       'German':   'detenten2_50M',
                       'Spanish':  'estenten11_freeling_new_sample',
                       'Russian':  'rutenten11_8_1G',
                     }
        lang = self._corp().get_conf('LANGUAGE').split(', ')[0]
        if lang not in refcorpora:
            raise ConcError('Term extraction not available for this language')
        keyterms, size = corplib.ws_keywords(self._corp(),
                                     corplib.manatee.Corpus(refcorpora[lang]),
                                     wlminfreq=1, wlmaxitems=self.wlmaxitems*5,
                                     simple_n=1, ret_count=True,
                                     wlattr='ws_terms', filter_singleword=0)
        if size < 100000: # count the exact numbers
            keyterms, size = corplib.ws_keywords(self._corp(),
                                     corplib.manatee.Corpus(refcorpora[lang]),
                                     wlminfreq=1, wlmaxitems=100000,
                                     simple_n=1, ret_count=True,
                                     wlattr='ws_terms', filter_singleword=0)
        data = [{'str': w.replace('_', ' '), 'score': round(s,1),
                 'freq': int(f), 'rel': round(rel, 1)}
                    for s, rel, relref, f, fr, w in keyterms]
        keyterms = [x for x in filter_wipo_terms(data, lang, single)
                          if x['str'].split('\t')[2] not in self.blacklist]
        if size < 100000: size = len(keyterms)
        return { 'Keyterms': keyterms[:self.wlmaxitems],
                 'single': single,
                 'lang': lang,
                 'size': size,
               }

    def savewipo (self, single=0):
        self._headers['Content-Type'] = 'text/plain'
        self._headers['Content-Disposition'] = 'attachment; filename="trms.csv"'
        return self.wipo(single)


    def do_nest_ngrams(self, items): # items must be sorted by freq
        from operator import itemgetter
        ngrams = [[], [], [], [], [], [], [], []]
             # (0-), (1-), 2-, 3-, 4-, 5-, 6-, (7-)grams
        for item in items:
            n = item['str'].count('  ') + 1
            item['str'] = '  ' + item['str'] + '  '
            item['children'] = []
            item['nested'] = False
            for ng in reversed(ngrams[n+1]): # find superior n+1-gram
                if ng['freq'] > item['freq']:
                    break
                if item['str'] in ng['str']: # ng['freq'] == item['freq']
                    item['nested'] = True
                    ng['children'].append(item)
            for ng in ngrams[n-1]: # find subordinate (n-1)-grams
                if ng['str'] in item['str']:
                    item['children'].append(ng)
                    ng['nested'] = True
            ngrams[n].append(item)
        result = ngrams[2]+ngrams[3]+ngrams[4]+ngrams[5]+ngrams[6]
        result.sort(key=itemgetter('freq'), reverse=True)
        for item in result:
            item['str'] = item['str'][2:-2]
        return result


    def wordlist (self, wlpat='', wltype='simple', corpname='', usesubcorp='',
                  ref_corpname='', ref_usesubcorp='', wlpage=1):
        if not wlpat: self.wlpat = '.*'
        if '.' in self.wlattr: orig_wlnums = self.wlnums
        self.check_wl_compatibility(wltype, ref_usesubcorp)
        result= {'new_maxitems': self.wlmaxitems}; lastpage = 0 # for template
        wlstart = (wlpage - 1) * self.wlmaxitems
        self.wlmaxitems =  self.wlmaxitems * wlpage + 1 # +1 = end detection
        if self._wordlist_max_size and (self._wordlist_max_size
                                              < self.wlmaxitems):
            self.wlmaxitems = self._wordlist_max_size
            result['lastpage'] = 1
            result['note'] = _('You are allowed to see only %s items.') \
                               % self._wordlist_max_size
        try:
            self.words, self.wlcache = self.get_wl_words()
            self.blacklist, self.blcache = self.get_wl_words(('wlblacklist',
                                                                    'blcache'))
            if wltype == 'keywords':
                sc = self.cm.get_Corpus (self.corpname, usesubcorp,
                                         self.complement_subc)
                if ref_usesubcorp == '== the rest of the corpus ==':
                    scref = self.cm.get_Corpus (ref_corpname, usesubcorp,
                                                complement=True)
                else:
                    scref = self.cm.get_Corpus (ref_corpname, ref_usesubcorp)
                if self.wlattr in ('ws_terms', 'ws_collocations'):
                    kw_func = getattr(corplib, 'ws_keywords')
                elif self.usengrams:
                    kw_func = getattr(corplib, 'ngr_keywords')
                else:
                    kw_func = getattr(corplib, 'subc_keywords_onstr')
                out = self.call_function (kw_func, (sc, scref))
                result_list = [{
                    'str': w, 'score': round(s,1),
                    'freq': round(f, 1) if self.wlnums == 'arf' else int(f),
                    'freq_ref': round(fr, 1) if self.wlnums=='arf' else int(fr),
                    'rel': round(rel, 1),
                    'rel_ref': round(relref, 1) }
                       for s, rel, relref, f, fr, w in out]
                result['ref_corp_full_name'] = scref.get_conf('NAME') \
                                               or scref.get_conffile()
            else: # ordinary list
                if self.wlattr in ('ws_terms', 'ws_collocations'):
                    result_list = self.call_function (corplib.ws_wordlist,
                                                      (self._corp(),))
                elif self.usengrams:
                    if self.nest_ngrams:
                        wlstart = 0
                        self.wlmaxitems = self.wlpage * 1000
                        if self._wordlist_max_size \
                              and self._wordlist_max_size < self.wlpage * 1000:
                            self.wlmaxitems = self._wordlist_max_size
                    result_list = self.call_function (corplib.ngrams,
                                                      (self._corp(),))
                    if self.nest_ngrams:
                        if 0 < self._wordlist_max_size <= len(result_list):
                            result['note'] = _('You are allowed to see only %s'
                                           ' items.') % self._wordlist_max_size
                        result_list = self.do_nest_ngrams(result_list)
                else:
                    if hasattr(self, 'wlfile') and self.wlpat == '.*':
                        self.wlsort = ''
                    result_list, cnt = self.call_function (corplib.wordlist,
                                                           (self._corp(),))
                    result['total'] = cnt
                    if self.words: result['wlcache'] = self.wlcache
                    if self.blacklist: result['blcache'] = self.blcache
            result_list = result_list[wlstart:]
            for ll in result_list: # url-encoded queries to concordance
                encstr = ll['str'].replace('\\', '\\\\"').replace('"', '\\"')
                ll['q'] = self.urlencode(''.join(['[%s=="%s"]' % (self.wlattr,w)
                                                  for w in encstr.split('  ')]))
            if len(result_list) < self.wlmaxitems/wlpage: result['lastpage'] = 1
            else: result['lastpage'] = 0; result_list = result_list[:-1]
            if wltype == 'keywords': result['Keywords'] = result_list
            else: result['Items'] = result_list
            self.wlmaxitems -= 1
            if '.' in self.wlattr: self.wlnums = orig_wlnums
            try:
                if not wlattr in ('ws_terms', 'ws_collocations'):
                    result['wlattr_label'] = self._corp().get_conf(
                                           self.wlattr+'.LABEL') or self.wlattr
            except:
                result['wlattr_label'] = self.wlattr
            result['frtp'] = corplib.get_stat_desc (self.wlnums)
            return result
        except corplib.MissingSubCorpFreqFile, subcmiss: # run compilation
            self.wlmaxitems -= 1
            if self.usengrams:
                if type('') == type(subcmiss.args[0]): # missing n-grams
                    out = corplib.compute_ngrams (self._user, self._corp(),
                                                  subcmiss.args[0],
                                                  self.get_url())
                else: # freqfile miss
                    out = corplib.compute_freqfile (self._user,
                          subcmiss.args[0], self.wlattr + '.ngr',
                          self.wlnums, self.get_url())
            else:
                if self.wlattr not in ('ws_terms', 'ws_collocations'):
                    corp = self._corp()
                    try: doc = corp.get_struct(corp.get_conf('DOCSTRUCTURE'))
                    except: raise ConcError('DOCSTRUCTURE not set correctly')
                out = corplib.compute_freqfile (self._user,
                      subcmiss.args[0], self.wlattr, self.wlnums, self.get_url())
            return { 'processing': out["progress"] == '100' and '99' or out["progress"],
                     'bgjob_notification': out['notifyme'] and 'checked' or '',
                     'jobid': out["jobid"], 'esttime': out["esttime"],
                     'new_maxitems': self.wlmaxitems}

    wlstruct_attr1 = ''
    wlstruct_attr2 = ''
    wlstruct_attr3 = ''

    def make_wl_query(self):
        qparts = []
        if self.wlpat: qparts.append('%s="%s"' % (self.wlattr, self.wlpat))
        if not self.include_nonwords:
            qparts.append('%s!="%s"' % (self.wlattr,
                                        self._corp().get_conf('NONWORDRE')))
        if self.wlwords:
            qq = ['%s=="%s"' % (self.wlattr, w.strip()) for w in self.wlwords]
            qparts.append('(' + '|'.join(qq) + ')')
        for w in self.blacklist:
            qparts.append('%s!=="%s"' % (self.wlattr, w.strip()))
        self.q = ['q[' + '&'.join(qparts) + ']']

    def struct_wordlist (self):
        self.exceptmethod = 'wordlist_form'
        if self.fcrit:
            self.wlwords, self.wlcache = self.get_wl_words()
            self.blacklist, self.blcache = self.get_wl_words(('wlblacklist',
                                                                    'blcache'))
            self.make_wl_query()
            return self.freqs (self.fcrit, self.flimit, self.freq_sort, 1)

        if '.' in self.wlattr:
            raise ConcError('Text types are limited to Simple output')
        if self.wlnums != 'frq':
            raise ConcError('Multilevel lists are limited to Word counts frequencies')
        if self.wlattr == 'ws_collocations':
            raise ConcError('Word sketch collocations are not compatible '
                            'with Multilevel wordlist')
        level = 3
        self.wlwords, self.wlcache = self.get_wl_words()
        self.blacklist, self.blcache = self.get_wl_words(('wlblacklist',
                                                                    'blcache'))
        if not self.wlstruct_attr1:
            raise ConcError(_('No output attribute specified'))
        if not self.wlstruct_attr3: level = 2
        if not self.wlstruct_attr2: level = 1
        if not self.wlpat and not self.wlwords:
            raise ConcError(_('You must specify either a regular expression or a file to get the multilevel wordlist'))
        self.make_wl_query()
        self.flimit = self.wlminfreq
        return  self.freqml (flimit=self.wlminfreq, freqlevel=level,
                ml1attr=self.wlstruct_attr1, ml2attr=self.wlstruct_attr2,
                ml3attr=self.wlstruct_attr3)
    struct_wordlist.template = 'freqs.tmpl'

    def savewl (self, maxsavelines=1000, wlpat='', wltype='simple',
                usesubcorp='', ref_corpname='', ref_usesubcorp='',
                saveformat='csv'):
        'save word list'
        if saveformat == 'xml':
            self._headers['Content-Type'] = 'application/xml'
            self._headers['Content-Disposition'] = 'attachment; filename="wl.xml"'
        else:
            self._headers['Content-Type'] = 'text/%s' % saveformat
            self._headers['Content-Disposition'] = 'attachment; filename="wl.%s"' % saveformat
        if not self.pages:
            self.wlpage = 1
            self.wlmaxitems = maxsavelines
        return self.wordlist(wlpat, wltype, self.corpname, usesubcorp,
                             ref_corpname, ref_usesubcorp, wlpage=self.wlpage)
     
    subcnorm = 'freq'

    def texttypes_with_norms(self, subcorpattrs='', list_all=False, ret_nums=True):
        corp = self._corp()
        if not subcorpattrs:
            subcorpattrs = corp.get_conf ('SUBCORPATTRS') \
                               or corp.get_conf ('FULLREF')
        if not subcorpattrs or subcorpattrs == '#':
            return { 'error': _('No meta-information to create a subcorpus.'),
                     'Normslist': [], 'Blocks': [],
                   }
        tt = corplib.texttype_values(corp, subcorpattrs, list_all, self.hidenone)
        if not ret_nums: return {'Blocks': tt, 'Normslist': []}
        basestructname = subcorpattrs.split('.')[0]
        struct = corp.get_struct (basestructname)
        normvals = {}
        if self.subcnorm not in ('freq', 'tokens'):
            try:
                nas = struct.get_attr (self.subcnorm).pos2str
            except conclib.manatee.AttrNotFound, e:
                self.error = str(e)
                self.subcnorm = 'freq'
        for item in tt:
            for col in item['Line']:
                if col.has_key('textboxlength'): continue
                if not col['name'].startswith(basestructname):
                    col['textboxlength'] = 30; continue
                attr = struct.get_attr(col['name'].split('.')[-1])
                p2i = attr.pos2id
                xcnt_dict = dict([(i, 0) for i in range(attr.id_range())])
                if self.subcnorm == 'freq':
                    for vid in xrange(attr.id_range()):
                        xcnt_dict[vid] = attr.freq(vid)
                elif self.subcnorm == 'tokens':
                    for sid in xrange(struct.size()):
                        vid = p2i(sid)
                        xcnt_dict[vid] += struct.end(sid) - struct.beg(sid)
                else:
                    for vid in xrange(attr.id_range()):
                        xcnt_dict[vid] = attr.norm(vid)
                for val in col['Values']:
                    val['xcnt'] = xcnt_dict.get(attr.str2id(unicode(val['v'])), 0)
        return {'Blocks': tt, 'Normslist': self.get_normslist(basestructname)}

    def get_normslist(self, structname):
        corp = self._corp()
        normsliststr = corp.get_conf ('DOCNORMS')
        normslist = [{'n':'freq', 'label': _('Document counts')},
                     {'n':'tokens', 'label': _('Tokens')}]
        if normsliststr:
            normslist += [{'n': n, 'label': corp.get_conf (structname + '.'
                                                          + n + '.LABEL') or n}
                          for n in normsliststr.split(',')]
        else:
            try:
                corp.get_attr(structname + ".wordcount")
                normslist.append({'n':'wordcount', 'label': _('Word counts')})
            except:
                pass
        return normslist

    def subcorp_form (self, subcorpattrs=''):
        tt_sel = self.texttypes_with_norms()
        if tt_sel.has_key('error'): 
            return {'error': tt_sel['error'], 'TextTypeSel': tt_sel }
        return { 'TextTypeSel': tt_sel }

    def _texttype_query (self):
        scas = [(a[4:], getattr (self, a))
                for a in dir(self) if a.startswith ('sca_')]
        fscas = [(a[5:], getattr (self, a))
                 for a in dir(self) if a.startswith ('fsca_')]
        structs = {}
        for sa, v in scas: # checkbox input
            s, a = sa.split('.')
            if type(v) is type([]):
                query = '(%s)' % ' | '.join (['%s="%s"' % (a,escape(v1))
                                              for v1 in v])
            else:
                query = '%s="%s"' % (a,escape(v))
            if not structs.has_key (s): structs[s] = []
            structs[s].append (query)
        for sa, v in fscas: # free text input (allows REs)
            s, a = sa.split('.')
            query = '%s="%s"' % (a, v)
            if not structs.has_key (s): structs[s] = []
            structs[s].append (query)
        return [(sname, ' & '.join(subquery)) for
                sname, subquery in structs.items()]
        
    def subcorp (self, subcname='', delete='', create=False, q='', struct='', ttq=''):
        if delete:
            base = os.path.join (self.subcpath[-1], self.corpname, subcname)
            base = base.encode('utf8')
            for e in glob.glob(base + '.*'):
                if e.endswith('subcdef'):
                    continue
                if os.path.isfile(e):
                    os.unlink(e)
        tt_query = ttq or self._texttype_query()
        if create and not subcname:
            raise ConcError (_('No subcorpus name specified!'))
        if (not subcname or (not tt_query and delete)
            or (not delete and not create)):
            subcList = self.cm.subcorp_names (self.corpname)
            if subcList and not subcname:
                subcname = subcList[0]['n']
            return {'subcname': subcname,
                    'SubcorpList': self.cm.subcorp_names (self.corpname)}
        basecorpname = self.corpname.split(':')[0]
        path = os.path.join (self.subcpath[-1], basecorpname)
        if not os.path.isdir (path):
            os.makedirs (path)
        path = os.path.join (path, subcname) + '.subc'
        # XXX ignoring more structures
        if type(path) == unicode:
            path = path.encode("utf-8")
        if q: # AJAX
            conc = self.call_function (conclib.get_conc,
                                       (self._corp(), self.samplesize))
            conc.sync()
            s = self._corp().get_struct(struct)
            cs = conclib.manatee.create_subcorpus (path, conc.RS(), s)
            if cs:
                corplib.save_subcdef(path, subcname, struct or '--NONE--',
                        'Q:' + '\v'.join(self.q))
                return _("Subcorpus saved.")
            else:
                return _("Nothing saved: empty subcorpus!")
        else:
            if not tt_query:
                raise ConcError (_('Nothing specified!'))
            structname, subquery = tt_query[0]
            if conclib.manatee.create_subcorpus (path, self._corp(), structname,
                                                 subquery):
                # save subc def file
                subcdeff = corplib.save_subcdef(path, subcname, structname,
                        subquery)
                finalname = '%s:%s' % (basecorpname, subcname)
                sc = self.cm.get_Corpus (finalname)
                return {'subcorp': finalname,
                        'subcorp_deffile': subcdeff,
                        'corpsize': sc.size(),
                        'subcsize': sc.search_size(),
                        'SubcorpList': self.cm.subcorp_names (self.corpname)}
            else:
                raise ConcError (_('Empty subcorpus!'))

    def subcorp_info (self, subcname=''):
        sc = self.cm.get_Corpus (self.corpname, subcname)
        return {'subcorp': subcname,
                'corpsize': sc.size(),
                'subcsize': sc.search_size()}

    def rebuild_subc(self, subcname=''):
        self.format = 'json'
        subcp = os.path.join(self.subcpath[-1], self.corpname, subcname + '.subcdef')
        subcn, subcs, subcq = corplib.parse_subcdef(subcname, subcp)
        self.subcorp(subcname, True)
        if all([subcn, subcs, subcq]):
            subcs = subcs.replace('--NONE--', '')
            if subcq.startswith('Q:'):
                self.q = subcq[2:].split('\v')
                return self.subcorp(subcname, False, True, subcq[2:], subcs, '')
            else:
                return self.subcorp(subcname, False, True, '', '', [(subcs, subcq)])
        else:
            raise RuntimeError('Failed to rebuild subcorpus')

    def corp_info (self, corpname='', gramrels=0):
        self._headers['Content-Type'] = 'text/html'
        return corplib.get_corp_info(self.abs_corpname(corpname), self.registry, gramrels)

    def attr_vals (self, avattr='', avpat=''):
        self.format = 'json'
        return corplib.attr_vals(self.abs_corpname(self.corpname), avattr,
                                 avpat)

    def corpus_lpos(self, corpname=''):
        self.format = 'json'
        corp = conclib.manatee.Corpus(self.abs_corpname(corpname))
        if 'lempos' == corp.get_conf('WSATTR').strip():
            l = corp.get_conf('WSPOSLIST').split(',')[1:]
            return {'lposlist': zip(l[0::2], l[1::2])}
        else:
            return {'lposlist': []}

    def has_auto_pos(self):
        try:
            return self._corp().get_conf('WSATTR') in ['lempos', 'lempos_lc']\
                    and self._corp().get_attr('lemma')\
                    and self._corp().get_conf('lemma.DYNAMIC')
        except:
            return False

    maxsavelines=1000
    def saveconc (self, maxsavelines=1000, saveformat='text', pages=0, fromp=1,
                  align_kwic=0, numbering=0, leftctx='40#', rightctx='40#'):
        if maxsavelines > 100000: maxsavelines = 100000
        conc = self.call_function (conclib.get_conc,
                                   (self._corp(), self.samplesize))
        conc.switch_aligned (os.path.basename(self.corpname))
        if saveformat == 'xml':
            self._headers['Content-Type'] = 'application/xml'
            self._headers['Content-Disposition'] = 'attachment; filename="conc.xml"'
        else:
            self._headers['Content-Type'] = 'text/plain'
            self._headers['Content-Disposition'] = 'attachment; filename="conc.txt"'
        ps = self.pagesize
        if pages:
            if maxsavelines < self.pagesize:
                ps = maxsavelines
        else:
            fromp = 1
            ps = maxsavelines
        labelmap = {}
        if self.annotconc:
            try:
                anot = self._get_annotconc()
                conc.set_linegroup_from_conc (anot)
                labelmap = anot.labelmap
            except conclib.manatee.FileAccessError:
                pass
        return self.call_function (conclib.kwicpage, (conc,), fromp=fromp,
                                   pagesize=ps, labelmap=labelmap, align=[],
                                   alignlist=[self.cm.get_Corpus(c)
                                        for c in self.align.split(',') if c])
    add_vars['saveconc'] = ['Desc']

    def _storeconc_path (self, annotconc=None):
        return os.path.join (self._conc_dir, self.corpname.split(':')[0],
                             annotconc or self.annotconc)
    
    def storeconc (self, storeconcname=''):
        conc = self.call_function (conclib.get_conc, (self._corp(),))
        self.annotconc = storeconcname
        cpath = self._storeconc_path()
        cdir = os.path.dirname (cpath)
        if not os.path.isdir (cdir):
            os.makedirs (cdir)
        conc.save (cpath + '.conc')
        um=os.umask (self.annotconc_info_umask)
        labels ='\n'.join(['%i\t%s' % (n+1,x)
                           for (n,x) in enumerate(self.annotconc_init_labels)])
        open (cpath + '.info', 'w').write(labels + '\n')
        os.umask (um)
        self._cookieattrs.append ('annotconc')
        return {'stored': storeconcname}
    storeconc.template = 'saveconc_form.tmpl'
    add_vars['storeconc'] = ['Desc']

    def storeconc_fromlemma (self, lemma='', lpos='-v'):
        import re
        num = re.search ('-\d+$', lemma)
        if num:
            annotname = lemma
            lemma = lemma [:num.start()]
        else:
            annotname = lemma
        if 'lempos' in self._corp().get_conf('ATTRLIST').split(','):
            self.q = ['q[lempos="%s%s"]' % (lemma, lpos)]
            annotname += lpos
        else:
            self.q = ['q[lemma="%s"]' % lemma]
        if not self._selectstored (annotname):
            self.storeconc (annotname)
        self.annotconc = annotname
        try:
            return self.view()
        except ConcError:
            self.exceptmethod = 'cpa_form'
            raise
    storeconc_fromlemma.template = 'view.tmpl'

    def _selectstored (self, annotconc):
        if os.path.exists (self._storeconc_path(annotconc) + '.conc'):
            self._cookieattrs.append ('annotconc')
            return True
        return False
 
    def selectstored (self, annotconc='', storedconcnumber=200):
        out = {}
        if self._selectstored (annotconc):
            out['selected'] = annotconc
            if annotconc.startswith('cpa'):
                out['lemma'] = annotconc[6:]
            else:
                out['lemma'] = annotconc
        self.annotconc, annotconc_saved = '', self.annotconc
        stored = [(os.stat(c).st_mtime, c)
                  for c in glob.glob (self._storeconc_path() + '*.conc')]
        stored.sort(reverse=True)
        del stored[storedconcnumber:]
        self.annotconc = annotconc_saved
        out['LastStoredConcs'] = [{'n': os.path.basename(c)[:-5]} for t,c in stored]
        return out

    def _get_annotconc (self):
        return conclib.get_stored_conc (self._corp(), self.annotconc, 
                                        self._conc_dir)

    def _save_lngroup_log (self, log):
        logf = open (self._storeconc_path() + '.log', 'a')
        flck_ex_lock(logf)
        actionid = hex(hash(tuple(log)))[2:]
        logf.write('Time: %s\n' % time.strftime('%Y-%m-%d %H:%M:%S'))
        logf.write('User: %s\n' % self._user)
        logf.write('Start: #%s#\n' % actionid)
        for toknum, orggrp in log:
            logf.write('%d\t%d\n' % (toknum, orggrp))
        logf.write('End: #%s#\n' % actionid)
        flck_unlock(logf)
        logf.close()
        return actionid

    def undolngroupaction (self, action=''):
        self.format = 'json'
        conc = self._get_annotconc()
        if self._annotconc_locked():
            curr_annotating = self._annotconc_locked()
            if self._user != curr_annotating:
                return {'error': _('Annotation locked by user') + ' %s' % curr_annotating}
        logf = open (self._storeconc_path() + '.log')
        process_tokens = False
        log = []
        for line in logf:
            if line.startswith ('Start: #%s#' % action):
                process_tokens = True
            elif line.startswith ('End: #%s#' % action):
                break
            elif process_tokens:
                toknum, lngrp = map (int, line.split())
                log.append((toknum, conc.set_linegroup_at_pos (toknum, lngrp)))
        actionid = self._save_lngroup_log (log)
        conc.save (self._storeconc_path() + '.conc', 1)
        return {'actionid': actionid, 'count': len(log), 'error': ''}
        
    def setlngroup (self, toknum='', group=0):
        self.format = 'json'
        if not self.annotconc:
            return 'No concordance selected'
        if self._annotconc_locked():
            curr_annotating = self._annotconc_locked()
            if self._user != curr_annotating:
                return {'error': _('Annotation locked by user') + ' %s' % curr_annotating}
        else:
            self._annotconc_lock()
        conc = self._get_annotconc()
        log = []
        for tn in toknum.strip().split():
            tni = int(tn)
            log.append((tni,conc.set_linegroup_at_pos (tni, group)))
        actionid = self._save_lngroup_log (log)
        conc.save (self._storeconc_path() + '.conc', 1)
        lab = conc.labelmap.get (group, group)
        return {'actionid': actionid, 'label': lab, 'count': len(log),
                'error': ''}

    def getlngroupmap(self, annotconc='', corpname=''):
        self.format = 'json'
        ipath = self._storeconc_path() + '.info'
        labelmap = conclib.get_conc_labelmap(ipath)
        labelmap_f = conclib.format_labelmap(labelmap)
        from Cheetah.Template import Template
        import imp
        file, pathname, description = \
            imp.find_module('addlngrouplabel', [self._template_dir])
        module = imp.load_module('addlngrouplabel', file, pathname, description)
        TemplateClass = getattr(module, 'addlngrouplabel')
        result = {'GroupNumbers': labelmap_f, 'error': ''}
        result = TemplateClass(searchList=[result, self])
        return {'map': labelmap, 'html': str(result)}

    def check_annot(self, corpname='', annotconc='', user=''):
        self.format = 'json'
        if not corpname or not annotconc or not user:
            return {'error': _('You must specify corpus, entry and username')}
        self.corpname = corpname
        status = self._annotconc_locked(annotconc)
        return {'locked_by': status if status else ''}

    def _annotconc_lock(self):
        lockf = open(self._storeconc_path() + '.lock', 'w')
        lockf.write(self._user)
        lockf.close()

    def _annotconc_locked(self, lockannot=''):
        lockf = self._finished_annot_file(lockannot)
        if os.path.exists(lockf):
            return open(lockf).read()
        return False

    def _annotconc_unlock(self, lockannot=''):
        lockf = self._finished_annot_file(lockannot)
        if os.path.exists(lockf):
            os.unlink(lockf)

    def _finished_annot_file(self, arg=''):
        if arg:
            return os.path.join(self._conc_dir, self.corpname.split(':')[0],
                    arg + '.lock')
        else:
            return self._storeconc_path() + '.lock'

    def setlngroupglobally (self, group=0):
        self.format = 'json'
        if not self.annotconc:
            return 'No concordance selected'
        if self._annotconc_locked():
            curr_annotating = self._annotconc_locked()
            if self._user != curr_annotating:
                return {'error': _('Annotation locked by user') + ' %s' % curr_annotating}
        else:
            self._annotconc_lock()
        anot = self._get_annotconc()
        conc = self.call_function (conclib.get_conc, (self._corp(),))
        conc.set_linegroup_from_conc (anot)
        # create undo log
        kl = conclib.manatee.KWICLines (conc.corp(), conc.RS (True), '', '', '',
                                        '', '', '')
        log = []
        while kl.nextcontext():
            log.append((kl.get_pos(), kl.get_linegroup()))
        actionid = self._save_lngroup_log (log)
        conc.set_linegroup_globally (group)
        anot.set_linegroup_from_conc (conc)
        anot.save (self._storeconc_path() + '.conc', 1)
        lab = anot.labelmap.get (group, group)
        return {'actionid': actionid, 'label': lab, 'count': len(log)}

    def addlngrouplabel(self, annotconc='', newlabel='', remote=''):
        ipath = self._storeconc_path() + '.info'
        if self._annotconc_locked():
            curr_annotating = self._annotconc_locked()
            if self._user != curr_annotating:
                return {'error': _('Annotation locked by user') + ' %s' % curr_annotating}
        else:
            self._annotconc_lock()
        labelmap = conclib.get_conc_labelmap(ipath)
        if not newlabel:
            firstparts =  [int(x[0][1])
                           for x in [conclib.lngrp_sortcrit(l)
                                     for l in labelmap.values() if l]
                           if x[0][0] == 'n']
            if not firstparts:
                newlabel = '1'
            else:
                newlabel = str (max(firstparts) + 1)

        def _addlngrouplabel_into_map(newlabel, labelmap):
            ids = labelmap.items()
            freeids = range(1, len(ids)+2)
            for n,l in ids:
                try:
                    freeids.remove(n)
                except ValueError:
                    pass
                if l == newlabel:
                    break
            else:
                labelmap[freeids[0]] = newlabel
                open(ipath, 'w').write('\n'.join(['%i\t%s' % (n, l)\
                        for n, l in sorted(labelmap.items())]) + '\n')
        _addlngrouplabel_into_map (newlabel, labelmap)
        try:
            int (newlabel)
            for suff in self.annotconc_num_label_suffixes:
                _addlngrouplabel_into_map (newlabel + suff, labelmap)
        except ValueError:
            pass
        retdict = {'GroupNumbers': conclib.format_labelmap(labelmap),
                'error': ''}
        if remote:
            self.format = 'json'
            retdict['newlabel'] = newlabel
        return retdict


    def dellngrouplabel(self, delpat='', corpname='', annotconc=''):
        self.format = 'json'
        ipath = self._storeconc_path() + '.info'
        if self._annotconc_locked():
            curr_annotating = self._annotconc_locked()
            if self._user != curr_annotating:
                return {'error': _('Annotation locked by user') + ' %s' % curr_annotating}
        labelmap = conclib.get_conc_labelmap(ipath)
        labelmap = conclib.format_labelmap(labelmap)
        ids2del = []
        for item in labelmap:
            if item['Pref'] == delpat:
                ids2del = [i['n'] for i in item['Items']]
        if not ids2del:
            return {'error': _('Label not found')}
        for id in ids2del:
            annot = self._get_annotconc()
            nq = ['s' + annotconc, 'L' + annotconc + ' -' + str(id)]
            conc = self.call_function(conclib.get_conc, (self._corp(),), q=nq)
            conc.sync()
            conc.set_linegroup_globally(0)
            annot.set_linegroup_from_conc(conc)
            annot.save(self._storeconc_path() + '.conc', 1)
        renum_pairs = []
        try:
            int(delpat)
            newlabelmap = []
            for item in labelmap:
                try:
                    ipref = int(item['Pref'])
                except:
                    ipref = 0
                if ipref:
                    if ipref > int(delpat):
                        for i in item['Items']:
                            if '.' in i['lab']:
                                suff = i['lab'].split('.', 1)[1]
                                newlabelmap.append((
                                    i['n'],
                                    str(ipref-1) + '.' + suff
                                ))
                            else:
                                newlabelmap.append((i['n'], str(ipref-1)))
                                renum_pairs.append((
                                    str(ipref) + ':' + str(ipref-1)
                                ))
                    elif ipref < int(delpat):
                        for i in item['Items']:
                            newlabelmap.append((i['n'], i['lab']))
                        renum_pairs.append((str(ipref) + ':' + str(ipref)))
                else:
                    for i in item['Items']:
                        newlabelmap.append((i['n'], i['lab']))
            newlabelmap.sort()
        except:
            newlabelmap = []
            for item in labelmap:
                if item['Pref'] != delpat:
                    for i in item['Items']:
                        newlabelmap.append((i['n'], i['lab']))
            newlabelmap.sort()
        infofile = open(ipath, 'w')
        for i in newlabelmap:
            infofile.write('%i\t%s' % i + '\n')
        infofile.write('\n')
        infofile.close()
        return {'GroupNumbers': {},
                'renumber': '-'.join(renum_pairs),
                'deleted': delpat}


    def renlngrouplabel(self, corpname='', renumber='', annotconc=''):
        self.format = 'json'
        if self._annotconc_locked():
            curr_annotating = self._annotconc_locked()
            if self._user != curr_annotating:
                return {'error': _('Annotation locked by user') + ' %s'\
                        % curr_annotating}
        ipath = self._storeconc_path() + '.info'
        mapdata = {}
        try:
            for item in renumber.split('-'):
                if item.strip():
                    l, r = item.strip().split(':')
                    mapdata[l] = r
        except:
            return {'error': _('Error while renaming labels')}
        infomapf = open(ipath)
        infomap = infomapf.read().split('\n')
        infomapf.close()
        newinfomap = []
        try:
            for item in infomap:
                if item.strip():
                    id, label = item.strip().split('\t')
                    if label in mapdata:
                        newinfomap.append('%s\t%s' % (id, mapdata[label]))
                    elif '.' in label:
                        pref, suff = label.split('.', 1)
                        if pref in mapdata:
                            newinfomap.append('%s\t%s.%s'\
                                    % (id, mapdata[pref], suff))
                        else:
                            newinfomap.append('%s\t%s' % (id, label))
                    else:
                        newinfomap.append('%s\t%s' % (id, label))
        except:
            return {'error': _('Error while renaming labels')}
        infomap = open(ipath, 'w')
        infomap.write('\n'.join(newinfomap) + '\n')
        infomap.close()
        return {'renumbered': renumber}


    def lngroupinfo (self, annotconc=''):
        # XXX opravit poradne! (_conc_dir)
        annotverb = annotconc.split('-')[0]
        try:
            conc = self.call_function (conclib.get_conc, (self._corp(),))
            anot = self._get_annotconc()
            conc.set_linegroup_from_conc (anot)
            labelmap = anot.labelmap
            labelmap[0] = 'Not assigned'
            ids = conclib.manatee.IntVector()
            freqs = conclib.manatee.IntVector()
            conc.get_linegroup_stat (ids, freqs)
        except:
            self.format = 'json'
            return {'LineGroups': [], 'annotverb': annotverb, 'conc': '0'}
        lg = [(labelmap.get(i, '#%s'%i), i, f) for i,f in zip (ids, freqs)]
        lg = [(conclib.lngrp_sortcrit(n),n,i,f) for n,i,f in lg]
        lg.sort()
        lgs = [{'name': n, 'freq': f, 'id': i} for s,n,i,f in lg]
        if self.enable_sadd and self.lemma:
            import wsclust
            ws = self.call_function (wsclust.WSCluster, ())
            lgids = labelmap.keys()
            for lg in lgs:
                c1 = conclib.manatee.Concordance (conc)
                c1.delete_linegroups (str(lg['id']), True)
                lg['Sketch'] = ws.get_small_word_sketch (self.lemma,
                                                         self.lpos, c1)
        return {'LineGroups': lgs, 'annotverb': annotverb}

    minbootscore=0.5
    minbootdiff=0.8
    
    def bootstrap (self, annotconc='', minbootscore=0.5, minbootdiff=0.8):
        import wsclust
        annot = self._get_annotconc()
        ws = self.call_function (wsclust.WSCluster, ())
        ws.build_pos2coll_map()
        log = ws.bootstrap_conc (annot, minbootscore, minbootdiff)
        actionid = self._save_lngroup_log (log)
        annot.save (self._storeconc_path() + '.conc', 1)
        del annot
        self.q = ['s' + annotconc]
        out = self.lngroupinfo (annotconc)
        out['auto_annotated'] = len(log)
        return out

    bootstrap.template = 'lngroupinfo.tmpl'
                
    def rename_annot (self, annotconc='', newname=''):
        if not newname:
            return self.lngroupinfo(annotconc)
        for p in glob.glob (self._storeconc_path(annotconc) + '.*'):
            d, f = os.path.split(p)
            if f.startswith (annotconc):
                os.rename (p, os.path.join(d, newname + f[len(annotconc):]))
        self.annotconc = newname
        self._cookieattrs.append ('annotconc')
        return self.lngroupinfo(newname)

    rename_annot.template = 'lngroupinfo.tmpl'

    def fcs(self, operation='explain', version='', recordPacking='xml',
            extraRequestData='', query='', startRecord='', responsePosition='',
            recordSchema='', maximumRecords='', scanClause='', maximumTerms='',
            stylesheet=''):
        "Federated content search API function (www.clarin.eu/fcs)"

        # default values
        self._headers['Content-Type'] = 'application/xml'
        numberOfRecords = 0
        current_version = 1.2
        maximumRecords_ = 250
        maximumTerms_ = 100
        startRecord_ = 1
        responsePosition_ = 1
        # supported parameters for all operations
        sup_pars = ['operation', 'stylesheet', 'version', 'extraRequestData']
        # implicit result sent to template
        out = {'operation': operation, 'version': current_version,
               'recordPacking': recordPacking, 'result': [],
               'error': False, 'numberOfRecords': numberOfRecords,
               'server_name': self.environ.get('SERVER_NAME', ''),
               'server_port': self.environ.get('SERVER_PORT', '80'),
               'database': self.environ.get('SCRIPT_NAME', '')[1:] + '/fcs',
               'xml_stylesheet': stylesheet,
               }
        fcs_err = None
        try:
            # check version
            if version and current_version < float(version):
                fcs_err = Exception(5, version, 'Unsupported version')

            # check integer parameters
            if maximumRecords != '': 
                try:
                    maximumRecords_ = int(maximumRecords)
                except:
                    fcs_err = Exception(6, 'maximumRecords', 
                                        'Unsupported parameter value')
                if maximumRecords_ < 0:
                    fcs_err = Exception(6, 'maximumRecords', 
                                        'Unsupported parameter value')
                    
            out['maximumRecords'] = maximumRecords_
            if maximumTerms != '':
                try:
                    maximumTerms_ = int(maximumTerms)
                except:
                    fcs_err = Exception(6, 'maximumTerms', 
                                        'Unsupported parameter value')
            out['maximumTerms'] = maximumTerms_
            if startRecord != '':
                try:
                    startRecord_ = int(startRecord)
                except:
                    fcs_err = Exception(6, 'startRecord', 
                                        'Unsupported parameter value')
                if startRecord_ <= 0:
                    fcs_err = Exception(6, 'startRecord',
                                        'Unsupported parameter value')
            out['startRecord'] = startRecord_
            if responsePosition != '':
                try:
                    responsePosition_ = int(responsePosition)
                except:
                    fcs_err = Exception(6, 'responsePosition', 
                                        'Unsupported parameter value')
            out['responsePosition'] = responsePosition_
            
            # set content-type in HTTP header
            if recordPacking == 'string': 
                self._headers['Content-Type'] = 'text/plain'
            elif recordPacking == 'xml':
                self._headers['Content-Type'] = 'application/xml'
            else:
                fcs_err = Exception(71, 'recordPacking', 
                                    'Unsupported record packing')

            # provide info about service
            if operation == 'explain' or not operation:
                sup_pars.append('recordPacking') # other supported parameters
                unsup_pars = list(set(self._url_parameters) - set(sup_pars))
                if unsup_pars:
                    raise Exception(8, unsup_pars[0], 'Unsupported parameter')
                #if extraRequestData:
                #    corpname = extraRequestData
                corp = self._corp()
                out['result'] = corp.get_conf('ATTRLIST').split(',')
                out['numberOfRecords'] = len(out['result'])

            # wordlist for a given attribute
            elif operation == 'scan': 
                # special handling of fcs.resource = root
                if scanClause.startswith('fcs.resource'):
                    out['operation'] = 'fcs.resource'
                    out['resource_info'] = False
                    copts = []
                    if (hasattr(self, 'x-cmd-resource-info') 
                        and getattr(self, 'x-cmd-resource-info') == 'true'):
                        copts = ['DESCRIPTION', 'INFOHREF', 'LANGUAGE']
                        out['resource_info'] = True
                    corps = self.cm.corplist_with_names(copts)
                    out['FCSCorpora'] = corps[:maximumTerms_]
                else:
                    # check supported parameters
                    sup_pars.extend(['scanClause', 'responsePosition',
                                     'maximumTerms'])
                    unsup_pars = list(set(self._url_parameters) - set(sup_pars))
                    if unsup_pars:
                        raise Exception(8, unsup_pars[0], 'Unsupported parameter')
                    #if extraRequestData:
                    #    corpname = extraRequestData
                    out['result'] = conclib.fcs_scan(
                        self.abs_corpname(self.corpname), scanClause,
                        maximumTerms_, responsePosition_)

            # simple concordancer
            elif operation == 'searchRetrieve': 
                # check supported parameters
                sup_pars.extend(['query', 'startRecord', 'maximumRecords', 
                        'recordPacking', 'recordSchema', 'resultSetTTL',
                                 'x-cmd-context'])
                unsup_pars = list(set(self._url_parameters) - set(sup_pars))
                if unsup_pars:
                    raise Exception(8, unsup_pars[0], 'Unsupported parameter')
                if hasattr(self, 'x-cmd-context'):
                    corpname = getattr(self, 'x-cmd-context')
                    if corpname in self.corplist:
                        self._curr_corpus = None
                        self.corpname = corpname
                out['result'] = conclib.fcs_search(self._corp(), query, 
                        maximumRecords_, startRecord_ -1)
                out['numberOfRecords'] = len(out['result'])

            # unsupported operation
            else:
                out['operation'] = 'explain' # show within explain template
                raise Exception(4, 'operation', 'Unsupported operation')
            if fcs_err:
                out['error'] = True
                out['code'], out['details'], out['msg'] = (
                    fcs_err[0], fcs_err[1], fcs_err[2])
            return out

        # catch exception and amend diagnostics in template
        except Exception, e:
            out['error'] = True
            try: # concrete error, catch message from lower levels
                out['code'], out['details'], out['msg'] = e[0], e[1], e[2]
            except: # general error
                out['code'], out['details'] = 1, repr(e)
                out['msg'] = 'General system error'
            return out

    def extract_keywords(self, corpname='', ref_corpname='', simple_n=1,
            attr='lc', stopwords='0', alnum='0', onealpha='1',
            minfreq=5, max_keywords=100, export=None, lang_code='en'):
        retdict = {'corpus': corpname, 'ref_corpus': ref_corpname}
        if export is None:
            self.format = 'json'
        else:
            if not export in ['csv', 'tbx']:
                return {'error': "Requested export format not supported"}
            if export == 'tbx':
                self._headers['Content-Type'] = 'application/xml'
            else:
                self._headers['Content-Type'] = 'text/plain; charset=utf-8'
            self._headers['Content-Disposition'] =\
                    'attachment; filename="ske_export_%s_%s.%s"' %\
                    (corpname, time.strftime('%Y%m%d%H%M%S'), export)
            retdict['format'] = export
        blacklist = []
        if int(stopwords): blacklist = [] # TODO: get stopwords from CA
        if int(alnum): alnum = True
        if not int(onealpha): onealpha = False
        c = self._corp() # both must have the same encoding
        rc = conclib.manatee.Corpus(self.abs_corpname(ref_corpname))
        try:
            result = corplib.subc_keywords_onstr(c, rc, wlminfreq=minfreq,
                    wlmaxitems=max_keywords, simple_n=simple_n,
                    blacklist=blacklist, wlattr=attr,
                    onealpha=onealpha, alnum=alnum)
            retlist = []
            for item in result:
                link = 'view?corpname=%s;q=q[%s="%s"]' % (corpname,attr,item[5])
                ref_link = 'view?corpname=%s;q=q[%s="%s"]' %\
                        (ref_corpname, attr, item[5])
                retlist.append({'item': item[5], 'score': '%.2f' % item[0],
                        'frq1': item[3], 'frq2': item[4], 'link': link,
                        'ref_link': ref_link})
            retdict['keywords'] = retlist
            return retdict
        except Exception, e:
            return {'error': repr(e)}
    extract_keywords.template = 'export_terms.tmpl'

    def extract_terms(self, corpname='', ref_corpname='', simple_n=1,
            max_terms=100, alnum='0', onealpha='1', minfreq=1, stopwords='0',
            export=None, lang_code='en'):
        retdict = {'corpus': corpname, 'ref_corpus': ref_corpname}
        if export is None:
            self.format = 'json'
        else:
            if not export in ['csv', 'tbx']:
                return {'error': "Requested export format not supported"}
            if export == 'tbx':
                self._headers['Content-Type'] = 'application/xml'
            else:
                self._headers['Content-Type'] = 'text/plain'
            self._headers["Content-Disposition"] =\
                    'attachment; filename="ske_export_%s_%s.%s"' %\
                    (corpname, time.strftime('%Y%m%d%H%M%S'), export)
            retdict['format'] = export
        if int(alnum): alnum = True
        if not int(onealpha): onealpha = False
        blacklist = []
        if int(stopwords): blacklist = [] # TODO: get stopwords from CA
        c = self._corp() # both must have the same encoding
        rc = conclib.manatee.Corpus(self.abs_corpname(ref_corpname))
        try:
            retlist = []
            result = corplib.ws_keywords(c, rc, wlminfreq=minfreq,
                    simple_n=simple_n, wlattr='ws_terms',
                    alnum=alnum, onealpha=onealpha, blacklist=blacklist,
                    wlmaxitems=max_terms*10) # TODO: store only mw terms
            for item in result[:max_terms]:
                sitem = item[5].split('\t')
                link = 'view?corpname=%s;q=t%s' % (corpname, sitem[3])
                ref_link = 'view?corpname=%s;q=t%s' % (ref_corpname, sitem[4])
                retlist.append({'item': sitem[2].replace('_', ' '),
                'score': '%.2f' % item[0], 'frq1': item[3], 'frq2': item[4],
                        'link': link, 'ref_link': ref_link})
            retdict['terms'] = retlist
            return retdict
        except Exception, e:
            return {'error': repr(e)}
    extract_terms.template = 'export_terms.tmpl'

    def translate_kwic(self, bim_corpname='', data=''):
        self.format = 'json'
        result = conclib.translate_kwic(self.abs_corpname(self.corpname),
                                        self.abs_corpname(bim_corpname), data)
        return {'toknum2words': result[1], 'dict': result[0], 'corpus': bim_corpname}

    def biterms(self, corpname='', l2_corpname=''):
        biterms = corplib.get_biterms(self.abs_corpname(corpname), l2_corpname)
        if '/' in corpname:
            l2_corpname = corpname.rsplit('/', 1)[0] + '/' + l2_corpname
        return {'Biterms': biterms, 'aligned_corpname': l2_corpname, 'new_maxitems': 1000}
    biterms.template = 'wordlist.tmpl'

    def save_biterms(self, corpname='', l2_corpname='', format='txt'):
        biterms = corplib.get_biterms(self.abs_corpname(corpname), l2_corpname)
        if format == 'tbx':
            self._headers['Content-Type'] = 'application/xml'
        else:
            self._headers['Content-Type'] = 'text/plain; charset=utf-8'
        self._headers['Content-Disposition'] =\
                'attachment; filename="ske_biterms_%s_%s_%s.%s"' %\
                (corpname, l2_corpname, time.strftime('%Y%m%d%H%M%S'), format)
        return {'biterms': biterms}
    save_biterms.template = 'export_terms.tmpl'

    def trends_form(self):
        methods = {
                'mkts_all': _('Mann-Kendall, Theil-Sen (all)'),
                'mkts_nonzero': _('Mann-Kendall, Theil-Sen (non zero)'),
                'linreg_all': _('Linear regression (all)'),
                'linreg_nonzero': _('Linear regression (non zero)')
        }
        c = self._corp()
        path = c.get_conf('PATH')
        periods = [(p, c.get_conf(p + '.LABEL') or p)\
                for p in c.get_conf('DIACHRONIC').split(',') if p]
        diattrs = [{'n': at, 'label': c.get_conf(at + '.LABEL') or at}\
                for at in c.get_conf('ATTRLIST').split(',') if at]
        return {'periods': periods, 'diattrs': diattrs, 'methods': methods}
    add_vars['trends_form'] = ['LastSubcorp']

    def trends(self, structattr='', trends_attr='word', usesubcorp='',
            trends_method='mkts_all', trends_re='', trends_sort_by='t',
            filter_capitalized=1, trends_maxp=0.01, filter_nonwords=1,
            trends_minfreq=5):
        subcpath = getattr(self._corp(), 'spath', '')
        result, samples = corplib.get_trends(self._corp(), structattr,
                trends_attr, subcpath, trends_re, trends_sort_by,
                filter_nonwords, filter_capitalized, trends_method, trends_maxp,
                trends_minfreq)
        if result is None: # trends not computed
            missing_norms = False
            missing_freqs = False
            if usesubcorp:
                missing_norms = not os.path.exists(subcpath[:-5] + '.' +\
                        structattr + '.norm')
                missing_freqs = not os.path.exists(subcpath[:-5] + '.' +\
                        trends_attr + '.frq')
            else:
                missing_norms = not os.path.exists(os.path.join(self._corp().get_conf('PATH'),\
                        structattr + '.norm'))
                missing_norms = not os.path.exists(os.path.join(self._corp().get_conf('PATH'),\
                        structattr + '.norm'))
            if missing_freqs:
                return corplib.compute_freqfile(self._user, self._corp(),
                        trends_attr, 'frq', self.get_url())
            if missing_norms:
                return corplib.compute_norms(self._corp(), self._user,\
                        structattr.split('.')[0], subcpath, self.get_url())
            return corplib.compute_trends(self._corp(), self._user,
                    structattr, trends_attr, trends_method, subcpath, self.get_url())
        if result is False: # computing
            return {'processing': 1, 'result': []}
        if not result: # empty result
            return {'error': _("No data available for these parameters")}
        attr_label = self._corp().get_conf(trends_attr + '.LABEL') or trends_attr
        return {'result': result, 'samples': samples, 'structattr': structattr,
                'trends_attr': trends_attr, 'usesubcorp': usesubcorp,
                'trends_attr_label': attr_label,
                'trends_method': trends_method, 'trends_sort_by':trends_sort_by}
