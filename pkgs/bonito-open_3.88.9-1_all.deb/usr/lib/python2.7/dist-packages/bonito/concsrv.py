# Copyright (c) 2014-2015  Milos Jakubicek

import socket, sys, re, manatee, time
from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from urllib import unquote
from httplib import HTTPConnection
from pyconc import PyConc

server_host = 'localhost'

class ConcRequestHandler (BaseHTTPRequestHandler):

    def do_GET (self):
        if "?" in self.path:
            command, params = self.path[1:].split("?")
        else:
            command, params = self.path[1:], None
        q = {}
        if params:
            params = re.split ('[;&]', params)
            for p in params:
                p = p.split("=")
                if len(p) > 1:
                    q[p[0]] = unquote(p[1])
                else:
                    q[p[0]] = ""
        if not hasattr (self, command):
            self.send_error (404)
            return
        getattr (self, command) (**q)

    def conc_info (self):
        concsize = finished = fullsize = 0
        if self.server.conc:
            finished = self.server.conc.finished()
            concsize = self.server.conc.size()
            fullsize = self.server.conc.fullsize()
        self.send_response (200)
        self.end_headers()
        self.wfile.write ("%d\n%d\n%d\n" % (finished, concsize, fullsize))
        self.wfile.close()

    def send_conc (self, minsize=None):
        csize = self.server.conc.size()
        conc = self.server.conc
        if not conc:
            self.send_error (404, "Not yet started")
            return
        minsize = int(minsize)
        if minsize == -1 and not conc.finished():
            self.send_error (404, "Not yet finished")
            return
        if csize < minsize:
            self.send_error (404, "Only %d items available" % csize)
            return
        self.send_response (200, "Sending %d items" % csize)
        self.send_header('Content-type', 'application/octet-stream')
        self.end_headers()
        conc.save (self.wfile.fileno(), False, True) # partial
        self.wfile.close()
        
class ConcServer (HTTPServer):

    def __init__(self, logfile):
        HTTPServer.__init__ (self, (server_host, 0), ConcRequestHandler)
        self.conc = None
        self.logfile = open(logfile, "w", 0) # unbuffered => always flush
        sys.stderr = self.logfile
        self.logfile.write("Started\n")
    
def get_server_conc_sizes (server_port):
    conn = HTTPConnection (server_host, server_port, timeout=60)
    conn.request ("GET", "/conc_info")
    response = conn.getresponse()
    return map(int, response.read().split("\n")[:3])

def get_server_conc (corp, server_port, minsize):
    sleeptime = 1
    conn = HTTPConnection (server_host, server_port, timeout=60)
    while True:
        conn.request ("GET", "/send_conc?minsize=%d" % minsize)
        conn.sock.setblocking(1)
        response = conn.getresponse()
        if response.status == 200:
            try:
                fileno = response.fileno()
            except AttributeError:
                fileno = response.fp.fileno()
            conc = PyConc (corp, 'l', fileno)
            conc.port = server_port
            return conc
        elif response.status != 404: # less than minsize
            raise Exception ("Concordance failed")
        response.read() # flush
        time.sleep(sleeptime * 0.1)
        sleeptime += 1

