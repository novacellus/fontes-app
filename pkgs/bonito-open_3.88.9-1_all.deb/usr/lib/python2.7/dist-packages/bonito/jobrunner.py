#!/usr/bin/python

# Copyright (c) 2014-2015  Milos Jakubicek

"""JobRunner: simple job management module

== General ==

* client/server model
* communication over HTTP
* minimal security

== Security ==

* anybody can connect to server, no authentication and very limited authorization
* client can run any command on server
* server runs anything that it has system permissions to
* admin must ensure that server does not get malicious requests

== Authorization ==

The jobserver performs authorization only if a jobid is given.
In this case the required action is allowed only if the job
belongs to the user or the user is superuser.

Where no jobid is given, the caller is responsible to perform
authorization, namely for following actions:
new_job, list_user_jobs, list_all_jobs

== Example ==

=== Server side ===

run ./jobserver.py -d /var/run/jobs -n localhost -p 8333 -l /var/log/jobs.log

=== Client side ===

jc = JobClient (job_server, job_port, job_dir, admin_email)
jobid = jc.request ("new_job", {"user" : "someuser", "cmd" : "echo x", "corpus" : "bnc",
                                "url" : "http://localhost/bonito/somewhere", "desc" : "Test"})
jobs = jc.request ("list_all_jobs", {"finished" : finished})
import json
jobs = json.loads(jobs[0])
"""

from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from httplib import BadStatusLine
from subprocess import Popen, PIPE, call, CalledProcessError
from urllib import unquote_plus, urlencode
from urllib2 import urlopen
from datetime import datetime
from glob import glob
from socket import setdefaulttimeout, getfqdn
from email.mime.text import MIMEText
import sys, os, re, signal, signalfd, json, hashlib, shlex, time, smtplib
from version import version

try:
    from subprocess import check_output
except ImportError:
    def check_output(*popenargs, **kwargs): # from Python 2.7
        if 'stdout' in kwargs:
            raise ValueError('stdout argument not allowed, will be overridden.')
        process = Popen(stdout=PIPE, *popenargs, **kwargs)
        output, unused_err = process.communicate()
        retcode = process.poll()
        if retcode:
            cmd = kwargs.get("args")
            if cmd is None:
                cmd = popenargs[0]
            raise CalledProcessError(retcode, cmd, output=output)
        return output

server_name = 'localhost'
server_port = 8333
job_dir = '/var/lib/ske/jobs'
job_log = "%s/jobs.log" % job_dir
admin_email = 'root@localhost'

sig_desc = dict((getattr(signal, n), n) \
           for n in dir(signal) if n.startswith('SIG') and '_' not in n )

job_attrs = ["actions", "cgroup", "cpu", "esttime", "ionice", "mem", "nice",
             "pid", "progress", "retcode", "starttime", "status", "stderr",
             "stdout", "user", "cmd", "srv", "desc", "corpus", "url", "notify"]

class JobServer (BaseHTTPRequestHandler):
    """Server class

    Run this module to start the server, see ./jobrunner.py --help
    """
    log_file = None

    def do_GET (self):
        """Main GET method handler"""
        try:
            command, params = self.path[1:].split("?")
        except:
            self.send_error (404)
            return
        if params:
            params = re.split ('[;&]', params)
        q = {}
        for p in params:
            p = p.split("=")
            if len(p) > 1:
                q[p[0]] = unquote_plus(p[1])
            else:
                q[p[0]] = ""
        if not hasattr (self, command):
            self.send_error (400)
            return
        if q.has_key("version") and q['version'] != version:
            JobServer.log_event (0,
                         'Version incompatibility detected: %s vs. %s, exiting'
                         % (q['version'], version))
            self.server.wannadie = True
            return
        if q.has_key("jobid") and \
           not self.has_access (q["user"], q["superuser"], q["jobid"], command):
            self.send_error (401)
            return
        args = getattr (self, command).func_code.co_varnames
        if q.has_key("user") and not "user" in args:
            del q["user"]
        if q.has_key("superuser") and not "superuser" in args:
            del q["superuser"]
        if q.has_key("user_email") and not "user_email" in args:
            del q["user_email"]
        if q.has_key("version") and not "version" in args:
            del q["version"]
        result = getattr (self, command) (**q)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Content-type', 'text/plain; charset=UTF-8')
        self.end_headers()
        self.wfile.write(result)

    def has_access (self, user, superuser, jobid, command=''):
        """Returns True iff superuser is True or user is owner of jobid
        or command just asks for progress"""
        try:
            job_user = JobServer.job_info (jobid)["user"]
        except IOError: #may have finished
            return True
        if superuser == "True" or job_user == user or command == 'job_progress':
            return True
        return False

    @staticmethod
    def is_pid_alive (pid):
        try:
            os.kill(pid, 0)
        except OSError:
            return False
        return True

    def new_job (self, user=None, cmd=None, desc=None, corpus=None, url=None):
        """Starts a new job
        Args:
            user: user name (string)
            cmd: command to be run (string)
            desc: user-friendly job description (string)
            corpus: corpus name (string)
            url: URL where the user can review result of this job
        Returns:
            A unique jobid to the command to be run.
        """
        fd = None
        md5 = hashlib.md5()
        cmd_list = shlex.split (cmd)
        md5.update (json.dumps(sorted(cmd_list)))
        jobid = md5.hexdigest()
        fname = "%s/%s" % (job_dir, jobid)
        open_flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        while not fd:
            try:
                fd = os.open (fname + ".pid", open_flags, 0644)
            except OSError: # already running?
                pid = int(open (fname + ".pid").readline().split("\t")[1])
                if JobServer.is_pid_alive (pid):
                    self.send_response (202, "Already running")
                    return jobid
                os.unlink (fname + ".pid")
        pidf = os.fdopen (fd, "w")
        outf = open(fname + ".out", "w")
        errf = open(fname + ".err", "w")
        signalfd.sigprocmask (signalfd.SIG_BLOCK, [signal.SIGCHLD])
        proc = Popen (cmd_list, stdout=outf, stderr=errf, close_fds=True,
                      preexec_fn=os.setsid)
        outf.close()
        errf.close()
        starttime = str(datetime.now())
        params = ["pid\t" + str(proc.pid), "starttime\t" + starttime,
                  "user\t" + user, "cmd\t" + cmd, "srv\t" + getfqdn(),
                  "desc\t" + desc,
                  "corpus\t" + corpus, "url\t" + url, "notify\t", "retcode\t"]
        pidf.write ("\n".join (params) + "\n")
        pidf.close()
        msg = "started (%s)" % ",".join (map(lambda x: x.replace("\t","="), params))
        jobid = fname.split("/")[-1]
        JobServer.log_event (jobid, msg)
        signalfd.sigprocmask (signalfd.SIG_UNBLOCK, [signal.SIGCHLD])
        self.send_response (200, "Job started")
        return jobid

    def job_change (self, jobid=None, key=None, value=None, user_email=''):
        """Change a job's attribute
        Args:
            jobid: ID of the job (string)
            key: job attribute to change (string)
            value: new value of the key (string)
        Returns:
            value
        """
        if not key or not jobid:
            self.send_error (400)
            return
        pidfile = job_dir + "/" + jobid + ".pid"
        cmd = ''
        if key == 'notify' and user_email:
            cmd = r"sed -i 's/\(notify\t.*\)/\1 %s /' %s" % (user_email, pidfile)
        elif key == 'notifyrm' and user_email:
            cmd = r"sed -i 's/\(notify\t.*\) %s \(.*\)/\1 \2/' %s" % (user_email, pidfile)
        elif key not in ('notify', 'notifyrm'):
            cmd = r"sed -i 's/\(%s\t\).*/\1%s/' %s" % (key, value, pidfile)
        try:
            if cmd:
               check_output (cmd, shell=True)
        except CalledProcessError: # may have finished meanwhile
            pass
        JobServer.log_event (jobid, "change of key '%s' to value '%s' (success)" % (key, value))
        self.send_response (200, "Value changed")
        return value

    @staticmethod
    def cleanup_job (job_id):
        pidfile = "%s/%s" % (job_dir, job_id)
        try: os.unlink (pidfile + ".pid")
        except: pass
        try: os.unlink (pidfile + ".out")
        except: pass
        try: os.unlink (pidfile + ".err")
        except: pass

    def signal_job (self, jobid=None, signame=None):
        """Send signal to a job
        Args:
            jobid: ID of the job (string)
            signame: name of the signal, one of ["KILL", "STOP", "CONT", "PURGE"]
                     except for the last one the semantic is that of the relevant
                     POSIX signal, "PURGE" means remove a stalled job record
        """
        if not jobid or not signame:
            self.send_error (400)
            return
        if signame not in ["KILL", "STOP", "CONT", "PURGE"]:
            self.send_error (400, "Invalid signal")
            return
        pid = self.jobid2pid (jobid)
        if not pid:
            self.send_error (410, "No such job")
            return
        if signame == "PURGE":
            JobServer.cleanup_job (jobid)
            JobServer.log_event (jobid, "purge %s (success)" % signame)
            self.send_response (200, "Job purged")
            return "Job purged"
        else:
            try:
                os.killpg (pid, getattr(signal, "SIG%s" % signame))
            except OSError:
                self.send_error (500, "Failed to signal")
                JobServer.log_event (jobid, "signal %s (failed)" % signame)
                return
            JobServer.log_event (jobid, "signal %s (success)" % signame)
            self.send_response (200, "Job signaled")
            return "Job signaled"

    def nice_job (self, jobid=None, nice=None):
        """Change nice (CPU priority) level
        Args:
            jobid: ID of the job (string)
            nice: one of ["min", "max", "minus", "plus"]
                  min/max sets nice to minimum/maximum
                  minus/plus lower/higher the nice level relatively to its current value
        """
        if not jobid or not nice:
            self.send_error (400)
            return
        if nice not in ["min", "max", "minus", "plus"]:
            self.send_error (400, "Invalid nice")
            return
        pid = self.jobid2pid (jobid)
        if not pid:
            self.send_error (410, "No such job")
            return
        curr_nice = int(JobServer.job_info (jobid)["nice"])
        nice_max = 19
        nice_min = -20
        if nice == "minus" and curr_nice < nice_max:
            nice = curr_nice + 1
        elif nice == "plus" and curr_nice > nice_min:
            nice = curr_nice - 1
        elif nice == "min" and curr_nice < nice_max:
            nice = nice_max
        elif nice == "max" and curr_nice > nice_min:
            nice = nice_min
        else:
            self.send_response(304, "Nothing to do")
            return "Nothing to do"
        retcode = call (("renice %d -p %d" % (nice, pid)).split())
        if retcode > 0:
            self.send_error (500, "Failed to nice")
            JobServer.log_event (jobid, "nice %d (failed)" % nice)
            return
        JobServer.log_event (jobid, "nice %s (success)" % nice)
        self.send_response (200, "Job niced")
        return "Job niced"

    def ionice_job (self, jobid=None, ionice=None):
        """Change ionice (I/O priority) level
        Args:
            jobid: ID of the job (string)
            nice: one of ["min", "max", "minus", "plus"]
                  min/max sets nice to minimum/maximum
                  minus/plus lower/higher the nice level relatively to its current value
        """
        if not jobid or not ionice:
            self.send_error (400)
            return
        if ionice not in ["min", "max", "minus", "plus"]:
            self.send_error (400, "Invalid ionice")
            return
        pid = self.jobid2pid (jobid)
        if not pid:
            self.send_error (410, "No such job")
            return
        curr_ionice = JobServer.job_info (jobid)["ionice"].split()
        if ionice == "plus" and curr_ionice[0] == "idle":
            ionice = "-c 2 -n 7"
        elif ionice == "plus" and curr_ionice[0] == "best-effort" \
                              and int(curr_ionice[2]) > 0:
            ionice = "-c 2 -n %d" % (int(curr_ionice[2]) - 1)
        elif ionice == "minus" and curr_ionice[0] not in ["idle","best-effort"]:
            ionice = "-c 2 -n 0"
        elif ionice == "minus" and curr_ionice[0] == "best-effort":
            if int(curr_ionice[2]) < 7:
                ionice = "-c 2 -n %d" % (int(curr_ionice[2]) + 1)
            else:
                ionice = "-c 3"
        elif ionice == "max":
            ionice = "-c 2 -n 0"
        elif ionice == "min":
            ionice = "-c 3"
        else:
            self.send_response(204, "Nothing to do")
            return "Nothing to do"
        retcode = call (("ionice %s" % ionice).split(), stderr=open('/dev/null', 'w'))
        if retcode > 0:
            self.send_error (500, "Failed to ionice")
            JobServer.log_event (jobid, "ionice %s (failed)" % ionice)
            return
        JobServer.log_event (jobid, "ionice %s (success)" % ionice)
        self.send_response (200, "Job ioniced")
        return "Job ioniced"

    @staticmethod
    def job_info (jobid=None, jobfile=None):
        """Retrieve information about a job
           Args:
                jobid: ID of the job (string)
                jobfile: used to retrieve jobid iff no jobid is given
        """
        if not jobid:
            jobf = open (jobfile)
            jobid = os.path.basename(jobfile).split(".")[0]
        else:
            jobf = open("%s/%s.pid" % (job_dir, jobid))
        job = jobf.read().split("\n")
        d = {"jobid" : jobid}
        for line in job:
            if not line:
                continue
            attr, value = line.split("\t")
            d[attr] = value
        d.update((x, "") for x in job_attrs if x not in d)
        if not d.has_key("pid"):
            d.update((x, "err") for x in job_attrs)
            return d
        # finished jobs:
        if jobf.name.endswith(".done"):
            if d["retcode"] == "0" or d["retcode"] == "":
                d["status"] = ('-', 'Completed')
            else:
                d["status"] = ("err", 'Failed')
                try:
                    d["stdout"] = open ("%s/%s.out" % (job_dir, jobid)).read()
                    d["stderr"] = open ("%s/%s.err" % (job_dir, jobid)).read()
                except:
                    d["stdout"] = d["stderr"] = "Not available"
            end = datetime.fromtimestamp (os.path.getctime (jobf.name))
            start = datetime.strptime(d["starttime"][:-7],"%Y-%m-%d %H:%M:%S")
            d["esttime"] = str(end - start)[:-7]
            d["progress"] = "100"
            d["nice"] = d["cgroup"] = d["cpu"] = d["mem"] = d["ionice"] \
                      = d["actions"] = "N/A"
            return d
        # unfinished jobs:
        cmd = "sed '$a\\' %s/%s.err | tr '\r' '\n' | tac | grep -o -m 1 '[0-9\.]\+ *%%' | sed 's/ *%%//'" % (job_dir, jobid)
        try:
            progress = check_output (cmd, shell=True)[:-1]
        except CalledProcessError:
            progress = "0"
        d["progress"] = progress or "0"
        try:
            ps = check_output (['ps','-o','s=,nice=,cgroup=,%cpu=,%mem=',
                                d["pid"]])
        except CalledProcessError:
            ps = ""
        if not ps:
            ps = "dead ? ? ? ?"
        ps = ps.split()
        helps = {'dead': 'The job is dead but pidfile was not removed',
                 'S': 'Interruptible sleep',
                 'D': 'Uninterruptible sleep',
                 'R': 'Running',
                 'T': 'Stopped',
                 'Z': 'Zombie'}
        d["status"] = (ps[0], helps.get(ps[0], "?"))
        if ps[0] == 'dead':
            d["actions"] = ['PURGE']
        elif ps[0] == 'T': # stopped
            d["actions"] = ['KILL', 'CONT']
        else:
            d["actions"] = ['KILL', 'STOP']
        d["nice"] = ps[1]
        d["cgroup"] = ps[2]
        d["cpu"] = ps[3]
        d["mem"] = ps[4]
        try:
            io = check_output (['ionice', '-p', d["pid"]], stderr=open('/dev/null', 'w'))
        except CalledProcessError:
            io = "?"
        d["ionice"] = io.strip()
        try:
            progress = int(d["progress"])
            if progress <= 0:
                raise ValueError
            now = datetime.now()
            start = now.strptime(d["starttime"][:-7],"%Y-%m-%d %H:%M:%S")
            delta = now - start
            est_whole = delta * 100 / progress
            d["esttime"] = str(est_whole - delta)[:-7]
        except ValueError:
            d["esttime"] = "N/A"
        return d

    @staticmethod
    def list_jobs (jobfiles):
        """Retrieve job info for a list of jobs
        Args:
            jobfiles: list of job IDs
        Returns:
            List of job information in JSON
        """
        jobs = []
        for jobf in jobfiles:
            try:
                jobs.append (JobServer.job_info (jobfile=jobf))
            except IOError: # some jobs may finished meanwhile
                pass
        return json.dumps(jobs)

    def job_progress (self, jobid=None, user_email=''):
        """Retrieve job info for a particular job
        Args:
            jobid: ID of the job (string)
            user_email: address of the user who is asking
        Returns:
            List of non-sensitive job information in JSON
        """
        self.send_response (200, "Listing done")
        ji = None
        try:
            ji = JobServer.job_info (jobfile="%s/%s.pid" % (job_dir, jobid))
        except IOError: # not running
            jobfile_done = "%s/%s.pid.done" % (job_dir, jobid)
            if not os.path.isfile(jobfile_done): # no record
                return json.dumps([])
            ji = JobServer.job_info (jobfile=jobfile_done)
            if 'err' not in ji['status']: # finished successfully
                return json.dumps([])
        # now, either computation in progress, or failed
        if user_email:
            notifyme = (' %s ' % user_email) in ji['notify']
        else:
            notifyme = False
        ji_final = { 'progress': ji['progress'],
                     'jobid': ji['jobid'],
                     'notifyme': notifyme,
                     'esttime': ji['esttime'],
                     'status': ji['status'],
                   }
        return json.dumps([ji_final])

    def list_user_jobs (self, user=None, finished=False):
        """Retrieve job info for all user jobs
        Args:
            user: user name (string)
            finished: a string, if "true", returns finished jobs as well
        Returns:
            List of job information in JSON
        """
        jobfiles = glob (job_dir + "/" + "*.pid")
        if finished == 'true':
            jobfiles += glob (job_dir + "/" + "*.pid.done")
        grep = Popen("xargs grep -l '^user	%s$'" % user, shell=True,
                     stdin=PIPE, stdout=PIPE)
        jobfiles, _err = grep.communicate("\n".join(jobfiles))
        jobfiles = jobfiles.split("\n")[:-1]
        self.send_response (200, "Listing done")
        return JobServer.list_jobs (jobfiles)

    def list_all_jobs (self, finished=False):
        """Retrieve job info for all jobs
        Args:
            finished: a string, if "true", returns finished jobs as well
        Returns:
            List of job information in JSON
        """
        jobfiles = glob (job_dir + "/" + "*.pid")
        if finished == 'true':
            jobfiles += glob (job_dir + "/" + "*.pid.done")
        self.send_response (200, "Listing done")
        return JobServer.list_jobs (jobfiles)

    def jobid2pid (self, jobid):
        """Retrieve PID for a given job
        Args:
            jobid: ID of the job (string)
        Returns:
            PID of the job's process (int)
        """
        try:
            pidfile = open(job_dir + "/" + jobid + ".pid")
            return int(pidfile.readline().split("\t")[1][:-1])
        except:
            return None

    @staticmethod
    def log_event (jobid, message):
        """Log message to the server's log file"""
        if not JobServer.log_file:
            JobServer.log_file = open(job_log, "a", 0)
        JobServer.log_file.write ("JOBSERVER - - [%s] \"JOB %s\": %s" % (datetime.now().strftime("%d/%b/%Y %H:%M:%S"), jobid, message))
        JobServer.log_file.write ("\n")
        JobServer.log_file.flush()

    @staticmethod
    def get_smtp (jobid):
        """Return smtplib.SMTP (or None + write into log, if not possible)"""
        try:
            return smtplib.SMTP('localhost')
        except:
            JobServer.log_event (jobid, "Failed to initialize SMTP")
            return None

    @staticmethod
    def job_finished (signum, frame):
        """SIGCHLD handler for finished jobs"""
        succ_msg = """
Automatic notification from Sketch Engine:\n
Your background computation\n'%s'
has finished successfully. You can access the results at the link below:\n\n%s"""
        fail_msg = """
Automatic notification from Sketch Engine:\n
Your background computation\n'%s'
has failed. We are currently working on fixing the problem. Please try again later or contact support."""
        admin_fail_msg = """
Dear administrator,\nthe background computation\n'%s'
in Sketch Engine has failed.
Id: %s
User: %s (%s was/were notified)
Server: %s
Command: %s
Return code: %d
stdout: %s\n
stderr: %s\n"""
        try:
            pid, retcode = os.waitpid (-1, os.WNOHANG)
            while (pid, retcode) != (0, 0):
                pidfile = Popen("grep -sl 'pid	%d' %s/*.pid"
                                % (pid, job_dir), stdout=PIPE, shell=True).communicate()[0][:-1]
                if pidfile and not os.WIFSTOPPED (retcode) and not os.WIFCONTINUED (retcode):
                    msg = "finished with return code %d" % retcode
                    if os.WIFSIGNALED (retcode):
                        msg += ", because it was signaled %s" % sig_desc[os.WTERMSIG (retcode)]
                    jobid = os.path.basename(pidfile).split(".")[0]
                    JobServer.log_event (jobid, msg)
                    out = JobServer.list_jobs([pidfile])
                    out = json.loads (out)[0]
                    pidf = open(pidfile, "a")
                    pidf.write ("retcode\t%d\n" % retcode)
                    pidf.close()
                    pidbase = pidfile[:-4]
                    os.rename (pidfile, pidfile + ".done")
                    if retcode == 0:
                        os.unlink (pidbase + ".err")
                        os.unlink (pidbase + ".out")
                        if out["notify"]:
                            s = JobServer.get_smtp (jobid)
                        if out["notify"] and s:
                            msg = MIMEText(succ_msg % (out["desc"], out["url"]))
                            msg['From'] = admin_email
                            msg['Subject'] = "Your computation in Sketch Engine has finished"
                            for notif in out["notify"].split():
                                msg['To'] = notif
                                s.sendmail(admin_email, [notif], msg.as_string())
                                del msg['To']
                            s.quit()
                            JobServer.log_event (jobid, "notified completion to user(s): %s" % out["notify"])
                    else:
                        err = open (pidbase + ".err", "a")
                        err.write ("\n===== EXIT INFORMATION =====\n")
                        err.write ("Return code: %d\n" % retcode)
                        if os.WIFSIGNALED (retcode):
                            err.write ("Was signaled: %s\n" % sig_desc[os.WTERMSIG (retcode)])
                        else:
                            err.write ("Was signaled: no\n")
                        err.close()
                        s = JobServer.get_smtp (jobid)
                        if out["notify"] and s:
                            msg = MIMEText(fail_msg % out["desc"])
                            msg['From'] = admin_email
                            msg['Subject'] = "Your computation in Sketch Engine has failed"
                            for notif in out["notify"].split():
                                msg['To'] = notif
                                s.sendmail(admin_email, [notif], msg.as_string())
                                del msg['To']
                            JobServer.log_event (jobid, "notified failure to user(s): %s" % out["notify"])
                        if s:
                            msg = MIMEText(admin_fail_msg
                                           % (out["desc"], out["jobid"],
                                              out["user"],
                                              out["notify"] or "no e-mail",
                                              out["srv"], out["cmd"],
                                              retcode,
                                              open(pidbase + ".out").read(),
                                              open(pidbase + ".err").read()))
                            msg['From'] = admin_email
                            msg['To'] = admin_email
                            msg['Subject'] = "Computation '%s' in Sketch Engine has failed" % out["desc"]
                            s.sendmail(admin_email, admin_email, msg.as_string())
                            JobServer.log_event (jobid, "notified failure to admins at %s" % admin_email)
                            s.quit()
                pid, retcode = os.waitpid (-1, os.WNOHANG)
        except OSError:  # [Errno 10] No child processes
            pass

class JobClient():

    def __init__ (self, name, port, jobdir, email, user_email='', user='',
                  superuser=False):
        """Creates a new client
        Args:
            name: server host name (string)
            port: server port (int)
            jobdir: job directory (string)
            email: admin-email (string)
            user_email: user email (string)
            user: user name (string)
            superuser: whether the user is a superuser (bool)

        jobdir and email are used to start the server by the client if it is not running

        Returns:
            new JobClient instance
        """

        self.name = name
        self.port = port
        self.jobdir = jobdir
        self.admin_email = email
        self.user_email = user_email
        self.user = user
        self.superuser = superuser

    def start_server (self):
        """Starts the job server"""
        jobserver = Popen ([sys.executable, __file__, "-n", self.name, "-p",
                            str(self.port), "-d", self.jobdir, "-l",
                            self.jobdir + "/jobs.log", "-e", self.admin_email],
                           stdin=PIPE, stdout=PIPE, stderr=PIPE)
        # wait to read "STARTED\n" confirming server is up and bound to its port
        ll = jobserver.stdout.readline()
        if not ll.startswith('STARTED'):
            raise RuntimeError('Failed to run jobserver on port %s'
                               % self.port, [ll])
        # must be here so that Apache CGI does not hang on open stdin/stdout/stderr
        jobserver.stdin.close()
        jobserver.stdout.close()
        jobserver.stderr.close()

    def request (self, cmd, params):
        """Performs a request to the job server
        Args:
            cmd: command to the job server (string), see list of JobServer methods
                 for possible values
            params: dictionary of GET parameters for the command
        Returns:
            output of the requested JobServer's method
        """
        if type(params) == type({}):
            params.update({'user_email': self.user_email,
                           'user': self.user,
                           'superuser': self.superuser,
                          })
            params = urlencode (params)
        else:
            params += ';user_email=%s;user=%s;superuser=%s' % (self.user_email,
                                                     self.user, self.superuser)
        url = "http://%s:%d/%s?%s" % (self.name, self.port, cmd, params)
        try:
            setdefaulttimeout (None)
            if self.name == 'localhost': # check version of running jobserver
                url += ';version=' + version
            f = urlopen (url)
        except (IOError, BadStatusLine) as e:
            self.start_server ()
            setdefaulttimeout (10)
            f = urlopen (url)
        return f.read(), f.getcode()

def usage (jobdir, name, port, email):
    print """Usage: %s [ OPTIONS ]
Options may be:
-h, --help       Show this help
-d, --dir DIR    Use DIR as job directory, defaults to %s
-n, --name NAME  Server name, defaults to %s
-p, --port PORT  Server port, defaults to %d
-e, --email EMAIL  Server admin e-mail, defaults to %s
-l, --log FILE   Logfile, defaults to stderr""" % \
(sys.argv[0], jobdir, name, port, email)

if __name__ == '__main__':
    from getopt import getopt
    opts, _ = getopt (sys.argv[1:], "hn:p:d:l:e:", ["help", "name=", "port=", "dir=", "log=", "email="])
    for o, a in opts:
        if o in ("-h", "--help"):
            usage(job_dir, server_name, server_port, admin_email)
            sys.exit(0)
        elif o in ("-n", "--name"):
            server_name = a
        elif o in ("-p", "--port"):
            server_port = int(a)
        elif o in ("-d", "--dir"):
            job_dir = a
        elif o in ("-e", "--email"):
            admin_email = a
        elif o in ("-l", "--log"):
            job_log = a
    httpd = HTTPServer((server_name, server_port), JobServer)
    signal.signal (signal.SIGCHLD, JobServer.job_finished)
    sys.stderr = open(job_log, "a", 0)
    sys.stdout.write ("STARTED\n")
    sys.stdout.flush()
    sys.stdout = sys.stderr
    httpd.wannadie = False
    while not httpd.wannadie:
        try: httpd.handle_request()
        except: continue
