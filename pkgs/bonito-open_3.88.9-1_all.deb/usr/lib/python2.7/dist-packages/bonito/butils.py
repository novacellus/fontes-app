# Copyright (c) 2003-2015  Milos Jakubicek, Jan Busta, Vojtech Kovar, Vit Baisa

import re

try:
    import fcntl
except ImportError:
    try:
        import msvcrt
    except ImportError:
        # no locking available, dummy defs
        def flck_no_op (file):
            pass
        flck_sh_lock = flck_ex_lock = flck_unlock = flck_no_op
    else:
        # XXX substitute with win32file
        # see e.g. http://code.activestate.com/recipes/65203/
        # Windows: msvcrt.locking
        def flck_sh_lock (file):
            file.seek (0)
            msvcrt.locking (file.fileno(), msvcrt.LK_LOCK, 1)
        flck_ex_lock = flck_sh_lock
        def flck_unlock (file):
            file.seek (0)
            msvcrt.locking (file.fileno(), msvcrt.LK_UNLCK, 1)
else:
    # UNIX: fcntl.lockf
    def flck_sh_lock (file):
        fcntl.lockf (file, fcntl.LOCK_SH, 0, 0, 0)
    def flck_ex_lock (file):
        fcntl.lockf (file, fcntl.LOCK_EX, 0, 0, 0)
    def flck_unlock (file):
        fcntl.lockf (file, fcntl.LOCK_UN, 0, 0, 0)

escape_regexp = re.compile(r'[][.*+{}?()|\\"$^]')
def escape (s):
    """ Escape CQL attribute value to protect it against RE evaluation """
    return escape_regexp.sub(r'\\\g<0>', s)

escape_nonwild_regexp = re.compile(r'[][+{}?()|"$^]')
def escape_nonwild (s):
    """ Escape CQL attribute value except . and * """
    return escape_nonwild_regexp.sub(r'\\\g<0>', s)

try:
    from prctl import set_proctitle
except ImportError:
    def set_proctitle(x): pass

# borrowed from stackoverflow, question #2301789
def reverse_readline(filename, buf_size=8192, maxlines=1000):
    """a generator that returns the lines of a file in reverse order"""
    from os import SEEK_END
    with open(filename) as fh:
        segment = None
        offset = 0
        fh.seek(0, SEEK_END)
        total_size = remaining_size = fh.tell()
        counter = 0
        while remaining_size > 0 and counter < maxlines:
            offset = min(total_size, offset + buf_size)
            fh.seek(-offset, SEEK_END)
            buffer = fh.read(min(remaining_size, buf_size))
            remaining_size -= buf_size
            lines = buffer.split('\n')
            if segment is not None:
                if buffer[-1] is not '\n':
                    lines[-1] += segment
                else:
                    yield segment
                counter += 1
            segment = lines[0]
            for index in range(len(lines) - 1, 0, -1):
                counter += 1
                yield lines[index]
        if counter < maxlines:
            yield segment

def get_last_corpcheck(logfile):
    """extracts corpcheck log from manatee log file"""
    check_re = re.compile('(Warning|Error|Fatal error): (.*)')
    lines = []
    header_found = False
    for line in reverse_readline(logfile):
        if line.startswith('Checking corpus sanity disabled'):
            return [('N/A', line.strip())]
        if line.startswith('Checking corpus'):
            header_found = True
            break
        s = check_re.match(line)
        if s:
            lines.append((s.group(1), s.group(2)))
    if not header_found:
        return False
    return lines
