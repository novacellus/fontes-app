# Copyright (c) 2003-2015  Pavel Rychly, Vojtech Kovar, Milos Jakubicek, Vit Baisa

import os, sys, cgi, re
from types import MethodType, TypeType, StringType, DictType, ListType, TupleType, UnicodeType
from inspect import isclass
import Cookie
import codecs
import imp
from urllib import urlencode, quote_plus
import simplejson
import gettext

# According to Cheetag changelog, Cheetah should use Unicode in its internals since version 2.2.0
# If you experience it also in any previous version, change it here:
# NOTE: YOU MUST RECOMPILE TEMPLATES WHEN SWITCHING FROM A VERSION < 2.2.0 TO A VERSION >= 2.2.0 OR VICE VERSA
try:
    from Cheetah import VersionTuple
    major, minor, bugfix, _status, _statusNr = VersionTuple
except ImportError:
    from Cheetah import Version
    try: major, minor, bugfix = map(int, Version.split("."))
    except ValueError: major, minor, bugfix = 0, 0, 0 # 2.0rc8 ;-)
if (major, minor, bugfix) >= (2, 2, 0):
    has_cheetah_unicode_internals = True
else:
    has_cheetah_unicode_internals = False

def replace_dot_error_handler (err):
    return u'.', err.end

codecs.register_error ('replacedot', replace_dot_error_handler)

def function_defaults (fun):
    defs = {}
    if isclass (fun):
        fun = fun.__init__
    try:
        dl = fun.func_defaults or ()
    except AttributeError:
        return {}
    nl = fun.func_code.co_varnames
    for a,v in zip (nl [fun.func_code.co_argcount - len(dl):], dl):
        defs [a] = v
    return defs

def correct_types (args, defaults, del_nondef=0, selector=0, safe=1):
    corr_func = {type(0): int, type(0.0): float, ListType: lambda x: [x]}
    for full_k, v in args.items():
        if selector:
            k = full_k.split(':')[-1] # filter out selector
        else:
            k = full_k
        if (safe and k.startswith('_')) \
                                or type (defaults.get (k,None)) is MethodType:
            del args[full_k]
        elif defaults.has_key(k):
            default_type = type (defaults[k])
            if default_type is not ListType and type(v) is ListType:
                args[k] = v = v[-1]
            if type(v) is not default_type:
                try:
                    args[full_k] = corr_func[default_type](v)
                except: pass
        else:
            if del_nondef:
                del args[full_k]
    return args

def choose_selector (args, selector):
    selector += ':'
    s = len (selector)
    for n,v in [(n[s:],v) for n,v in args.items() if n.startswith (selector)]:
        args [n] = v

def q_help(page, lang): # html code for context help
   return "<a onclick=\"window.open('https://www.sketchengine.co.uk/help.cgi?page=" \
   + page + ";lang=" + lang \
   + "','help','width=500,height=300,scrollbars=yes')\" class=\"help\">[?]</a>"


class CheetahResponseFile:
    def __init__(self, outfile):
        if has_cheetah_unicode_internals:
            outfile = codecs.getwriter("utf-8")(outfile)
        self.outfile = outfile
    def response(self):
        return self.outfile

class CGIPublisher:

    _headers = {'Content-Type': 'text/html; charset=utf-8'}
    _keep_blank_values = 0
    _cookieattrs = []
    _template_dir = u'cmpltmpl/'
    _locale_dir = u'locale/'
    _tmp_dir = u'/tmp'
    _url_parameters = []
    exceptmethod = None
    _request_method = 'GET'
    debug = None
    precompile_template = 1
    format = u''
    uilang = u''
    reload = 0
    _has_access = 1
    _anonymous = 0
    _authenticated = 0
    _login_address = u'' # e.g. 'https://beta.sketchengine.co.uk/login'
    _sessionid = u''
    _user_ip = u''


    def __init__ (self):
        self._request_method = os.environ['REQUEST_METHOD']

        # correct _locale_dir
        if not os.path.isdir (self._locale_dir):
            p = os.path.join (os.path.dirname (__file__), self._locale_dir)
            if os.path.isdir (p):
                self._locale_dir = p
            else:
                # This will set the system default locale directory as a side-effect:
                gettext.install(domain='ske', unicode=True)
                # hereby we retrieve the system default locale directory back:
                self._locale_dir = gettext.bindtextdomain('ske')

        # correct _template_dir
        if not os.path.isdir (self._template_dir):
            self._template_dir = imp.find_module('cmpltmpl')[1]
        
    def is_template (self, template):
        try:
            imp.find_module(template, [self._template_dir])
            return True
        except ImportError:
            return False

    def preprocess_values(self, form):
        pass

    def _setup_user(self, user=None, corpname=''):
        pass

    def self_encoding(self):
        return 'iso-8859-1'

    def _set_defaults (self):
        pass

    def _correct_parameters (self):
        pass

    def add_undefined (self, result, methodname):
        pass

    def _add_globals(self, result):
        ppath = self.environ.get ('REQUEST_URI','/')
        try:
            ppath = ppath [:ppath.index ('?')]
            ppath = ppath [:ppath.rindex ('/')]
        except ValueError:
            pass
        result ['hrefbase'] = self.environ.get ('HTTP_HOST', '') + ppath

    def call_method (self, method, args, named_args):
        na = named_args.copy()
        correct_types (na, function_defaults (method), 1, safe=0)
        return apply (method, args[1:], na)
        
    def call_function (self, func, args, **named_args):
        na = self.clone_self(safe=0)
        na.update (named_args)
        correct_types (na, function_defaults (func), 1, safe=0)
        return apply (func, args, na)

    def clone_self (self, safe=1):
        na = {}
        for a in dir(self) + dir(self.__class__):
            if (not a.startswith('_') or not safe) \
                    and not callable (getattr (self, a)):
                na[a] = getattr (self, a)
        return na

    def parse_parameters (self, selectorname=None, cookies=None, 
                          environ=os.environ, post_fp=None):
        self.environ = environ
        named_args = {}
        if cookies:
            named_args.update(cookies)
        else:
            try:
                ck = Cookie.SimpleCookie(self.environ.get('HTTP_COOKIE',''))
            except Cookie.CookieError: # hack because of GA cookies
                ck = Cookie.SimpleCookie(';'.join(
                      [x for x in self.environ.get('HTTP_COOKIE','').split(';')
                           if ':' not in x.split('=')[0]]))
            for k,v in ck.items():
                named_args[k] = v.value
                if k == 'sessionid': self._sessionid = v.value
        form = cgi.FieldStorage(keep_blank_values=self._keep_blank_values,
                                environ=self.environ, fp=post_fp)
        self.preprocess_values(form) # values needed before recoding
        self._user_ip = os.getenv ('REMOTE_ADDR', '-')
        self._setup_user(self.corpname)
        if form.has_key ('json'):
            json_data = simplejson.loads(form.getvalue('json').decode('utf8'))
            named_args.update(json_data)
        for k in form.keys():
            self._url_parameters.append(k)
            # must remove empty values, this should be achieved by
            # keep_blank_values=0, but it does not work for POST requests
            if len(form.getvalue(k)) > 0 and not self._keep_blank_values:
                named_args[str(k)] = self.recode_input(form.getvalue(k))
            if k == 'attachment':
                named_args[str(k)] = (form[k].filename, form[k].file)
        na = named_args.copy()
        correct_types (na, self.clone_self())
        if selectorname:
            choose_selector (self.__dict__, getattr (self, selectorname))
        self._set_defaults()
        self.__dict__.update (na)
        self._correct_parameters()
        return named_args

    def set_localisation(self):
        "set up localisation"
        import __builtin__
        os.environ['LANG'] = self.get_uilang()
        os.environ['LC_ALL'] = self.get_uilang()
        CGIPublisher.l10n = gettext.translation('ske', self._locale_dir,
                                                                 fallback=True)
        try: CGIPublisher.l10n._catalog[''] = ''
        except AttributeError: pass
        if has_cheetah_unicode_internals:
            # install _() as a builtin for ugettext() - Unicode gettext()
            __builtin__.__dict__['_'] = CGIPublisher.l10n.ugettext
        else: # install _() as a builtin for gettext()
            __builtin__.__dict__['_'] = CGIPublisher.l10n.gettext

    redirect_template = """
        <html><head><meta http-equiv="REFRESH" content="0;url=%s"></head></html>
        """
    error_template = """
        <html><body>%s</body></html>
        """

    def run_unprotected (self, path=None, selectorname=None, outf=sys.stdout):
        if path is None:
            path = os.getenv('PATH_INFO','').strip().split('/')[1:]
        if len (path) is 0 or path[0] is '':
            path = ['methods']
        else:
            if path[0].startswith ('_'):
                self._headers['Status'] = '403 Forbidden'
                self.output_headers()
                raise Exception('access denied')
        try:
            named_args = self.parse_parameters (selectorname)
        except Exception, e:
            self._headers['Status'] = '500 Internal Server Error'
            self.output_headers()
            raise Exception(e)
        self.set_localisation()
        if self._has_access or path[0] == 'feedback':
            methodname, tmpl, result = self.process_method (path[0], path,
                                                                    named_args)
        else: # redirect to login or raise error
            methodname = path[0]
            tmpl = self.error_template
            if (not self._authenticated or self._anonymous) \
                                                    and not self._ca_api_info:
                self._headers['Status'] = '401 Unauthorized'
                result = self.redirect_template % self._login_address
            else:
                self._headers['Status'] = '403 Forbidden'
                result = self.error_template \
                             % _('You are not allowed to use this corpus.')
        self.output_headers()
        self.output_result (methodname, tmpl, result, outf)

    def process_method (self, methodname, pos_args, named_args):
        if getattr (self, 'reload', None):
            self.reload = None
            if methodname != 'subcorp':
                reload_template = methodname + '_form'
                if self.is_template (reload_template):
                    return self.process_method(reload_template,
                                               pos_args, named_args)

        if not hasattr (self, methodname):
            if methodname.endswith ('_form'):
                return (methodname[:-5], methodname + '.tmpl', {})
            else:
                self._headers['Status'] = '400 Bad Request'
                self.output_headers()
                raise Exception('unknown method: "%s"' % methodname)
        method = getattr (self, methodname)
        try:
            return (methodname,
                    getattr (method, 'template', methodname + '.tmpl'),
                    self.call_method (method, pos_args, named_args))
        except Exception, e:
            if self.format == 'json':
                return (methodname, None,
                        {'error': self.rec_recode(e.message, 'utf-8', True)})
            if not self.exceptmethod and self.is_template(methodname +'_form'):
                self.exceptmethod = methodname + '_form'
            if self.debug or not self.exceptmethod:
                raise
            if getattr(e, 'message', ''):
                if type(e.message) is StringType:
                    e.message = e.message.decode('utf-8')
                self.error = self.rec_recode(e.message, enc='utf-8')
            else:
                self.error = str(e).decode('utf-8')
            em, self.exceptmethod = self.exceptmethod, None
            return self.process_method (em, pos_args, named_args)

    def get_uilang(self):
        if self.uilang:
            return self.uilang
        return ''

    def recode_input(self, x, decode=1):
        if type(x) is ListType:
            return [self.recode_input(v, decode) for v in x]
        if decode:
            try: x = x.decode('utf-8')
            except UnicodeDecodeError: x = x.decode('latin1')
        return x

    def rec_recode(self, x, enc='', utf8_out=False):
        if has_cheetah_unicode_internals and not utf8_out:
            return x
        if not enc: enc = self.self_encoding()
        if isinstance(x, TupleType) or isinstance(x, ListType):
            return [self.rec_recode(e, enc, utf8_out) for e in x]
        if isinstance(x, DictType):
            d = {}
            for key, value in x.iteritems():
                if key in ['corp_full_name', 'Corplist']: d[key] = value
                else: d[key] = self.rec_recode(value, enc, utf8_out)
            return d
        elif type(x) is StringType:
            return unicode(x, enc, 'replace').encode('utf-8')
        elif type(x) is UnicodeType:
            return x.encode('utf-8')
        return x

    def urlencode (self, key_val_pairs):
        """recode values of key-value pairs and run urlencode from urllib"""
        enc = self.self_encoding()
        if type(key_val_pairs) is UnicodeType: # urllib.quote does not support unicode
            key_val_pairs = key_val_pairs.encode("utf-8")
        if type(key_val_pairs) is StringType:
            # mapping strings
            return quote_plus(key_val_pairs)
        return urlencode ([(k, self.rec_recode(v, enc, utf8_out=True)) 
                                                for (k,v) in key_val_pairs])

    _cookies = []

    def output_headers (self, outf=sys.stdout):
        # Cookies
        cookies = Cookie.SimpleCookie()
        for k in self._cookieattrs: 
            if self.__dict__.has_key (k):
                cookies [k] = self.__dict__[k]
                cookies [k]['expires'] = 5*24*3600
        for ck in self._cookies: # cookies from CA
            cookies[ck['key']] = ck['value']
            for k, v in ck.get('attributes', {}).items():
                cookies[ck['key']][k] = v
        if cookies and outf:
            outf.write(cookies.output() + '\n')

        # Headers
        if self.format == 'json':
            self._headers['Content-Type'] = 'application/json'
        if outf:
            for k,v in self._headers.items():
                outf.write('%s: %s\n' % (k, v))
            outf.write('\n')
        return cookies, self._headers

    def output_result (self, methodname, template, result, outf=sys.stdout,
                                                       return_template=False):
        from Cheetah.Template import Template

        # JSON
        if self.format == 'json':
            simplejson.dump(result, outf)

        # Template
        elif type(result) is DictType:
            self.set_localisation() # in case run_protected has not ran (CA)
            self._add_globals (result)
            self.add_undefined (result, methodname)
            result = self.rec_recode(result)
            for attr in dir(self): # recoding self
                setattr(self, attr, self.rec_recode(getattr(self, attr)))
            
            if template.endswith('.tmpl'):
                class_name = template[:-5] # appropriate module import
                file, pathname, description = \
                    imp.find_module(class_name, [self._template_dir])
                module = imp.load_module(class_name, file, pathname, description)

                TemplateClass = getattr(module, class_name)

                result = TemplateClass(searchList=[result, self])
            else:
                result = Template(template, searchList=[result, self])
            if return_template: return result
            result.respond(CheetahResponseFile(outf))
        
        # Image
        elif hasattr(result, '__module__') and result.__module__ == 'Image':
            img_type = self._headers['Content-Type'].split('/')[1]
            result.save(outf, img_type)

        # Other (string) - e.g. AJAX
        else:
            if isinstance(result, unicode):
                outf = codecs.getwriter("utf-8")(outf)
            outf.write(result)


    def run (self, path=None):
        try:
            self.run_unprotected (path)
        except:
            cgi.print_exception()

    def methods (self, params=0):
        """list all methods with a doc string"""
        methodlist = []
        cldict = self.__class__.__dict__
        for m in [x for x in cldict.keys()
                  if not x.startswith('_') and hasattr (cldict[x], '__doc__') \
                  and callable (cldict[x])]:
            mm = {'name': m, 'doc': cldict[m].__doc__}
            if params:
                try:
                    mm['Params'] = [{'name':v}
                                    for v in cldict[m].func_code.co_varnames[1:]]
                except AttributeError: pass
            methodlist.append (mm)
        return {'List': methodlist}
    
    methods.template = """<html><head><title>Methods</title></head><body><ul>
        #for $l in $List
           <li><b>$l.name</b>(
               #set $sep = ''
               #for $p in $l.get('Params',[])
                  $sep$p.name
                  #set $sep = ', '
               #end for
                )<br>$l.doc<br>
        #end for
        </ul></body></html>
        """
