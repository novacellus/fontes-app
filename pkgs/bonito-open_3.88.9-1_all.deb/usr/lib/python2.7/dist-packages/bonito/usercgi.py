# Copyright (c) 2004-2015  Pavel Rychly, Vojtech Kovar, Milos Jakubicek, Vit Baisa

import CGIPublisher
import os
from jobrunner import JobClient
 
def load_opt_file (options, filepath):
    if not os.path.isfile (filepath):
        return
    for line in open (filepath).readlines():
        if line[0] == '#':
            continue
        a,v = line.split ('\t', 1)
        options [a.strip()] = v.strip('\n').decode('utf8')


class UserCGI (CGIPublisher.CGIPublisher):
    _ca_user_info = u''
    _ca_api_info = u''
    _ca_languages = []
    _options_dir = u''
    _email = u''
    _default_user = u'defaults'
    _superuser = False
    _admin_email = ''
    _job_server = 'localhost'
    _job_port = 8333
    _job_dir = u''
    _data_dir = u''
    # list of usernames granted access to job management
    _superusers = []
    attrs2save = []
    display_adsense = False

    def __init__ (self, user=None):
        CGIPublisher.CGIPublisher.__init__ (self)
        self._user = user
        if not self._admin_email:
            self._admin_email = os.environ.get("SERVER_ADMIN", "root@localhost")
        if not self._job_dir:
            self._job_dir = os.path.dirname (os.path.abspath(self._cache_dir))\
                                             + "/jobs"
        if not os.path.isdir(self._job_dir):
            os.makedirs(self._job_dir)
        self._job = JobClient (self._job_server, self._job_port, self._job_dir,\
                               self._admin_email, self._email, self._user,
                               self._superuser)

    def _user_defaults (self, user):
        pass

    def _get_ca_corpnames(self, language='', with_ws=0):
        import urllib2, simplejson
        request = urllib2.Request(self._ca_corp_info
                % (self._sessionid, self._user_ip, language, with_ws))
        file = urllib2.urlopen(request)
        data = file.read()
        return simplejson.loads(data)

    def _get_ca_languages(self):
        import urllib2, simplejson
        request = urllib2.Request(self._ca_lang_info)
        file = urllib2.urlopen(request)
        data = file.read()
        self._ca_languages = simplejson.loads(data)

    api_key = ''
    url_username = ''

    def _get_ca_auth_request(self, corpname):
        import urllib2
        if self._ca_user_info and corpname:
            return urllib2.Request(self._ca_user_info
                                  % (self._sessionid, self._user_ip, corpname))
        elif self._ca_api_info:
            usr = self.url_username
            passwd = self.api_key
            return urllib2.Request(self._ca_api_info % (usr, passwd, corpname))
        else:
            return urllib2.Request(self._ca_user_access
                                   % (self._sessionid, self._user_ip))

    def _get_ca_user_info(self, corpname=''):
        import urllib, urllib2, simplejson
        if self._login_address:
            self._login_address += '/?next=' + urllib.quote_plus(
                                                os.getenv ('REQUEST_URI', '-'))
        request = self._get_ca_auth_request(corpname)
        no_tries = 0
        while True:
            try:
                file = urllib2.urlopen(request)
                break
            except urllib2.HTTPError:
                import time
                if no_tries <= 5: time.sleep(3); no_tries += 1
                else: raise
        data = file.read()
        file.close()
        user_info = simplejson.loads(data)
        if user_info.has_key('error'): self._has_access = False
            # set attributes (incl. these starting '_') and correct types
        corr_func = {type(0): int, type(0.0): float,
                     type([]): lambda x: x if type(x) == type([]) else [x]}
        for k, v in user_info.items():
            try: setattr (self, k, corr_func[type(getattr(self, k))](v))
            except: setattr (self, k, v)
        if self._user: self._job.user = self._user = str(self._user)
        if self._email.startswith('sso_'): self._email = '' # SSO has fake email
        if self._email: self._job.user_email = self._email
        self._job.superuser = self._superuser

    def _setup_user (self, corpname=''):
        if self._ca_user_info or self._ca_api_info:
            self._has_access = 0
            self._get_ca_user_info(corpname)
        if hasattr(self, '_ca_lang_info'):
            self._get_ca_languages()
        if not self._user:
            self._job.user = self._user = os.getenv ('REMOTE_USER','-')
            if self._user == '-':
                self._user = self._default_user
        if self._user in self._superusers: # not needed when CA
            self._job.superuser = self._superuser = True
        user = self._user
        options = {}
        load_opt_file (options, os.path.join (self._options_dir,
                                              self._default_user))
        if user is not self._default_user:
            load_opt_file (options, os.path.join (self._options_dir, user))
        CGIPublisher.correct_types (options, self.clone_self(), selector=1)
        self._user_defaults (user)
        self.__dict__.update (options)

    def _save_options (self, optlist=[], selector=''):
        if selector:
            tosave = [(selector + ':' + opt, self.__dict__[opt])
                           for opt in optlist if self.__dict__.has_key (opt)]
        else:
            tosave = [(opt, self.__dict__[opt]) for opt in optlist
                           if self.__dict__.has_key (opt)]
        opt_filepath = os.path.join (self._options_dir, self._user)
        options = {}
        load_opt_file(options, opt_filepath)
        options.update(tosave)

        opt_lines = []
        for k, v in options.iteritems():
            if isinstance(v, unicode): v = v.encode('utf8')
            opt_lines.append(str(k) + '\t' + str(v))
        opt_lines.sort()
        if not os.path.isdir(self._options_dir):
            os.makedirs(self._options_dir)
        opt_file = open(opt_filepath, 'w')
        opt_file.write('\n'.join(opt_lines))
        opt_file.close()

    def reset_options(self):
        opt_filepath = os.path.join(self._options_dir, self._user)
        if os.path.exists(opt_filepath):
            open(opt_filepath, 'w').close()
        return _('Options have been reset for %s')

    def save_global_attrs(self):
        options = [a for a in self.attrs2save if not a.startswith('_')]
        self._save_options(options, '')
        return _('Selected options successfully saved')

    def send_mail(self, subject, msg, sender='', recipient='', attachment='', sender_name=''):
        import smtplib
        import urllib
        if not recipient:
            recipient = self._email
        if not sender:
            sender = self._admin_email
        server = smtplib.SMTP('localhost')
        mhead = ("From: \"%s\" <%s>\nTo: %s\nSubject: %s\nContent-Type: text/plain; charset=utf-8\n\n") %\
                (sender_name, sender, recipient, subject)
        msg = urllib.unquote(msg).encode('utf-8')
        if attachment[0]:
            from email.MIMEMultipart import MIMEMultipart
            from email.MIMEBase import MIMEBase
            from email.MIMEText import MIMEText
            from email.Utils import formatdate
            from email import Encoders
            m = MIMEMultipart()
            m['From'] = '"%s" <%s>' % (sender_name, sender)
            m['To'] = recipient
            m['Date'] = formatdate(localtime=True)
            m['Subject'] = subject
            m['Content-Type'] = 'text/html; charset=utf-8'
            m.attach(MIMEText(msg))
            part = MIMEBase('application', "octet-stream")
            part.set_payload(attachment[1].read())
            Encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="%s"'%\
                    attachment[0])
            m.attach(part)
            server.sendmail(sender, recipient, m.as_string())
        else:
            server.sendmail(sender, recipient, mhead.encode('utf-8') + msg)
        server.quit()

    def feedback(self, feedback_url='', navigator='', feedback_corpname='',
            feedback_text='', attachment=('', None), feedback_fullname='',
            feedback_error='', feedback_email=''):
        if not navigator:
            return ""
        import time
        msg = "%s\n\nUSER: %s (%s)\nEMAIL: %s\nCORPUS: %s\nERR: %s\nURL: %s\nBROWSER: %s"%\
                (feedback_text, self._user,
                feedback_fullname or getattr(self, '_ca_full_name', ''),
                self._email or feedback_email or 'anonymous@anonym.com',
                feedback_corpname, feedback_error, feedback_url, navigator)
        self.send_mail('SkE feedback from %s, %s' %\
                (getattr(self, '_ca_full_name', self._user),
                time.strftime('%Y-%m-%d %H:%M:%S')), msg,
                self._email or feedback_email or 'anonymous@anonym.com',
                self._admin_email, attachment, getattr(self, '_ca_full_name', self._user))
        return _('Your feedback has been sent to %s. Thank you for your time!'\
                 % self._admin_email)

    def jobs (self, finished=False):
        jobs = self._job.request ("list_user_jobs",
                                  {"user" : self._user, "finished" : finished})
        import json
        jobs = json.loads(jobs[0])
        out = {'jobs': jobs, 'view_type' : 'user', 'no_corpus_show': 1}
        return out

    def all_jobs (self, finished=False):
        if not self._superuser:
            raise Exception('access denied: User "%s" is not a superuser' \
                             % self._user)
        jobs = self._job.request ("list_all_jobs",
                                  {"user" : self._user, "finished" : finished})
        import json
        jobs = json.loads(jobs[0])
        out = {'jobs': jobs, 'view_type' : 'all', 'no_corpus_show': 1}
        return out
    all_jobs.template = "jobs.tmpl"

    def jobproxy (self, task=""):
        qs = self.__dict__["environ"]["QUERY_STRING"]
        disallowed_tasks = ["new_job", "list_all_jobs", "list_user_jobs"]
        if task in disallowed_tasks:
            raise Exception('access denied: task not allowed for proxy')
        import re, json
        qs = re.sub ("task=[^;&]+[&;]?", "", qs)
        qs = re.sub ("ajax=[^;&]+[&;]?", "", qs)
        self.format = 'json'
        jr = self._job.request(task, qs)
        return {'signal': jr[0], 'code': jr[1]}

    def get_url (self):
        scheme = self.environ.get ("REQUEST_SCHEME")
        if not scheme:
            scheme = self.environ.get ("HTTPS") and "https" or "http"
        return "%s://%s%s" % (scheme, self.environ["SERVER_NAME"],
                                      self.environ["REQUEST_URI"])
