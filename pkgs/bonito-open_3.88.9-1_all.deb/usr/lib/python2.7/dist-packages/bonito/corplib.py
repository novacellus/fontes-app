#!/usr/bin/python
# Copyright (c) 2003-2016  Pavel Rychly, Vojtech Kovar, Milos Jakubicek, Milos Husak, Vit Baisa

import manatee
import os, sys, glob
import re
import time
from types import UnicodeType
try:
    from hashlib import md5
except ImportError:
    from md5 import new as md5
from butils import *

DEFAULTMAXLISTSIZE = 22

class CorpusManager:
    def __init__ (self, corplist=['susanne'], subcpath=[], gdexpath=[],
                  jobclient=None, abs_corpname=None):
        self.corplist = corplist
        self.subcpath = subcpath
        self.gdexdict = dict(gdexpath)
        self.missing_subc_error = u''
        self.jobclient = jobclient
        self.obsolete_subcorp = ''
        self.obsolete_has_subcdef = False
        self.abs_corpname = abs_corpname

    def default_subcpath(self, corp):
        if type(corp) in (type(''), type(u'')): corp = self.get_Corpus (corp)
        if corp.get_conf('SUBCBASE'): return corp.get_conf('SUBCBASE')
        cpath = corp.get_conf('PATH')
        return os.path.join(cpath, 'subcorp')

    def get_Corpus (self, corpname, subcname='', complement=False):
        if ':' in corpname:
            corpname, subcname = corpname.split(':',1)
        corp = manatee.Corpus (self.abs_corpname(corpname))
        manatee.setEncoding(corp.get_conf('ENCODING'))
        corp.corpname = str(corpname) # never unicode (paths)
        corp.cm = self
        dsubcpath = self.default_subcpath (corp)
        if subcname:
            for sp in self.subcpath + [dsubcpath]:
                if sp == dsubcpath:
                    spath = os.path.join (sp, subcname + '.subc')
                else:
                    spath = os.path.join (sp, corpname, subcname + '.subc')
                if type(spath) == unicode:
                    spath = spath.encode("utf-8")
                if os.path.isfile (spath):
                    sctime = time.gmtime(os.stat(spath).st_mtime)
                    dafile = os.path.join(corp.get_conf('PATH'),
                            corp.get_conf('DEFAULTATTR') + '.lex')
                    if sctime < time.gmtime(os.stat(dafile).st_mtime):
                        self.obsolete_subcorp = subcname
                        if os.path.exists(spath + 'def'):
                            self.obsolete_has_subcdef = True
                    subc = manatee.SubCorpus (corp, spath, complement)
                    subc.corp = corp
                    subc.spath = spath
                    try: open(spath[:-4] + 'used', 'w')
                    except: pass
                    subc.corpname = str(corpname) # never unicode (paths)
                    subc.subcname = subcname
                    subc.cm = self
                    compl = complement and '1' or ''
                    subc.subchash = md5(open(spath).read()+compl).digest()
                    return subc
            self.missing_subc_error = _('Subcorpus "%s" not found') % subcname
            return corp
        else:
            return corp

    def corpattrlist (self, corp):
        return dict (corpconf_pairs (corp, label)).get (item)

    def corplist_with_names (self, conf_options=[]):
        """conf_options 
           -- list of options to be extracted from corpus configure files"""
        #subc = manatee.StrVector()
        #for s in self.subcpath:
        #    manatee.find_subcorpora (s, subc)
        #corpora = self.corplist + map (None, subc)
        #corpora.sort()
        cl = []
        for c in self.corplist:
            try:
                mc = manatee.Corpus(self.abs_corpname(c))
                cinf = {'id': c,
                        'name': mc.get_conf('NAME') or c}
                cinf.update([(o.lower(), mc.get_conf(o)) for o in conf_options])
            except:
                cinf = {'id': c, 'name': c}
            cl.append (cinf)
        cl.sort()
        return cl

    def subcorpora (self, corpname):
        # we must encode for glob.glob otherwise it fails for non-ascii files
        enc_corpname = corpname.encode("utf-8")
        subc = []
        for sp in self.subcpath:
            subc += glob.glob (os.path.join (sp, enc_corpname, '*.subc'))
        subc += glob.glob (os.path.join (
                self.default_subcpath (corpname).encode("utf-8"), '*.subc'))
        return sorted(subc)

    def subcorp_names (self, corpname):
        return [{'n': os.path.splitext(os.path.basename (s))[0]}
                for s in self.subcorpora (corpname)]

    def last_subcorp_names (self, corpname, maxitems=25):
        
        subc = [os.path.isfile(c[:-4]+'used') and c[:-4]+'used' or c
                for c in self.subcorpora (corpname)]
        subc = [(os.stat(c).st_ctime, c) for c in subc]
        subc.sort(reverse=True)
        return [{'n': os.path.splitext(os.path.basename (s))[0]}
                for t,s in subc[:maxitems]]

    def find_same_subcorp_file (self, subcorp, wanted_infix,
                                 wanted_suff=('arf','frq', 'docf')):
        basedir = os.path.dirname (self.subcpath[0].rstrip('/'))
        scpath = subcorp.spath
        scsize = os.path.getsize (scpath)
        scdata = open(scpath).read()

        for f in glob.glob (basedir + '/*/%s/*.subc' % subcorp.corpname):
            if f == scpath: continue
            if os.path.getsize(f) != scsize: continue
            if [s for s in wanted_suff
                if not os.path.isfile(f[:-4] + wanted_infix + '.' + s)]:
                continue
            # now, f has same size and all wanted suffixes exist
            if open(f).read() == scdata:
                return f
        return None

re_alnum = re.compile('^\w+$', re.UNICODE)
re_alnum_terms = re.compile('^[\w_\- ]+$', re.UNICODE)
re_onealpha = re.compile('^.*(?![\d])\w.*$', re.UNICODE)

def corpconf_pairs (corp, label):
    val = corp.get_conf(label)
    if len(val) > 2:
        val = val[1:].split(val[0])
    else:
        val = ''
    return [val[i:i+2] for i in range (0, len(val), 2)]

def get_alt_lposes(corp, lemma, attr):
    ret = []
    alt_lposes = [lpos[1] for lpos in corpconf_pairs (corp, 'WSPOSLIST')]
    for alt_lpos in alt_lposes:
        s = lemma + alt_lpos
        a_id = attr.str2id (s)
        if a_id != -1:
            ret.append((attr.freq(a_id), a_id, s, alt_lpos))
    return sorted(ret, reverse=True)

def ws_subc_freq (wmap3, corp):
    if hasattr(corp, 'spath'):
        fs = wmap3.poss()
        fs2 = corp.filter_fstream(fs)
        return corp.count_rest(fs2)
    return wmap3.getcnt()

def ws_find_triple (wmap1, id1, id2, id3):
    # WARNING: ids has to be bigger than the current position in wmap
    if not wmap1.findid (id1): return None
    wmap2 = wmap1.nextlevel()
    if not wmap2.findid (id2): return None
    wmap3 = wmap2.nextlevel()
    if not wmap3.findid (id3): return None
    return wmap3


def ngrams(corp, words=[], wlattr='', wlpat='', wlminfreq=5, wlmaxitems=100,
          wlsort='', blacklist=[], include_nonwords=0, wlmaxfreq=0, ngrams_n=2,
          ngrams_max_n=2):
    import re
    from operator import itemgetter
    tmpcache_size = 1000000
    ngr_data_filename = str(corp.get_conf('PATH') + wlattr + '.ngr')
    try: ngr = manatee.NGram(ngr_data_filename)
    except: raise MissingSubCorpFreqFile(ngr_data_filename)
    attr = corp.get_attr(wlattr)
    is_subcorp, tmpminfreq = False, 0 # optimization
    if hasattr(corp, 'spath'):
        freqs = frq_db (corp, wlattr+'.ngr', id_range=ngr.size())
        is_subcorp = True
    items = []
    words, blacklist = set(words), set(blacklist)
    nwre = re.compile(corp.get_conf('NONWORDRE').replace('^[:alpha:]', '\d\W_'),
                      re.UNICODE)
    if wlpat and wlpat != '.*': wlpatre = re.compile(wlpat, re.UNICODE)
    else: wlpatre = None
    id2strmap = [attr.id2str(i)
                 for i in range(min(tmpcache_size, attr.id_range()))]
    for i in xrange(ngr.size()):
        if is_subcorp: freq = freqs[i]
        else: freq = ngr.freq(i)
        if freq < wlminfreq or freq < tmpminfreq \
                or (wlmaxfreq and freq > wlmaxfreq):
            continue
        ngrwords = []
        lids = ngr.lids(i)
        whitelisted = False
        for ii in range(ngr.max(i)):
            lid = lids.next()
            ngrwords.append(lid < tmpcache_size and id2strmap[lid]
                            or attr.id2str(lid))
            if ii+1 >= ngrams_max_n:
                break
        for ii, word in enumerate(ngrwords):
            n = ii + 1
            if not include_nonwords and nwre.match(word):
                break
            if blacklist and word in blacklist:
                break
            if words and word in words:
                whitelisted = True
            if n < ngrams_n or n > ngrams_max_n:
                continue
            if n < ngr.min(i) or n > ngr.max(i):
                continue
            ngram = ' '.join(ngrwords[:n])
            if ((wlpatre and not wlpatre.search(ngram)) or
                    (words and not whitelisted and not ngram in words) or
                    (blacklist and ngram in blacklist)):
                continue
            items.append((freq, '  '.join(ngrwords[:n])))
        if len (items) > 5 * wlmaxitems:
            if wlsort == 'f':
                items.sort(reverse=True)
                del items [wlmaxitems:]
                tmpminfreq = items[-1][0]
            else:
                items.sort(key=itemgetter(1))
                del items [wlmaxitems:]
    if wlsort == 'f': items.sort(reverse=True)
    else: items.sort(key=itemgetter(1))
    del items [wlmaxitems:]
    return [{'str': w, 'freq': f} for f, w in items]


def ws_wordlist (corp, wlmaxitems=100, wlsort='', wlattr='ws_collocations',
                 wlpat=''):
    import wmap
    wmap.setEncoding(corp.get_conf('ENCODING'))
    wsbasekw = 'TERMBASE' if wlattr == 'ws_terms' else 'WSBASE'
    csize = corp.search_size()
    basewsbase = os.path.basename (corp.get_conf(wsbasekw))
    freqs_file = subcorp_base_file (corp, basewsbase + '.hfrq')
    lex_file = subcorp_base_file (corp, basewsbase + '.hlex')
    logfile = wlattr + '.build'
    if not os.path.isfile (freqs_file): # not computed
        raise MissingSubCorpFreqFile (corp)
    if os.path.isfile (subcorp_base_file(corp, logfile)):
        raise MissingSubCorpFreqFile (corp) # computation in progress

    maxitems = wlmaxitems if wlpat == '.*' else 20000000 # 20M for filtered
    result_str = wmap.StrVector()
    wmap.terms_lexicon (freqs_file, lex_file, result_str, maxitems)
    if wlpat and wlpat != '.*': # filter items
        import re
        new_result = []
        wlpatre = re.compile(wlpat, re.UNICODE)
        for item in result_str:
            itemstr, num = item.rsplit('\t', 1)
            if wlpatre.search(itemstr):
                new_result.append((-int(num), itemstr))
            if len(new_result) >= 4 * wlmaxitems:
                new_result.sort()
                del new_result[wlmaxitems:]
        result_str = [x[1] for x in new_result]
    # find out seek and cnt
    ws1 = wmap.WMap (corp.get_conf(wsbasekw), corp.get_conffile())
    result_parsed = []
    for item in result_str:
        w1, gramrel, w2 = item.split ('\t')[:3]
        result_parsed.append((ws1.coll2id(w1), ws1.str2id(gramrel),
                              ws1.coll2id(w2), w1, gramrel, w2))
    result = []
    for id1, id2, id3, w1, gramrel, w2 in sorted (result_parsed):
        ws3 = ws_find_triple (ws1, id1, id2, id3)
        if not ws3: continue
        freq = ws_subc_freq (ws3, corp)
        result.append ((-freq, w1, gramrel, w2, ws3.tell(), ws3.getrnk()))
    return [{'w1': w1, 'gramrel': g, 'w2': w2, 'seek': seek,
             'freq': -mfreq, 'str': ' '.join([w1, g, w2]),
             'score': '%.2f' % score }
                          for mfreq, w1, g, w2, seek, score in sorted (result)]


def wordlist (corp, words=[], wlattr='', wlpat='', wlminfreq=5, wlmaxitems=100,
              wlsort='', blacklist=[], wlnums='frq', include_nonwords=0,
              wlmaxfreq=0):
    blacklist = set (blacklist)
    words = set (words)
    attr = corp.get_attr (wlattr)
    total = 0
    if '.' in wlattr: # attribute of a structure
        struct = corp.get_struct(wlattr.split('.')[0])
        if wlnums == 'doc sizes':
            normvals = dict ([(struct.beg(i), struct.end(i)-struct.beg(i))
                                              for i in xrange(struct.size())])
        else:
            normvals = dict ([(struct.beg(i),1) for i in xrange(struct.size())])
        attrfreq = dict ([(i, doc_sizes(corp, struct, wlattr, i, normvals))
                                              for i in xrange(attr.id_range())])
    else: # positional attribute
        attrfreq = frq_db (corp, wlattr, wlnums)
    items = []
    if words and wlpat == '.*': # word list just for given words
        for word in words:
            if wlsort == 'f':
                if len (items) > 5 * wlmaxitems:
                    items.sort()
                    del items [:-wlmaxitems]
            else:
                if len (items) >= wlmaxitems:
                    break
            id = attr.str2id(word)
            if id == -1:
                frq = 0
            else:
                frq = attrfreq[id]
            if word and frq >= wlminfreq \
                    and (not wlmaxfreq or frq <= wlmaxfreq) \
                    and (not blacklist or word not in blacklist):
                if wlnums == 'arf':
                    items.append ((round(frq, 1), word))
                else:
                    items.append ((frq, word))
    else: # word list according to pattern
        if not include_nonwords: nwre = corp.get_conf('NONWORDRE')
        else: nwre = ''
        try: gen = attr.regexp2ids (wlpat.strip(), 0, nwre)
        except TypeError: gen = attr.regexp2ids (wlpat.strip(), 0)
        while not gen.end():
            if wlsort == 'f':
                if len (items) > 5 * wlmaxitems:
                    items.sort()
                    del items [:-wlmaxitems]
            else:
                if len (items) >= wlmaxitems:
                    items.sort(key=lambda x: x[1])
                    del items [wlmaxitems:]
            id = gen.next()
            frq = attrfreq [id]
            if not frq: continue
            if frq >= wlminfreq and (not wlmaxfreq or frq <= wlmaxfreq) \
                    and (not words or attr.id2str(id) in words) \
                    and (not blacklist or attr.id2str(id) not in blacklist):
                if wlsort == 'f': w = id
                else: w = attr.id2str(id)
                if wlnums == 'arf': items.append ((round(frq, 1), w))
                else: items.append ((frq, w))
                total += 1
    if wlsort == 'f':
        items.sort()
        del items [:-wlmaxitems]
        items.reverse()
    else:
        items.sort(key=lambda x: x[1])
        del items [wlmaxitems:]
    if not (words and wlpat == '.*') and wlsort == 'f':
        items = [(f,attr.id2str(i)) for (f,i) in items]
    return [{'str': w, 'freq': f} for f,w in items], total

def doc_sizes(corp, struct, attrname, i, normvals):
    r = corp.filter_query (struct.attr_val (attrname.split('.')[1], i))
    cnt = 0
    while not r.end():
        cnt += normvals[r.peek_beg()]
        r.next()
    return cnt

def attr_vals (corpname, avattr, avpattern, avmaxitems=20):
    c = manatee.Corpus (corpname)
    attr = c.get_attr (avattr, True)
    gen = attr.regexp2ids ('.*%s.*' % avpattern.strip(), True)
    items = []
    while not gen.end() and avmaxitems > 0:
        items.append (attr.id2str(gen.next()))
        avmaxitems -= 1
    if not items:
        return {'query': avpattern, 'suggestions': [_('--nothing found--')]}
    return {'query': avpattern,
            'suggestions': items}

def texttype_values (corp, subcorpattrs, list_all=False, hidenone=True):
    if subcorpattrs == '#': return []
    attrlines = []
    for subcorpline in subcorpattrs.split(','):
        attrvals = []
        for n in subcorpline.split('|'):
            if n in ('', '#'):
                continue
            attr = corp.get_attr (n)
            attrval = { 'name': n,
                        'label': corp.get_conf (n+'.LABEL') or n,
                        'attr_doc': corp.get_conf (n+'.ATTRDOC'),
                        'attr_doc_label': corp.get_conf (n+'.ATTRDOCLABEL'),
                      }
            try:
                maxlistsize = int(corp.get_conf (n+'.MAXLISTSIZE'))
            except ValueError:
                maxlistsize = DEFAULTMAXLISTSIZE
            hsep = corp.get_conf(n+'.HIERARCHICAL')
            multisep = ''
            if corp.get_conf(n+'.MULTIVALUE').startswith(('y', 'Y', '1')):
                multisep = corp.get_conf(n+'.MULTISEP')
            if not hsep and not list_all \
                                and (corp.get_conf (n+'.TEXTBOXLENGTH')
                                      or attr.id_range() > maxlistsize):
                attrval ['textboxlength'] = (corp.get_conf (n+'.TEXTBOXLENGTH')
                                             or 24)
            else: # list of values
                if corp.get_conf(n+'.NUMERIC'):
                    vals = []
                    for i in xrange(attr.id_range()):
                        try: vals.append({'v': int(attr.id2str(i))})
                        except: vals.append({'v': attr.id2str(i)})
                elif hsep: # hierarchical
                    vals = [{'v': attr.id2str(i)}
                                  for i in xrange(attr.id_range())
                                  if not multisep in attr.id2str(i)]
                else:
                    vals = [{'v': attr.id2str(i)}
                            for i in xrange(attr.id_range())
                            if not (multisep and multisep in attr.id2str(i))]
                if hidenone: # hide empty + ===NONE===
                    i = 0
                    while i < len(vals):
                        if vals[i]['v'] in ('', '===NONE==='): del vals[i]
                        else: i += 1
                if hsep: # hierarchical
                    attrval ['hierarchical'] = hsep
                    attrval ['Values'] = get_attr_hierarchy(vals, hsep, multisep)
                else:
                    vals.sort()
                    attrval ['Values'] = vals
            attrvals.append (attrval)
        attrlines.append ({'Line': attrvals})
    return attrlines

def get_attr_hierarchy(vals, hsep, multisep):
    result = {}
    values = set([])
    for v in vals:
        values.add(v['v'])
    for value in sorted(values):
        level = result
        while hsep in value:
            key, value = value.split(hsep, 1)
            try: level = level[key]
            except: value = key + hsep + value; break
        level[value] = {}
    return print_attr_hierarchy(result, hsep=hsep)

def print_attr_hierarchy(layer, level=0, label='', hsep='::'):
    if not layer: return []
    result = []
    if level > 0: startdiv = True
    else: startdiv = False
    for item in sorted(layer):
        sub = print_attr_hierarchy(layer[item], level+1, label+hsep+item, hsep)
        if sub: display_plus = True
        else: display_plus = False
        if label: full_value = label[len(hsep):] + hsep + item
        else: full_value = item
        result.append({ 'v': full_value,
                        'key': label,
                        'label': item,
                        'shift': level * 16,
                        'startdiv': startdiv,
                        'enddiv': 0,
                        'display_plus': display_plus,
                      })
        startdiv = False
        result.extend(sub)
    if level > 0: result[-1]['enddiv'] += 1
    return result

def subc_freqs (subcorp, attr, minfreq=50, maxfreq=10000, last_id=None):
    return [(i, subcorp.count_rest(attr.id2poss(i)))
            for i in xrange(last_id or attr.id_range())
            if maxfreq > attr.freq(i) > minfreq]

def subcorp_base_file (corp, attrname):
    if hasattr(corp, 'spath'):
        return corp.spath[:-4] + attrname
    else:
        return corp.get_conf('PATH') + attrname
    
class MissingSubCorpFreqFile (Exception):
    pass

def frq_db (corp, attrname, nums='frq', id_range=0):
    import array, exceptions
    filename = subcorp_base_file (corp, attrname) + '.' + nums
    if not id_range: id_range = corp.get_attr (attrname).id_range()
    if nums == 'arf':
        frq = array.array('f')
        try:
            frq.fromfile (open(filename), id_range)
        except IOError:
            raise MissingSubCorpFreqFile (corp)
        except exceptions.EOFError:
            os.remove(filename.rsplit('.', 1)[0]+'.docf')
            raise MissingSubCorpFreqFile (corp)
    else:
        try:
            if corp.get_conf ('VIRTUAL') and not hasattr(corp, 'spath') \
                                         and nums == 'frq':
                raise IOError
            frq = array.array('i')
            frq.fromfile (open(filename), id_range)
        except exceptions.EOFError:
            os.remove(filename.rsplit('.', 1)[0]+'.docf')
            os.remove(filename.rsplit('.', 1)[0]+'.arf')
            os.remove(filename.rsplit('.', 1)[0]+'.frq')
            raise MissingSubCorpFreqFile (corp)
        except IOError:
            try:
                frq = array.array('l')
                frq.fromfile (open(filename + '64'), id_range)
            except IOError:
                if not hasattr(corp, 'spath') and nums == 'frq':
                    a = corp.get_attr (attrname)
                    frq.fromlist ([a.freq(i) for i in xrange(a.id_range())])
                else:
                    raise MissingSubCorpFreqFile (corp)
    return frq


def subc_keywords_onstr (sc, scref, wlattr='word', wlminfreq=5, wlpat='.*',
                         wlmaxitems=100, simple_n=1, words=[], wlmaxfreq=0,
                         blacklist=[], include_nonwords=0, wlnums='frq',
                         onealpha=True, alnum=False):
    simple_n = float(simple_n)
    size = sc.search_size()
    size_ref = scref.search_size()
    p = 1.0 * size_ref / size
    attr = sc.get_attr(wlattr)
    attrref = scref.get_attr(wlattr)
    if wlnums == 'frq':
        afreq = attr.freq
        rfreq = attrref.freq
    elif wlnums == 'arf':
        afreq = attr.arf
        rfreq = attrref.arf
    elif wlnums == 'docf':
        afreq = attr.docf
        rfreq = attrref.docf
    items = []
    if not include_nonwords: nwre = sc.get_conf('NONWORDRE')
    else: nwre = ''
    try: gen = attr.regexp2ids (wlpat.strip(), 0, nwre)
    except TypeError: gen = attr.regexp2ids (wlpat.strip(), 0)
    while not gen.end():
        i = gen.next()
        f = afreq(i)
        if f == -1: raise MissingSubCorpFreqFile (sc)
        if f < wlminfreq or (wlmaxfreq and f > wlmaxfreq):
            continue
        w = attr.id2str(i)
        if (words and w not in words) or (w in blacklist) \
                or (alnum and not re_alnum.match(w))\
                or (onealpha and not re_onealpha.match(w)):
            continue
        iref = attrref.str2id(w)
        if iref == -1:
            fref = 0
        else:
            fref = rfreq (iref)
        if fref == -1: raise MissingSubCorpFreqFile (scref)
        if fref == 0 or p * f / fref > 1.0:
            rel = (f * 1000000.0) / size
            relref = (fref * 1000000.0) / size_ref
            score = (rel + simple_n) / (relref + simple_n)
            items.append ((score, rel, relref, f, fref, w))
        if len(items) > 4 * wlmaxitems:
            items.sort(reverse=True)
            del items[wlmaxitems:]
    items.sort(reverse=True)
    return items[:wlmaxitems]


def ngr_keywords (sc, scref, wlattr='word', wlminfreq=5, wlpat='.*',
                  wlmaxitems=100, simple_n=1, words=[], wlmaxfreq=0,
                  blacklist=[], include_nonwords=0, ngrams_n=2):
    import re
    ngr_data_filename = str(sc.get_conf('PATH') + wlattr + '.ngr')
    ngrref_data_filename = str(scref.get_conf('PATH') + wlattr + '.ngr')
    try: ngr = manatee.NGram(ngr_data_filename)
    except: raise MissingSubCorpFreqFile(ngr_data_filename)
    try: ngrref = manatee.NGram(ngrref_data_filename)
    except: raise MissingSubCorpFreqFile(ngrref_data_filename)
    if hasattr(sc, 'spath'):
        freqs = frq_db (sc, wlattr+'.ngr', id_range=ngr.size())
    if hasattr(scref, 'spath'):
        freqsref = frq_db (scref, wlattr+'.ngr', id_range=ngrref.size())
    size = sc.search_size()
    size_ref = scref.search_size()
    p = 1.0 * size_ref / size
    attr = sc.get_attr(wlattr)
    attrref = scref.get_attr(wlattr)
    items = []
    words, blacklist = set(words), set(blacklist)
    nwre = re.compile(sc.get_conf('NONWORDRE').replace('^[:alpha:]', '\d\W_'),
                      re.UNICODE)
    if wlpat and wlpat != '.*': wlpatre = re.compile(wlpat, re.UNICODE)
    else: wlpatre = None
    for i in xrange(ngr.size()):
        if hasattr(sc, 'spath'): freq = freqs[i]
        else: freq = ngr.freq(i)
        if freq < wlminfreq or (wlmaxfreq and freq > wlmaxfreq): continue
        if ngrams_n < ngr.min(i) or ngr.max(i) < ngrams_n:
            continue # n-gram too big or too small
        ngrwords = []
        lids = ngr.lids(i)
        whitelisted = False
        for n in xrange(ngrams_n): # "unzip" n-gram and filter
            word = attr.id2str(lids.next())
            if not include_nonwords and nwre.match(word): break
            if blacklist and word in blacklist: break
            if words and word in words: whitelisted = True
            ngrwords.append(word)
        if len(ngrwords) < ngrams_n:
            continue
        ngram = ' '.join(ngrwords)
        if ((wlpatre and not wlpatre.search(ngram)) or
            (words and not whitelisted and not ngram in words) or
            (blacklist and ngram in blacklist)):
            continue
        # locate ngram in scref
        refngram = ngrref.locate_id(map(attrref.str2id, ngrwords))
        if refngram == -1: reff = 0
        elif hasattr(scref, 'spath'): reff = freqsref[refngram]
        else: reff = ngrref.freq(refngram)
        if reff == 0 or p * freq / reff > 1.0:
            rel = (freq * 1000000.0) / size
            relref = (reff * 1000000.0) / size_ref
            score = (rel + simple_n) / (relref + simple_n)
            items.append ((score, rel, relref, freq, reff, '  '.join(ngrwords)))
        if len(items) > 4 * wlmaxitems:
            items.sort(reverse=True)
            del items[wlmaxitems:]
    items.sort(reverse=True)
    return items[:wlmaxitems]


def ws_keywords (sc, scref, wlminfreq=10, wlmaxitems=100, simple_n=1,
                 ret_count=False, wlattr='ws_collocations', onealpha=True,
                 alnum=False, blacklist=[], filter_singleword=True):
    import wmap
    wsbasekw = 'WSBASE'
    if wlattr == 'ws_terms': wsbasekw = 'TERMBASE'
    if sc.get_conf('ENCODING') != scref.get_conf('ENCODING'):
        raise RuntimeError('Incompatible encodings (focus: %s, reference: %s)' %\
                (sc.get_conf('ENCODING'), scref.get_conf('ENCODING')))
    wmap.setEncoding(sc.get_conf('ENCODING'))
    basewsbase = os.path.basename(sc.get_conf(wsbasekw))
    ref_basewsbase = os.path.basename(scref.get_conf(wsbasekw))
    if not ref_basewsbase:
        raise RuntimeError('%s has no %s' % (scref.get_conf('NAME'), wsbasekw))
    freqs_file = subcorp_base_file(sc, basewsbase + '.hfrq')
    lex_file = subcorp_base_file(sc, basewsbase + '.hlex')
    ref_freqs_file = subcorp_base_file(scref, ref_basewsbase + '.hfrq')
    logfile = wlattr + '.build'

    if not os.path.isfile(freqs_file) or os.stat(freqs_file)[6] == 0:
        raise MissingSubCorpFreqFile(sc) # not computed
    if not os.path.isfile(ref_freqs_file) or os.stat(ref_freqs_file)[6] == 0:
        raise MissingSubCorpFreqFile(scref)

    result_str = wmap.StrVector()
    wmap.extrms(freqs_file, ref_freqs_file, lex_file, result_str, wlmaxitems*10,
            simple_n)

    # find out seek and cnt -- firstly for sc ...
    ws1 = wmap.WMap (sc.get_conf(wsbasekw), sc.get_confpath())
    size = sc.search_size()
    result_parsed = []
    try: wsstrip = int(sc.get_conf('WSSTRIP'))
    except ValueError: wsstrip = 0
    for item in result_str:
        w1, gramrel, w2, score = item.strip().split('\t')[:4]
        result_parsed.append ((ws1.coll2id(w1), ws1.str2id(gramrel),
                               ws1.coll2id(w2), w1, gramrel, w2, float(score)))
    result = {}

    for id1, id2, id3, w1, gramrel, w2, score in sorted (result_parsed):
        ws3 = ws_find_triple (ws1, id1, id2, id3)
        if not ws3: continue
        totalcount = ws3.size()
        freq = ws_subc_freq (ws3, sc)
        w2s = wsstrip and w2[:-wsstrip] or w2 # TODO: treat _xxx_ tokens
        if (wlattr == 'ws_terms' and filter_singleword and '_' not in w2s)\
                or (freq < wlminfreq)\
                or (blacklist and (set(w2s.split('_')) & set(blacklist)))\
                or (onealpha and not re_onealpha.match(w2s))\
                or (alnum and not re_alnum_terms.match(w2s)):
            continue
        result[(-score, w1, gramrel, w2s)] = [freq, float(freq)*1000000/size,
                                              ws3.tell()]
    result2 = {}
    for k in sorted(result.keys())[:wlmaxitems]:
        result2[k] = result[k]
    result = result2
    # ... and then for scref
    ws1 = wmap.WMap (scref.get_conf(wsbasekw), scref.get_confpath())
    size = scref.search_size()
    result_parsed = []
    for item in result_str:
        w1, gramrel, w2, score = item.strip().split('\t')[:4]
        result_parsed.append ((ws1.coll2id(w1), ws1.str2id(gramrel),
                               ws1.coll2id(w2), w1, gramrel, w2, float(score)))
    for id1, id2, id3, w1, gramrel, w2, score in sorted (result_parsed):
        w2s = wsstrip and w2[:-wsstrip] or w2
        if not (-score, w1, gramrel, w2s) in result: continue
        ws3 = ws_find_triple (ws1, id1, id2, id3)
        if not ws3:
            result[(-score, w1, gramrel, w2s)].extend([0, 0, 0]); continue
        freq = ws_subc_freq (ws3, scref)
        result[(-score, w1, gramrel, w2s)].extend (
                                 [freq, float(freq)*1000000/size, ws3.tell()])
    result_list = [(-k[0], v[1], v[4], v[0], v[3],
                    '%s\t%s\t%s\t%s\t%s' % (k[1], k[2], k[3], v[2], v[5]))
                   for k, v in sorted (result.items())]
    if ret_count:
        return result_list, totalcount
    return result_list


def create_hashws_cmd (corp, wsbase):
    basewsbase = os.path.basename(wsbase)
    freqs_file = subcorp_base_file(corp, basewsbase + '.hfrq')
    lex_file = subcorp_base_file(corp, basewsbase + '.hlex')
    out = "hashws %s '%s' '%s' %s" % (corp.get_confpath(), freqs_file, lex_file,
                                      wsbase)
    if hasattr(corp, 'spath'):
        out += " '%s'" % corp.spath
    return out

def create_mkstats_cmd (corp, attrname, freqtype):
    outfilename = subcorp_base_file (corp, attrname) + "." + freqtype
    if os.path.isfile (outfilename):
        return
    path = ""
    if hasattr(corp, 'spath'):
        path = "'%s'" % corp.spath
        same = corp.cm.find_same_subcorp_file (corp, attrname, (freqtype))
        if same:
            same = same[:-4] + attrname
            from shutil import copyfile
            copyfile (same + "." + freqtype, outfilename + "." + freqtype)
            try: copyfile (same + '.frq64', outfilename + '.frq64')
            except: pass
            return
    return "mkstats %s %s %s %s" % (corp.get_confpath(), attrname, freqtype,
                                    path)

def compute_trends(corp, user, sattr, tattr, method, subcpath, url):
    cmd = "mktrends %s %s %s %s 5 1 '%s'" % (corp.get_confpath(), sattr, tattr,
            method, subcpath)
    cmd_desc = corp.get_conf('NAME')
    if subcpath:
        cmd_desc += ':' + os.path.basename(subcpath)[:-5]
    desc = _('Trends computation (%s)') % cmd_desc
    return run_bgjob(user, corp, cmd, desc, url)

def compute_norms(corp, user, struct, subcpath, url):
    subcmd = ''
    cmd_desc = corp.get_conf('NAME')
    if subcpath:
        subcmd = "wordcount '%s'" % subcpath
        cmd_desc += ':' + os.path.basename(subcpath)[:-5]
    cmd = "mknorms %s %s %s" % (corp.get_confpath(), struct, subcmd)
    desc = _("Norms computation (%s)") % cmd_desc
    return run_bgjob(user, corp, cmd, desc, url)

def compute_ngrams (user, corp, attrname, url):
    baseattrname = attrname[:-4].split('/')[-1]
    cmd = " ".join(['genngr', corp.get_confpath(), baseattrname, '5',
                    attrname])
    desc = "N-grams computation ('%s' attribute)" % baseattrname
    return run_bgjob (user, corp, cmd, desc, url)

def get_stat_desc (stat):
    return {'arf':_('average reduced frequency'),
            'frq':_('frequency'),
            'docf':_('document frequency')}[stat]

def compute_freqfile (user, corp, attrname, freqtype, url):
    freqdesc = get_stat_desc (freqtype)
    if attrname == 'ws_terms':
        if not os.path.exists(corp.get_conf('TERMBASE') + '.lex'):
            raise Exception('Terms are not compiled for ' + corp.get_conf('NAME'))
        cmd = create_hashws_cmd (corp, corp.get_conf('TERMBASE'))
        desc = "Terms statistics (%s)" % freqdesc
    elif attrname == 'ws_collocations':
        cmd = create_hashws_cmd (corp, corp.get_conf('WSBASE'))
        desc = "Collocations statistics (%s)" % freqdesc
    else:
        cmd = create_mkstats_cmd (corp, attrname, freqtype)
        desc = "(Sub)corpus statistics (%s)" % freqdesc
    return run_bgjob (user, corp, cmd, desc, url)

def run_bgjob (user, corp, cmd, desc, url):
    job = corp.cm.jobclient.request ("new_job",
            {"cmd" : cmd, "url" : url,
             "corpus" : corp.get_conf("NAME").encode('utf-8'), "desc" : desc})
    if job[1] == 200: # new process started:
        return {"progress": '0', "jobid": job[0], "notifyme": False,
                "esttime": "N/A"}
    else: # already running
        job = corp.cm.jobclient.request ("job_progress", {"jobid" : job[0]})
        import json
        job = json.loads(job[0])
        return {"progress": job[0]["progress"], "jobid": job[0]["jobid"],
                "notifyme": job[0].get("notifyme", False),
                "esttime": job[0]["esttime"]}

def get_corp_info(corpname, registry='', gramrels=0):
    from string import strip
    from butils import get_last_corpcheck
    from subprocess import Popen, PIPE
    result = {
            'wposmap': False,
            'lposmap': False,
            'attrs': [],
            'structs': [],
            'gramrels': [],
            }
    corp = manatee.Corpus(corpname)
    wposlist = corp.get_conf('WPOSLIST').split(',')
    lposlist = corp.get_conf('LPOSLIST').split(',')
    attrlist = corp.get_conf('ATTRLIST').split(',')
    wsbase = corp.get_conf('WSBASE')
    if gramrels and wsbase and wsbase != "none":
        grl = []
        grspd = {}
        import wmap
        try:
            ws = wmap.WMap(wsbase, corpname)
            for i in xrange(ws.id_range()):
                grn = ws.id2str(i)
                grsp = ws.seppage(i)
                if grsp == -1:
                    grl.append(grn)
                else:
                    grspd.setdefault(grsp, [])
                    grspd[grsp].append(grn)
            result['gramrels'].extend(sorted(grl))
            result['gramrels'].extend([x[1] for x in grspd.iteritems()])
        except RuntimeError:
            pass
    structlist = corp.get_conf('STRUCTLIST').split(',')
    structs = dict([(x, [0, []]) for x in structlist if x])
    for s in structs:
        structs[s][0] = corp.get_struct(s).size()
    for item in attrlist:
        attr = corp.get_attr(item)
        result['attrs'].append((item, attr.id_range(), corp.get_conf(item + '.LABEL')))
    for sa in corp.get_conf('STRUCTATTRLIST').split(','):
        if len(sa.split('.')) != 2:
            continue
        s, a = sa.split('.')
        struct = corp.get_struct(s)
        if struct.size() < 1:
            continue
        l = corp.get_conf('%s.%s.LABEL' % (s, a)) or a
        if s not in structs:
            continue
        structs[s][0] = struct.size()
        sattr = struct.get_attr(a)
        structs[s][1].append((sa, l, sattr.id_range()))
    for k in structs:
        result['structs'].append((k, structs[k][0], sorted(structs[k][1],
                key=lambda x: x[1])))
    modtime = time.gmtime(os.stat(corp.get_conf('PATH')).st_mtime)
    sizes = {}
    alsizes = []
    for sizesline in corp.get_sizes().split('\n'):
        sls = sizesline.split(' ')
        if len(sls) == 2:
            sizes[sls[0].strip()] = sls[1].strip()
        if len(sls) == 4:
            alsizes.append((sls[2], sls[1], sls[3]))
    result.update({
            'name': corp.get_conf('NAME'),
            'lang': corp.get_conf('LANGUAGE'),
            'infohref': corp.get_conf('INFOHREF'),
            'info': corp.get_conf('INFO'),
            'encoding': corp.get_conf('ENCODING'),
            'tagsetdoc': corp.get_conf('TAGSETDOC'),
            'compiled': time.strftime("%m/%d/%Y %H:%M:%S", modtime),
            'sizes': sizes,
            'alsizes': alsizes,
            })
    if wposlist:
        result.update({'wposmap': zip(wposlist[1::2], wposlist[2::2])})
    if lposlist:
        result.update({'lposmap': zip(lposlist[1::2], lposlist[2::2])})
    logs = sorted(glob.glob(os.path.join(corp.get_conf('PATH'), 'log/*.log')))
    if logs:
        result['last_corpcheck'] = get_last_corpcheck(logs[-1])
    if registry:
        result['registry_dump'] = manatee.loadCorpInfo(str(corpname)).dump().replace('\r', '\n')
        result['registry_text'] = open(corp.get_confpath()).read().replace('\r', '\n')
    return result

def get_biterms(corpname, l2_corpname='', limit=1000):
    result = {}
    corp = manatee.Corpus(corpname)
    path = corp.get_conf('PATH')
    if not l2_corpname:
        return {'error': _('Aligned corpus not specified')}
    fname = os.path.join(path, l2_corpname + '.biterms')
    if not os.path.exists(fname):
        return {'error': _('No bilingual terminology for') + ' ' + l2_corpname}
    counter = 0
    result = []
    f = open(fname)
    while counter < limit:
        line = f.readline().strip().decode('utf-8')
        if not line:
            break
        result.append(tuple(line.split('\t')))
        counter += 1
    return result

def get_trends(corp, sattr, attr, subcpath='', trends_re='', sort_by='t',
        filter_nonwords=1, filter_capitalized=0, method='mkts_all',
        maxp=0.01, minfreq=5):
    import math
    path = corp.get_conf('PATH')
    if subcpath:
        fpath = subcpath + '.' + '.'.join([sattr, attr, method, 'trends'])
        spath = subcpath + '.' + '.'.join([sattr, attr, method, 'minigraphs'])
    else:
        fpath = os.path.join(path, '.'.join([sattr, attr, method, 'trends']))
        spath = os.path.join(path, '.'.join([sattr, attr, method, 'minigraphs']))
    trends_items, samples = [], {}
    if os.path.exists(fpath):
        if filter_nonwords:
            nwre = re.compile(corp.get_conf('NONWORDRE').replace('^[:alpha:]',
                    '\d\W_'), re.UNICODE)
        if trends_re:
            if not trends_re.endswith('$'):
                tre = re.compile(trends_re + '$')
            else:
                tre = re.compile(trends_re)
        a = corp.get_attr(attr)
        for id, angle, p in read_trends_file(fpath):
            if id == -1:
                return False, []
            if id == -2:
                return [], []
            w = a.id2str(id)
            f = a.freq(id)
            if not w:
                continue
            if minfreq > f or maxp < p:
                continue
            if filter_nonwords and nwre.search(w):
                continue
            if filter_capitalized and w[0].lower() != w[0]:
                continue
            if trends_re and not tre.match(w):
                continue
            trend = math.tan(angle/180.0*math.pi)
            if trend > 1.0:
                simple_trend = 2
            elif trend > 0.1:
                simple_trend = 1
            elif trend > -0.1:
                simple_trend = 0
            elif trend > -1.0:
                simple_trend = -1
            else:
                simple_trend = -2
            trends_items.append([id, w, trend, p, f, simple_trend])
        if sort_by == 't':
            trends_items.sort(key=lambda x:x[2], reverse=True,
                    cmp=lambda x,y: 1 if (abs(x)-abs(y)) >= 0 else -1)
        elif sort_by == 'p':
            trends_items.sort(key=lambda x:x[3])
        else:
            trends_items.sort(key=lambda x:x[4], reverse=True)
        if os.path.exists(spath):
            for sitem in read_trends_file(spath, True):
                samples[sitem[0]] = ':'.join(map(str, sitem[1]))
    else:
        return None, None
    return trends_items[:1000], samples

def read_trends_file(path, samples=False):
    import struct
    f = open(path, 'rb')
    h = f.read(32)
    if not h: # header empty => computing
        yield samples and (-1, -1) or (-1, -1, -1)
    result = []
    if samples:
        b = f.read(8)
        if b == '':
            yield (-2, -1) # empty file after header
        while b != '':
            try:
                id, v = struct.unpack('<II', b)
            except:
                yield (-1, [])
            cols = [(v >> i & 15) for i in (0, 4, 8, 12, 16, 20, 24, 28)]
            yield (id, cols)
            b = f.read(8)
    else:
        #hexdump -s 32 -v -e '1/4 "%i" 1/1 " %5i" 1/4 " %10f" "\n"'
        b = f.read(9)
        if b == '':
            yield (-2, -1, -1) # empty file after header
        while b != '':
            try:
                id, angle, p = struct.unpack('<Ibf', b)
                yield (id, angle, p)
            except:
                yield (-1, -1, -1)
            b = f.read(9)

def save_subcdef(path, subcname, structname, subquery):
    scdf = open(path + 'def', 'w')
    scdf.write('=%s\n\t%s\n\t' % (subcname, structname))
    scdf.write(subquery.encode('utf-8'))
    scdf.write('\n')
    scdf.close()
    return path + 'def'

def parse_subcdef(subcname, path):
    "extracts only the first (topmost) subc definition"
    infile = open(path)
    while 1:
        line = infile.readline()
        if not line:
            break
        if line.startswith('='):
            subcdef_subcname = line[1:].strip()
            struct = infile.readline().strip()
            query = infile.readline().strip().decode('utf-8')
            if subcdef_subcname == subcname and struct and query:
                return (subcdef_subcname, struct, query)
    return (False, False, False)

def are_subcorp_stats_compiled(c, attr):
    # check subcorpus statistics are compiled for the given attribute
    sc = manatee.SubCorpus (c, c.spath)
    a = sc.get_attr (attr)
    return a.freq(0) != -1
