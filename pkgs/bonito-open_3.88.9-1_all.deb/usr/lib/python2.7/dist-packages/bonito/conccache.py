# Copyright (c) 2003-2015  Pavel Rychly, Vojtech Kovar, Milos Jakubicek

import cPickle, os, manatee
from butils import flck_sh_lock, flck_ex_lock, flck_unlock
from socket import error as socketerror
from httplib import BadStatusLine
from concsrv import ConcServer, get_server_conc_sizes, get_server_conc
from pyconc import PyConc

def load_map (_cache_dir):
    try:
        f = open (_cache_dir + '00CONCS.map', 'rb')
    except IOError:
        return {}
    try:
        flck_sh_lock (f)
        ret = cPickle.load (f)
        flck_unlock (f)
    except:
        os.rename (_cache_dir + '00CONCS.map',
                   _cache_dir + '00CONCS-broken-%d.map' % os.getpid())
        return {}
    return ret

def uniqname (key, used):
    name = '#'.join ([''.join ([c for c in w if c.isalnum()]) for w in key])
    name = name[1:15].encode("UTF-8") # UTF-8 because os.path manipulations
    if not name:
        name = 'noalnums'
    if name in used:
        used = [w[len(name):] for w in used if w.startswith(name)]
        i = 0
        while str(i) in used:
            i += 1
        name += str(i)
    return name

def add_to_map (_cache_dir, pid_dir, subchash, key, size):
    kmap = None
    try:
        f = open (_cache_dir + '00CONCS.map', 'r+b')
    except IOError:
        f = open (_cache_dir + '00CONCS.map', 'wb')
        kmap = {}
    flck_ex_lock (f)
    if kmap is None:
        kmap = cPickle.load (f)
    ret = uniqname (key, [r for (r,s) in kmap.values()])
    if kmap.has_key ((subchash,key)):
        ret, storedsize = kmap [subchash,key]
        if storedsize < size:
            kmap [subchash,key] = (ret, size)
            f.seek(0)
            cPickle.dump (kmap, f)
        try:
            server = int(open(pid_dir + ret + ".pid").readline()[:-1])
        except:
            server = 0
    else:
        kmap [subchash,key] = (ret, size)
        f.seek(0)
        cPickle.dump (kmap, f)
        server = ConcServer (pid_dir + ret + ".log")
        pidfile = open(pid_dir + ret + ".pid", "w")
        pidfile.write (str(server.server_port) + "\n")
        pidfile.write (str(os.getpid()) + "\n")
        pidfile.close()
    f.close() # also automatically flck_unlock (f)
    return _cache_dir + ret + ".conc", pid_dir + ret + ".pid", server

def del_from_map (_cache_dir, subchash, key):
    try:
        f = open (_cache_dir + '00CONCS.map', 'r+b')
    except IOError:
        return
    flck_ex_lock (f)
    kmap = cPickle.load (f)
    try:
        del kmap [subchash,key]
        f.seek(0)
        cPickle.dump (kmap, f)
    except KeyError:
        pass
    f.close() # also automatically flck_unlock (f)

def get_cached_conc (corp, subchash, q, _cache_dir, pid_dir, minsize):
    q = tuple (q)
    try:
        attr = "word"
        if not attr in corp.get_conf("ATTRLIST").split(","):
            attr = corp.get_conf("DEFAULTATTR")
        if not os.path.isdir (pid_dir):
            os.makedirs (pid_dir)
        if not os.path.isdir (_cache_dir):
            os.makedirs (_cache_dir)
        elif (os.stat(_cache_dir + '00CONCS.map').st_mtime
              < os.stat(corp.get_conf('PATH') + attr + '.lex').st_mtime):
            os.remove (_cache_dir + '00CONCS.map')
            for f in os.listdir (_cache_dir):
                os.remove (_cache_dir + f)
    except OSError:
        pass

    saved = load_map (_cache_dir)
    for i in range (len(q), 0, -1):
        cache_val = saved.get ((subchash, q[:i]))
        if cache_val:
            cache_id, size = cache_val[0], cache_val[1]
            cachefile = os.path.join (_cache_dir, cache_id + '.conc')
            pidfile = os.path.realpath (pid_dir + cache_id + ".pid")
            if size == -1: # not yet finished
                try:
                     server_port = open(pid_dir + cache_id + ".pid").readline()[:-1]
                     return i, get_server_conc (corp, server_port, minsize)
                except (socketerror, BadStatusLine): # did we finish meanwhile?
                    saved = load_map (_cache_dir)
                    cache_val = saved.get ((subchash, q[:i]))
                    cache_id = cache_val[0]
                    cachefile = os.path.join (_cache_dir, cache_id + '.conc')
                    pidfile = os.path.realpath (pid_dir + cache_id + ".pid")
                    if cache_val and cache_val[1] == -1 \
                                 and os.path.exists (cachefile): # dead item
                        os.remove (cachefile)
            if not os.path.exists (cachefile): # broken cache
                del_from_map (_cache_dir, subchash, q)
                try:
                    os.remove (pidfile)
                except OSError:
                    pass
                continue
            conccorp = corp
            for qq in reversed(q[:i]): # find the right main corp, if aligned
                if qq.startswith('x-'): conccorp = manatee.Corpus(qq[2:]); break
            conc = PyConc (conccorp, 'l', cachefile, orig_corp=corp)
            return i, conc
    return 0, None

def get_cache_conc_sizes (corp, q, _cache_dir):
    q = tuple(q)
    subchash=getattr(corp, "subchash", None)
    _cache_dir = _cache_dir + '/' + corp.corpname + '/'
    saved = load_map (_cache_dir)
    cache_val = saved.get ((subchash, q))
    if not cache_val:
        return 1, 0, 0
    cachefile = os.path.join (_cache_dir, cache_val[0] + '.conc')
    import struct
    cache = open(cachefile,"rb")
    flck_sh_lock (cache)
    cache.seek(15);
    finished = ord(cache.read(1))
    (fullsize,) = struct.unpack("q",cache.read(8))
    cache.seek(32);
    (concsize,) = struct.unpack("i",cache.read(4))
    flck_unlock (cache)
    return finished, concsize, fullsize

def get_existing_conc (corp, subchash, q, _cache_dir, pid_dir, minsize,
                      server_port):
    try:
        conc = get_server_conc (corp, server_port, minsize)
    except (socketerror, BadStatusLine): # we may have finished meanwhile
        i, conc = get_cached_conc (corp, subchash, q, _cache_dir,
                                   pid_dir, minsize)
        if not conc or i != len (q):         
            raise Exception ("Failed to compute concordance")
    return conc

def get_existing_conc_sizes (corp, q, _cache_dir, server_port):
    try:
        finished, concsize, fullsize = get_server_conc_sizes (server_port)
    except (socketerror, BadStatusLine): # we may have finished meanwhile
        finished, concsize, fullsize = get_cache_conc_sizes (corp, q,_cache_dir)
    if fullsize > 0:
        relconcsize = 1000000.0 * fullsize / corp.search_size()
    else:
        relconcsize = 1000000.0 * concsize / corp.search_size()
        fullsize = concsize
    return {'finished':finished, 'concsize':concsize, 'fullsize': fullsize,
            'relconcsize': relconcsize}

