version = 'open-3.88.9'
manatee_minversion = '2.138'
