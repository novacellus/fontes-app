var exp = new Date();
exp.setDate(exp.getDate() + 30);
var opts = { domain: '', path: '/', expiresAt: exp, secure: false };

function endsWith(str, suffix) {
    return str.indexOf(suffix, str.length - suffix.length) !== -1;
}

jQuery(document).ready(function () {
    jQuery('.long_process_warning').click(function () {
        setTimeout(function () {
            jQuery('#long_process_warning').show();
        }, 4000);
    });
    jQuery('a[rel*=external]').click(function() {
        window.open(jQuery(this).attr('href'));
        return false;
    });
    jQuery(window).unload(function () { // enable button on unload
        jQuery(':disabled').attr('disabled', false);
    });
    jQuery(document).keyup(function(e) { // enable disabled buttons after ESC
        if (e.keyCode === 27) {
            jQuery('input[type="submit"]').removeAttr('disabled');
        }
    });
    jQuery('.menu_switch').click(function () {
        if (jQuery.cookies.get('menupos') == 'top') {
            jQuery('#sidebar, #in-sidebar, #content, #breadcrumbs')
                    .removeClass('horizontal');
            jQuery.cookies.del('menupos');
        }
        else {
            jQuery('#sidebar, #in-sidebar, #content, #breadcrumbs')
                    .toggleClass('horizontal');
            jQuery.cookies.set('menupos', 'top', opts);
        }
    });
    if (jQuery.cookies.get("menupos") == "top") {
        jQuery('#sidebar').addClass('horizontal');
        jQuery('#in-sidebar').addClass('horizontal');
        jQuery('#content').addClass('horizontal');
    }
    jQuery('form').submit(function (e) { // remove empty params from URL
        e.preventDefault();
        jQuery(this).find('input[type="text"]').each(function () {
            jQuery(this).val(jQuery.trim(jQuery(this).val()));
        });
        jQuery('input[name="sel_aligned"]:not(:checked)').each(function () {
            var corpn = jQuery(this).val();
            jQuery('select[name=pcq_pos_neg_'+corpn+']').attr('disabled', true);
            jQuery('#qtable_'+corpn+' input').each(function () {
                jQuery(this).attr('disabled', true);
            });
        });
        if (endsWith(this.action,'/first') && this.id == 'mainform') {
            store_ff_state();
        }
        var check_status = true;
        var checks = new Array("integer", "pos_integer", "pos_integer_zero",
                    "hundred", "float", "pos_integer_zero_auto", "empty",
                    "symbols");
        jQuery('.errtext').remove();
        jQuery('.wrong').removeClass('wrong');
        jQuery(this).find('.check_input').each(function () {
            var classes = jQuery(this).attr('class').split(/\s+/);
            for (var i=0; i<checks.length; i++) {
                if (jQuery.inArray(checks[i], classes) > 0) {
                    if (!check_value(checks[i], jQuery(this).val())
                            && !jQuery(this).prop('disabled')) {
                        jQuery(this).addClass('wrong');
                        if (jQuery(this).attr('data-errtext')) {
                            var ep = jQuery('<p class="errtext"></p>');
                            ep.text(jQuery(this).attr('data-errtext'));
                            jQuery(this).after(ep);
                        }
                        check_status = false;
                    }
                }
            }
        });
        if (!check_status &&
                jQuery(this).attr('action').indexOf('save_') !== 0) {
            jQuery('.check_input.wrong').first().focus();
            return;
        }
        if (jQuery(this).attr('id') !== 'help-search-form'
                && jQuery(this).attr('action').substring(0, 4) !== 'save') {
            jQuery(this).find('input[type=submit]').attr('disabled', true);
        }
        if (jQuery('[name="selgrlist"]:checked').length
                == jQuery('[name="selgrlist"]').length) {
            jQuery('[name="selgrlist"]').prop('disabled', true);
        }
        this.submit();
    });
    jQuery('.add_commas').each(function () {
        var dec = 2;
        var dattr = jQuery(this).attr('data-decimals');
        if (typeof dattr !== typeof undefined && dattr !== false) {
            dec = parseInt(dattr);
        }
        jQuery(this).text(add_commas(jQuery(this).text(), dec));
    });
    
    jQuery('#li_system_menu').click(function () {
        var smenu = jQuery('#ske_menu');
        var gear_icon = jQuery(this).find('.fa-cog');
        smenu.show();
        smenu.offset({top: gear_icon.offset().top + 20,
                left: gear_icon.offset().left - smenu.outerWidth() + 24});
        return false;
    });

    jQuery(document).click(function (e) {
        if (!jQuery('#ske_menu').is(e.target)
                && !jQuery('#a_open_ske_menu').is(e.target)
                && !jQuery('[name="uilang"]').is(e.target)) {
            jQuery('#ske_menu').hide();
        }
    });
});

function toggle_button(bid, chname, selstr, deselstr) {
    bid = bid.replace('.', '\\.');
    chname = chname.replace('.', '\\.');
    if (jQuery('#' + bid).val() == selstr) {
        jQuery('input[name="' + chname + '"]').attr("checked", "checked");
        jQuery('#' + bid).val(deselstr);
        return;
    }
    if (jQuery('#' + bid).val() == deselstr) {
        jQuery('input[name="' + chname + '"]').removeAttr("checked");
        jQuery('#' + bid).val(selstr);
    }
}

function update_button(bid, chname, selstr, deselstr) {
    bid = bid.replace('.', '\\.');
    chname = chname.replace('.', '\\.');
    if (!jQuery('input[name="' + chname + '"]:not(:checked)').length) {
        jQuery('#' + bid).val(deselstr);
        return;
    }
    if (jQuery('input[name="' + chname + '"]:checked').length == 0) {
        jQuery('#' + bid).val(selstr);
    }
}

function clear_form(elid) {
    if (jQuery('#error') != null) {
        jQuery('#error').hide();
    }
    jQuery('#' + elid).find(':input').each(function () {
        if (jQuery(this).attr("name") == "corpname") {
            return;
        }
        switch(this.type) {
            case 'password':
            case 'select-multiple':
            case 'select-one':
            case 'text':
            case 'textarea': jQuery(this).val(''); break;
            case 'checkbox':
            case 'radio': jQuery(this).removeAttr("checked");
        }
     }); 
}

function clear_fileinput(id) {
    if (jQuery('#' + id).length) {
        var obj = jQuery('#' + id);
    }
    else {
        var obj = jQuery('input[name="' + id + '"]');
    }
    obj.replaceWith('<input type="file" name="' + id + '" size="30" />');
}

function toggle_view_store(id) { // toggle show / hide and update cookie
    var el = jQuery('#' + id);
    if (el.is(':visible')) {
        el.hide();
        jQuery.cookies.set(id + '_view', 'hide', opts);
        if (id == 'texttypeel' || id == 'contextel') {
            clear_form(id);
        }
        if (jQuery('#contextel').is(':hidden')
                && jQuery('#texttypeel').is(':hidden')
                && jQuery('tbody.advanced_query').is(':hidden')
                && !jQuery('#cup_err_menu').is(':visible')
                && !jQuery('fieldset.parallel').length) {
            jQuery('.buttons').addClass('hidden');
        }
    }
    else {
        el.show();
        jQuery.cookies.set(id + '_view', 'show', opts);
        jQuery('.buttons').removeClass('hidden');
    }
}

function show_hide() { // show or hide elements according to cookies
    for (var key in jQuery.cookies.get()) { // for all cookies
        if (key.indexOf('_view', key.length - '_view'.length) !== -1) {
            el = key.replace('_view', ''); // remove end '_view'
            if (jQuery('#' + el).length != 0) { // element exists
                if (jQuery.cookies.get(key) == 'show') {
                    jQuery('#' + el).show();
                    if (el == 'contextel' || el == 'texttypeel') {
                        jQuery('.buttons').removeClass('hidden');
                    }
                }
                else {
                    jQuery('#' + el).hide();
                }
            }
        }
    }
}

function show_detail(url, params, loadtext, erase, toknum) {
    var toknum = typeof toknum !== 'undefined' ? toknum : false;
    if (toknum) {
        jQuery('.hl_kwic_detail').removeClass('hl_kwic_detail');
        jQuery('[toknum='+toknum+']').addClass('hl_kwic_detail');
    }
    jQuery('#detailframe').show();
    if (erase) {
        jQuery('#detailframecontent')
                .html('<span class="load">'+loadtext+'</span>');
    }
    jQuery.ajax({
        url: url,
        type: 'GET',
        data: params,
        complete: function (data) {
            jQuery('#detailframecontent').html(data.responseText);
        }
    });
}

function close_detail() {
    jQuery('#detailframe').hide();
    jQuery('#detailframecontent').empty();
    jQuery('.hl_kwic_detail').removeClass('hl_kwic_detail');
}

function switch_advanced(suff) { // switch simple|adv firstform
    if (!jQuery('tbody.advanced_query' + suff).length) {
        return;
    }
    if (jQuery('tbody.advanced_query' + suff).is(':visible')) {
        jQuery('tbody.advanced_query' + suff).hide();
        jQuery('.simple_query'+suff+' tr:nth-child(1) td:lt(3)')
                .css('opacity', '1');
        jQuery('.simple_query'+suff+' tr:nth-child(1) th').css('opacity', '1');
        if (jQuery('#contextel').is(':hidden')
                && jQuery('#texttypeel').is(':hidden')
                && !jQuery('fieldset.parallel').length) {
            jQuery('.buttons').addClass('hidden');
        }
        jQuery('#qnode_adv td label:nth-child(1) input').attr('checked', true);
        jQuery('#qnode_simple'+suff+' input[name="iquery'+suff+'"]').focus();
        jQuery('.cql_builder').hide();
    }
    else {
        jQuery('tbody.advanced_query'+suff).show();
        jQuery('tbody.advanced_query'+suff+' tr:gt(0)').css('opacity', '0.3');
        jQuery('tbody.advanced_query'+suff+' tr#tr_tagset_link').css('opacity', '1');
        jQuery('.buttons').removeClass('hidden');
    }
}

function switch_active_row(el, suff, type) { // switch query type in first form
    jQuery('.simple_query'+suff+' tr:nth-child(1) th').css('opacity', '0.3');
    jQuery('.simple_query'+suff+' tr:nth-child(1) td:nth-child(2)')
            .css('opacity', '0.3');
    jQuery('.advanced_query' + suff + ' tr:gt(0)').css('opacity', '0.3');
    jQuery('tbody.advanced_query'+suff+' tr#tr_tagset_link').css('opacity', '1');
    if (jQuery(el).attr('type') == 'radio') {
        var rtype = jQuery(el).val();
        jQuery('#' + rtype + suff).css('opacity', '1');
        jQuery('#' + rtype + suff).children().css('opacity', '1');
    }
    else {
        if (jQuery(el).is('th') || jQuery(el).is('td')) {
            el = jQuery(el).parent();
        }
        jQuery(el).css('opacity', '1');
        jQuery(el).children().css('opacity', '1');
        jQuery('input[name=queryselector'+suff+'][value='+type+'row]')
                .attr('checked', true);
    }
}

function store_last_sample(el) {
    var rlines = jQuery(el).closest('form').find('input[name="rlines"]').val();
    jQuery.cookies.set('last_sample_size', rlines, opts);
}

function store_ff_state() {
    try {
        var old_values = jQuery.cookies.get('ff_state').split(';');
    } catch (err) {
        var old_values = new Array();
    }
    var corpora = new Object();
    for (var i=0; i<old_values.length; i++) {
        corpora[old_values[i].split(':')[0]] = old_values[i].split(':')[1];
    }
    jQuery('input[name="sel_aligned"]').each(function () {
        var corp = jQuery(this).val();
        if (jQuery(this).is(':checked')) {
            var type = jQuery('input[name="queryselector_'+corp+'"]:checked')
                    .val();
            corpora[corp] = type.substring(0, type.length-3);
        }
        else {
            delete corpora[corp];
        }
    });
    new_values = new Array();
    jQuery.each(corpora, function (key) {
        new_values.push(key+':'+corpora[key]);
    });
    jQuery.cookies.set('ff_state', new_values.join(';'), opts);
    var main_type = jQuery('input[name="queryselector"]:checked').val();
    main_type = main_type.substring(0, main_type.length-3);
    jQuery.cookies.set('ff_main_state', main_type, opts);
}

function restore_ff_state() {
    try {
        var values = jQuery.cookies.get('ff_state').split(';');
    } catch (err) {
        var values = new Array();
    }
    for (var i=0; i<values.length; i++) {
        var corp = values[i].split(':')[0];
        var qtype = values[i].split(':')[1];
        try {
            var check = jQuery('input[name="sel_aligned"][value="'+corp+'"]');
            if (check.attr('checked')) { // remove relict from back in history
                check.click();
            }
            check.click();
            if (qtype != 'iquery') {
                switch_advanced('_'+corp);
                switch_active_row(jQuery('#'+qtype+'row_'+corp)[0],
                        '_'+corp, qtype);
            }
        } catch (err) {}
    }
    var main_state = jQuery.cookies.get('ff_main_state');
    if (main_state == 'iquery' || main_state == '') {
        jQuery('[name="iquery"]').focus();
    }
    else {
        switch_advanced('');
        jQuery('[name="'+main_state+'"]').focus();
    }
}

function check_child_radio(elem) {
    jQuery(elem).find('input[type="radio"]').attr('checked', true);
}

function redirect_to_func(formid, savefunc) {
    jQuery('#'+formid).attr('action', savefunc);
    jQuery('#'+formid).submit();
}

function cmdHideElementStore(id) {
    var el = jQuery(id).parent().children('ul');
    var divid = el.attr('id');
    var icon = jQuery(id);
    var cookie = jQuery.cookies.get('showhidden') || '';
    cookie = cookie.replace(new RegExp('\\.'+divid+'\\.', 'g'), '.');
    if (el.hasClass('hidden')) {
        el.removeClass('hidden');
        icon.removeClass('fa-plus-square-o').addClass('fa-minus-square-o');
        cookie += divid+'.';
    }
    else {
        el.addClass('hidden');
        icon.remove('fa-minus-square-o').addClass('fa-plus-square-o');
    }
    jQuery.cookies.set('showhidden', cookie, opts);
}

function loadHideElementStore() {
    var cookie = jQuery.cookies.get('showhidden') || '';
    var ids = cookie.split('.');
    jQuery('.plusminus').each(function () {
        var el = jQuery(this).parent().children('ul');
        var id = el.attr('id');
        var icon = jQuery(this).parent().children('i');
        if (jQuery.inArray(id, ids) !== -1) {
            el.removeClass('hidden');
            icon.removeClass('fa-plus-square-o').addClass('fa-minus-square-o');
        }
        else {
            el.addClass('hidden');
            icon.removeClass('fa-minus-square-o').addClass('fa-plus-square-o');
        }
    });
}

function escape_selector(str) {
    if (str) {
        return str.replace(/([:.])/g, '\\\\$1');
    }
    return str;
}

function reloadHits(conc_sett, act, pagesize, samplesize, port) {
    var freq = 100;
    var countup = 30;

    jQuery.periodic({ period: freq, decay: 1.2, max_period: 60000 },
    function() {
        jQuery.ajax({
            url: 'get_conc_sizes?ajax=1;' + conc_sett + ';port=' + port,
            type: 'POST',
            periodic: this,
            dataType: 'text',
            complete: function(data) {
                function updateNumElem(elem, newnum) {
                    elem.attr('data-num', newnum);
                    elem.html(add_commas(newnum, 2));
                }
                function incSampleSize() { // increase random sample size
                    csizen += inc;
                    npagesn += pginc;
                    if (csizen >= newcsize) { // last update
                        updateNumElem(npages_el, newnpages)
                        updateNumElem(csize_el, newcsize)
                        lpage_el.attr('href', "view?" + conc_sett + ";fromp="
                                               + newnpages);
                        if (finished) { jQuery('#counting2').hide(); }
                        return;
                    }
                    updateNumElem(csize_el, csizen);
                    updateNumElem(npages_el, npagesn);
                    npagest = npagesn.toString();
                    lpage_el.attr('href', "view?"+conc_sett+";fromp="+npagest);
                    setTimeout(function() { incSampleSize(); }, countup);
                }
                function incSize() { // increase full conc size
                    fsizen += inc;
                    npagesn += pginc;
                    if (fsizen >= newfsize) { // last update
                        updateNumElem(fsize_el, newfsize);
                        updateNumElem(npages_el, newnpages);
                        lpage_el.attr('href', "view?" + conc_sett + ";fromp="
                                              + newnpages);
                        if (finished) {
                            jQuery('#counting1').hide();
                            jQuery('#permillnote').show();
                            jQuery('#relconcsize').show();
                            jQuery('#relconcsize').html('('
                                + add_commas(relcsize.toFixed(1).toString(), 2));
                        }
                        return;
                    }
                    if (samplesize <= fsizen) {
                        jQuery('#hardcut_msg').show();
                    }
                    updateNumElem(fsize_el, fsizen);
                    updateNumElem(npages_el, npagesn);
                    npagest = npagesn.toString();
                    lpage_el.attr('href', "view?"+conc_sett+";fromp="+npagest);
                    setTimeout(function () { incSize(); }, countup);
                }
                // init elems and counters
                sizes = data.responseText.split('\n');
                if (sizes.length != 4) return;
                finished = parseInt(sizes[0]);
                newcsize = parseInt(sizes[1]);
                relcsize = parseFloat(sizes[2]);
                newfsize = parseInt(sizes[3]);
                if (finished == NaN || newcsize == NaN || relcsize == NaN
                                    || newfsize == NaN) {
                    return;
                }
                if (finished) { freq = 5; }
                fsize_el = jQuery('#fullsize');
                npages_el = jQuery('.numofpages');
                lpage_el = jQuery('.lastpage');
                newnpages = Math.ceil(newcsize / pagesize);
                npagesn = parseInt(npages_el.attr('data-num'));
                pginc = Math.round((newnpages - npagesn)
                                   / (freq * 1000.0 / countup));
                // update freq figures
                if (newfsize > 0 && act == "R") { // update sample size only
                    csize_el = jQuery('#concsize');
                    csizen = parseInt(csize_el.attr('data-num'));
                    inc = (newcsize - parseInt(csize_el.attr('data-num')))
                          / (freq * 1000 / countup);
                    inc = Math.max(1, Math.round(inc));
                    incSampleSize();
                } else { // update full size only
                    fsizen = parseInt(fsize_el.attr('data-num'));
                    inc = (newfsize - fsizen) / (freq * 1000 / countup);
                    inc = Math.max(1, Math.round(inc));
                    incSize();
                }
                if (finished) { setTimeout(this.periodic.cancel, 1000); }
            },
        });
    });
}

function select_lines() {
    var sl = sessionStorage.getItem('selected_lines');
    if (sl.length > 1) {
        jQuery('#filter_select_lines,#filter_unselect_lines').show();
    }
    else {
        jQuery('#filter_select_lines,#filter_unselect_lines').hide();
    }
    var sls = sl.split(',');
    for (var i=0; i<sls.length; i++) {
        var tn = sls[i].split(':')[0];
        var hl = sls[i].split(':')[1];
        jQuery('tr[toknum="' + tn + '"][hitlen="' + hl + '"]')
                .addClass('selected')
                .find('input[type="checkbox"]').prop('checked', true);
    }
}

function select_diff_by(diff_by) {
    if (diff_by == '') {
        diff_by = jQuery('input[name="diff_by"]').val();
    }
    if (diff_by == 'lemma') {
        jQuery('.bywordform input, .bysubcorpus select').prop('disabled', true);
        jQuery('.bylemma input').prop('disabled', false);
    }
    else if (diff_by == 'subcorpus') {
        jQuery('.bywordform input, .bylemma input').prop('disabled', true);
        jQuery('.bysubcorpus select').prop('disabled', false);
    }
    else if (diff_by == 'word form') {
        jQuery('.bywordform input').prop('disabled', false);
        jQuery('.bysubcorpus select, .bylemma input').prop('disabled', true);
    }
}

function switch_all_commex(v) {
  if (v == 'all') {
      jQuery('#maxexclusive').prop('disabled', true);
  }
  else {
      jQuery('#maxexclusive').prop('disabled', false);
  }
}

function select_output_type(type) {
  var sel = jQuery('[name="wltype"]:checked').val();
  if (sel != "undefined" && sel !== type) {
      type = sel;
  }
  var wlform = jQuery('#wordlist_form');
  var kwinputs = jQuery('#ref_corpname, #ref_usesubcorp, #simple_n');
  var mlinputs = jQuery('#wlstruct_attr1, #wlstruct_attr2, #wlstruct_attr3');
  switch (type) {
    case 'simple':
      wlform.attr('action', 'wordlist');
      kwinputs.add(mlinputs).prop('disabled', true);
      jQuery("#simple_n_slider").noUiSlider("disabled", true);
      break;
    case 'keywords':
      wlform.attr('action', 'wordlist');
      kwinputs.prop('disabled', false);
      mlinputs.prop('disabled', true);
      jQuery("#simple_n_slider").noUiSlider("disabled", false);
      break;
    case 'multilevel':
      wlform.attr('action', 'struct_wordlist');
      kwinputs.prop('disabled', true);
      mlinputs.prop('disabled', false);
      jQuery("#simple_n_slider").noUiSlider("disabled", true);
      break;
  }
}

function check_value(type, value) {
    switch (type) {
        case "integer":
            return check_integer(value);
        case "pos_integer":
            return check_integer(value) && (parseInt(value) > 0);
        case "pos_integer_zero":
            return check_integer(value) && (parseInt(value) >= 0);
        case "pos_integer_zero_auto":
            return (value == 'auto') ||
                    (check_integer(value) && (parseInt(value) >= 0));
        case "hundred":
            return check_integer(value) && (parseInt(value) >= 0) &&
                    (parseInt(value) <= 100);
        case "float":
            return check_float(value);
        case "empty":
            return value !== "";
        case "symbols":
            return check_symbols(value);
    }
}

function check_integer(value) {
    if (isNaN(value)) {
        return false;
    }
    var val = parseInt(value);
    if (val.toString() != value) {
        return false;
    }
    return true;
}

function check_float(value) {
    if (!isNaN(value)) {
        return true;
    }
    return false;
}

function check_symbols(value) {
    var re = /[\\%&@"'(){}\[\].\-\/:+^$!?#*|;,`~ ><]/;
    if (!re.exec(value)) {
        return true;
    }
    return false;
}

function toggle_mchoice(eid, chb) {
    jQuery('#' + eid).find('input[type="checkbox"]')
            .prop('checked', jQuery(chb).is(':checked')).change();
}

function show_line_numbers() {
    jQuery('[toknum]').each(function (i, val) {
        jQuery(this).prepend(jQuery('<td class="lnum">'+(i+1)+'</td>'));
    });
}

function num2slider(number) {
    try {
        return Math.max(Math.min(6, Math.floor(Math.log(parseInt(number))
                / Math.LN10)), -2);
    }
    catch (err) {
        return 2;
    }
}

function save_options_ajax(el, address) {
    var form = jQuery(el).closest('form');
    var params = form.serialize();
    jQuery.ajax({
        url: address + '?' + params,
        success: function () {
            jQuery('#saved_message').show();
            setTimeout(function () {
                jQuery('#saved_message').fadeOut("slow");
            }, 10000);
            jQuery(el).prop('disabled', true);
        }
    });
}

function permalink(prefix, url, username) {
    window.open(prefix + '?from_ske=1&username=' + username + '&url=' +
            encodeURIComponent(window.location.href + url), '_blank');
}

function shorten_long_refs() {
    jQuery('.ref').each(function () {
        var full = jQuery(this).text();
        if (full.length > 12) {
            jQuery(this).text(full.slice(0, 10) + '...');
            var hoverdiv = jQuery('<div/>');
            hoverdiv.addClass('refdiv').text(full);
            jQuery(this).append(hoverdiv);
            jQuery(this).hover(
                function () { jQuery(this).find('div').show(); },
                function () { jQuery(this).find('div').hide(); }
            );
        }
    });
}

function check_job_processing(jobid) {
    jQuery.periodic({ period: 2000, decay: 1.0 },
        function () {
            jQuery.ajax({
                url: 'jobproxy?ajax=1;task=job_progress;jobid=' + jobid,
                        periodic: this,
                complete: function (data) {
                    eval('data = ' + data.responseText);
                    if (data.hasOwnProperty('signal')) {
                        var signal = JSON.parse(data.signal);
                        if (signal.length == 0) { // finished
                            this.periodic.cancel();
                            window.location.reload(true);
                        }
                        else {
                            if (signal[0].status[0] == 'err') { // failed
                                this.periodic.cancel();
                                jQuery('#processper').text(jQuery('#processbar').data('err-msg-short'));
                                jQuery('#esttime').text(jQuery('#processbar').data('err-msg'));
                            }
                            else { // in progress
                                jQuery('#processbar').css('width', (signal[0].progress-1) + '%');
                                jQuery('#processper').text(signal[0].progress + '%');
                                jQuery('#esttime').text(signal[0].esttime);
                            }
                        }
                    }
                    else {
                        jQuery('#processbar').css('width', '0%');
                        jQuery('#processper').text('0%');
                        jQuery('#esttime').text('N/A');
                    }
                }
            });
        }
    );
}

function change_wl_form_method() {
    if (jQuery('#wlfile').val() == '' &&
            jQuery('#wlblacklist').val() == '') {
        jQuery('#wordlist_form').attr('method', 'get');
    }
}

function add_commas(num, dec) {
    var parts = num.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    if (parts.length > 1) {
        if (parts[1].length >= dec) {
            parts[1] = parts[1].substring(0, dec);
        }
        else {
            parts[1] += Array(dec-parts[1].length+1).join('0');
        }
    }
    return parts.join(".");
}

function highlight_aligned_kwics(data, corp) {
    jQuery.each(data.toknum2words, function (toknum, lemma) {
        var ptd = jQuery('tr[toknum="' + toknum + '"] td.par[data-parcorp="' + corp + '"] span:not(.nott):not(.attr_tooltip)');
        var ptdt = jQuery.trim(ptd.text()).split(' '); // TODO: better tokenization
        var poses = new Array();
        if (!data.dict[lemma].length && !data.dict[lemma.toLowerCase()].length) {
            return true;
        }
        if (data.dict[lemma]) {
            var trans = data.dict[lemma];
            var pos = subInArray(trans, ptdt);
            poses = poses.concat(pos);
        }
        if (data.dict[lemma.toLowerCase()]) {
            var trans = data.dict[lemma.toLowerCase()];
            var pos = subInArray(trans, ptdt);
            poses = poses.concat(pos);
        }
        var new_ptd = jQuery('<span></span>');
        for (var i=0; i<ptdt.length; i++) {
            var ptdti = jQuery.trim(ptdt[i]);
            if (!ptdti) {
                new_ptd.append(' ');
                continue;
            }
            var wspan = jQuery('<span>' + ptdti + '</span>');
            if (poses.indexOf(i) > -1) {
                wspan.addClass('transkwic');
            }
            new_ptd.append(wspan);
            new_ptd.append(' ');
        }
        ptd.empty();
        ptd.append(new_ptd);
    });
}

function subInArray(item, list) {
    var retlist = new Array();
    var ranklist = new Array();
    var minj = 100;
    for (var i=0; i<list.length; i++) {
        var llitem = list[i].toLowerCase();
        for (var j=0; j<item.length; j++) {
            if (item[j].length < 3) { // skip short translations (I, in, on)
                continue;
            }
            var lpos = llitem.indexOf(item[j].toLowerCase());
            if (lpos > -1) {
                if (j < minj) minj = j;
                retlist.push(i);
                ranklist.push(j);
                break;
            }
        }
    }
    // remove all but the highest-scored translations
    var finallist = new Array();
    for (var i=0; i<retlist.length; i++) {
        if (ranklist[i] == minj) {
            finallist.push(retlist[i]);
        }
    }
    return finallist;
}

function add_selected_line(toknum, hl) {
    sessionStorage.setItem('selected_lines',
            sessionStorage.getItem('selected_lines') + ',' + toknum + ':' + hl);
    jQuery('#filter_unselect_lines,#filter_select_lines').show();
}

function remove_selected_line(toknum, hl) {
    var old = sessionStorage.getItem('selected_lines').split(',');
    var toknums = new Array();
    for (var i=0; i<old.length; i++) {
        if (old[i] == '') {
            continue;
        }
        if (old[i] != (toknum + ':' + hl)) {
            toknums.push(old[i]);
        }
    }
    if (toknums.length) {
        sessionStorage.setItem('selected_lines', toknums.join(','));
    }
    else {
        sessionStorage.setItem('selected_lines', '');
        jQuery('#filter_unselect_lines,#filter_select_lines').hide();
    }
}

function do_ajax_notification (jobid, key) {
  jQuery.ajax({
    url: 'jobproxy?ajax=1&task=job_change&jobid=' + jobid + '&key=' + key
  });
}

function add_notification (jobid, email) {
  if (!email.length) { return undefined; }
  if (jQuery("#notify").prop("checked")) {
    do_ajax_notification (jobid, 'notify');
  }
  else {
    do_ajax_notification (jobid, 'notifyrm');
  }
}
