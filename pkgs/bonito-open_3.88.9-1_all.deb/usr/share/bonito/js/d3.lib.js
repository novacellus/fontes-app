// frequency distribution graph with D3 library
function draw_freq_distrib(data, url, concpos_msg, freq_msg) {
    var margin = {top: 10, right: 20, bottom: 40, left: 30};
    var width = dyn_sizes(data.length, 'svg') - margin.left - margin.right;
    var height = 250 - margin.top - margin.bottom;
    var frmtPerc = d3.format(".0%");
    var x = d3.scale.linear().range([0, width]);
    var y = d3.scale.linear().range([height, 0]);
    var xAxis = d3.svg.axis().scale(x).orient("bottom").tickFormat(frmtPerc);
    var yAxis = d3.svg.axis().scale(y).orient("right").ticks(0);
    var svg = d3.select("#svg_plot").append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom).append("g")
        .attr("transform", "translate("+margin.left+","+margin.top+")");
    x.domain([0, Math.round(d3.max(data, function(d) { return d.pos; }))]);
    y.domain([0, d3.max(data, function(d) { return d.frq; })]);
    svg.selectAll(".bar").data(data).enter().append("rect").attr("class", "bar")
        .attr("x", function(d) { return x(d.pos); })
        .attr("width", function(d) { return dyn_sizes(data.length, 'bar'); })
        .attr("y", function(d) { return y(d.frq); })
        .attr("height", function(d) { return height - y(d.frq); })
        .on("mouseover", function (d) {
            d3.select(this).classed('active', true);
        })
        .on('mouseout', function (d) {
            d3.select(this).classed('active', false);
        })
        .on('click', function (d) {
            if (d.beg < d.end) {
                window.location.href = url + d.beg + '-' + d.end + '];';
            }
        });
    svg.append("g").attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")").call(xAxis)
        .append("text").attr("x", width).attr("y", 35).attr("class", "legend")
        .style("text-anchor","end").text(concpos_msg);
    svg.append("g").attr("class", "y axis").call(yAxis).append("text")
        .attr("transform", "rotate(-90)").attr("y", -20).attr("dy", ".71em")
        .attr("class", "legend").style("text-anchor", "end")
        .text(freq_msg);
}

//draw wordcloud for thesaurus words
function draw(words) {
    var cloud = d3.select("#wordcloud").append("svg")
        .attr("width", 500)
        .attr("height", 300)
        .append("g")
        .attr("transform", "translate(250,150)");
    cloud.selectAll("text")
        .data(words)
        .enter().append("text")
        .style("font-size", function(d) { return d.size + "px"; })
        .style("fill", function(d, i) { return fill(i); })
        .attr("text-anchor", "middle")
        .attr('letter-spacing', '-1px')
        .attr("transform", function(d) {
            return "translate(" + [d.x, d.y] + ")";
        })
        .text(function(d) { return d.text; })
}

function draw_skell_cloud(words) {
    var cloud = d3.select("#wordcloud").append("svg")
        .attr("width", 380)
        .attr("height", 240)
        .append("g")
        .attr("transform", "translate(190,120)");
    cloud.selectAll("text")
        .data(words)
        .enter().append("text")
        .style("font-size", function(d) { return d.size + "px"; })
        .style("fill", function(d, i) { return fill(i); })
        .attr("text-anchor", "middle")
        .attr('letter-spacing', '-1px')
        .attr("transform", function(d) {
            return "translate(" + [d.x, d.y] + ")";
        })
        .text(function(d) { return d.text; })
}

function dyn_sizes(res, what) {
    if (what == 'svg') return 700 + Math.round(((res-100)/900)*1200);
    if (what == 'bar') return Math.max(1, 5-Math.ceil(((res-100)/900)*5));
}
