jQuery.fn.dataTableExt.oSort['absolute-asc']  = function(x,y) {
  return Math.abs(x) - Math.abs(y);
};
jQuery.fn.dataTableExt.oSort['absolute-desc'] = function(x, y) {
  return Math.abs(y) - Math.abs(x);
};
jQuery.fn.dataTableExt.oSort['numeric-html-asc']  = function(a,b) {
  a = parseInt(jQuery(a).text());
  b = parseInt(jQuery(b).text());
  return ((a < b) ? -1 : ((a > b) ?  1 : 0));
};
jQuery.fn.dataTableExt.oSort['numeric-html-desc']  = function(a,b) {
  a = parseInt(jQuery(a).text());
  b = parseInt(jQuery(b).text());
  return ((a < b) ? 1 : ((a > b) ?  -1 : 0));
};
