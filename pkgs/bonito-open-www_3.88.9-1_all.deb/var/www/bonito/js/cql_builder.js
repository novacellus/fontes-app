// CQL builder for Sketch Engine
// 2016 Copyright  Pavel Bernat, Vit Baisa

var row_number = 0; //variable storing current number of queries with assigned number for global conditions
var corp_info; //stored info about corpora
var time_disabled_CONSTANT = 150; //constant, sets how long (in ms) is button disbled after click

jQuery.fn.visible = function() {
    return this.css('visibility', 'visible');
};

jQuery.fn.invisible = function() {
    return this.css('visibility', 'hidden');
};

jQuery.fn.visibilityToggle = function() {
    return this.css('visibility', function(i, visibility) {
        return (visibility == 'visible') ? 'hidden' : 'visible';
    });
};

jQuery.fn.timedDisable = function(time) {
    if (time == null) { time = time_disabled_CONSTANT; }
    return jQuery(this).each(function() {
        jQuery(this).prop('disabled', true);
        var disabledElem = jQuery(this);
        setTimeout(function() {
            disabledElem.prop('disabled',false);
        }, time);
    });
};

// initialization

jQuery(document).ready(function() {
    jQuery(".cql_builder").addClass("loading");
    jQuery.ajax({
        // TODO no need of corpinfo?
        url: 'corp_info?corpname='+ jQuery(".cql_builder #corp_name").text() + ';format=json;registry=1',
        complete: function (data) {
            corp_info = JSON.parse(data.responseText);
            var registry = corp_info.registry_dump;
            loadAttributes(corp_info.attrs);
            loadThesaurus(registry);
            loadWithin(registry);
            loadStructures(corp_info.structs);
            loadWSRelations(corp_info.gramrels);
            jQuery(".cql_builder").removeClass("loading");
            jQuery(".cql_builder #cb_container").empty();
            jQuery(".cql_builder .advanced").hide();
            jQuery(".cql_builder .global_conditions_header").hide();
            jQuery(".cql_builder [name=type]").trigger("change");
            jQuery(".cql_builder [name=repetitions]").trigger("change");
            if (jQuery.cookies.get('cql_builder_advanced') == '1') {
                jQuery('#advanced').prop('checked', true).change();
            }
            out();
        }
    });
});

function loadWithin(registry) {
    var parallel = jQuery(".cql_builder [name=parallel]");
    jQuery(parallel).empty();
    var pos = registry.search("ALIGNED");
    // get directly from Bonito
    if (pos != -1) {
        var help = registry.substr(pos).split('"');
        var aligned = help[1].split(',');
        for (name in aligned) {
            if (aligned[name].length > 0) {
                jQuery(parallel).append("<option value=\"" + aligned[name] +"\">" + aligned[name]  + "</option>");
            }
        }
    }
    var options = jQuery(parallel).children();
    if (options.length==0) {
        jQuery(".cql_builder .parallel").remove();
        jQuery(".cql_builder .within_parallel").remove();
    }
    for (var i=0; i<options.length; i++) {
        loadNameOfCorpora(jQuery(options[i]));
    }
}

function loadNameOfCorpora(option) {
    value = jQuery(option).prop("value");
    jQuery.ajax({
        url: 'corp_info?corpname='+ value + ';format=json',
        complete: function (data) {
            var name = JSON.parse(data.responseText).name;
            jQuery(option).text(name);
        }
    });
}

function loadWSRelations(options) {
    jQuery(".cql_builder #WordSketchTemplate [name=rel]").empty();
    for (index in options) {
        jQuery(".cql_builder #WordSketchTemplate [name=rel]").append("<option>" + options[index][1] + "</option>");
    }
}

jQuery(document).on('change', '[name=attr]', function() {
    var attr_name = jQuery(this).find(":selected").val();
    if (attr_name === "tag") {
        var tags = corp_info.wposmap;
        if (tags.length > 0) {
            jQuery(this).closest('.table').find("[name=val]").replaceWith("<select class=\"cell select\" name=\"val\">");
            for (value in tags) {
                jQuery(this).closest('.table').find("[name=val]").append("<option class=\"dynam\" value=" + tags[value][1]  + " >" + tags[value][0] + "</option>");
            }
        }
        else {
            jQuery(this).closest('.table').find("[name=val]").replaceWith("<input type=\"text\" class=\" cell input\" name=\"val\">");
        }
    }
    else {
        jQuery(this).closest('.table').find("select[name=val]").replaceWith("<input type=\"text\" class=\" cell input\" name=\"val\">");
    }
});

function loadAttributes(attribs) {
    jQuery(".cql_builder #AttributeValueTemplate [name=attr]").empty();
    jQuery(".cql_builder [name=positionAttrib1]").empty();
    jQuery(".cql_builder [name=positionAttrib2]").empty();
    for (attr in attribs) {
        var value = attribs[attr][0];
        var label = attribs[attr][2];
        if (label.length == 0) {
            label = value;
        }
        jQuery(".cql_builder #AttributeValueTemplate [name=attr]").append("<option value=\"" + value + "\">" + label + "</option>");
        jQuery(".cql_builder [name=positionAttrib1]").append("<option value=\"" + value + "\">" + label + "</option>");
        jQuery(".cql_builder [name=positionAttrib2]").append("<option value=\"" + value + "\">" + label + "</option>");
    }
}

function loadThesaurus(registry) {
    var thesaurSelect = jQuery(".cql_builder [name=thesaurAttr]");
    jQuery(thesaurSelect).empty();
    var attributes = jQuery(".cql_builder #AttributeValueTemplate [name=attr]");
    var pos = registry.search("WSATTR");
    if (pos!=-1) {
        var help = registry.substr(pos).split('"');
        var thes = help[1].split(',');
        for (att in thes) {
            if (thes[att].length > 0) {
                jQuery(thesaurSelect).append("<option value=\"" + thes[att] +"\">" + jQuery(attributes).find("[value=" + thes[att] +"]").text() + "</option>");
            }
        }
    }
    if (jQuery(thesaurSelect).children().length == 0) {
        var attr;
        if (jQuery(attributes).children("[value=lempos_lc]").length > 0) {
            attr = "lempos_lc";
        }
        else if (jQuery(attributes).children("[value=lempos]").length > 0) {
            attr = "lempos";
        }
        else if (jQuery(attributes).children("[value=lemma_lc]").length > 0) {
            attr = "lemma_lc";
        }
        else if (jQuery(attributes).children("[value=lemma]").length > 0) {
            attr = "lemma";
        }
        else {
            var pos = registry.search("DEFAULTATTR");
            if (pos!=-1) {
                var help2 = registry.substr(pos).split('"');
                attr  = help2[1].split(',');
            }
        }
        jQuery(attributes).children("[value="+ attr +"]").clone().appendTo(jQuery(thesaurSelect));
    }
}

function loadStructures(structs) {
    var str = jQuery(".cql_builder #StructureTemplate [name=struct_name]");
    jQuery(str).empty();
    var doc = "";
    var s = "";
    var p = "";
    var help = "";
    for (struct in structs) {
        var name = structs[struct][0]
        if (name.match(/^s$/i)) {
            s = name;
            help = "sentence";
        }
        else if (name.match(/^p$/i)) {
            p = name;
            help = "paragraph";
        }
        else if (name.match(/doc$/i)) {
            doc = name;
            help = "document";
        }
        else help = name;
        jQuery(str).append("<option value=\""+ name +"\">" + help + "</option>");
        help = "";
    }
    if (!s) jQuery(".cql_builder #addSentenceButton").remove();
    if (!p) jQuery(".cql_builder #addParagraphButton").remove();
    if (!doc) jQuery(".cql_builder #addDocumentButton").remove();
}

jQuery(document).on('change', '[name=struct_name]', function() {
    jQuery(this).closest('.row_container').children(".attriblist").empty();
    out();
    jQuery(this).closest('.row_container').find('.struct-add-attrib').show();
    jQuery(".cql_builder").find("#StructAttribTemplate").find('[name=struct_attrib]').children(".dynam").remove();
    var struct_index = -1;
    var struct_name;
    var structures = corp_info.structs;
    if (jQuery(this).closest(".row_container").hasClass("doc")) {
        struct_name = jQuery(this).find("[value$=doc]").val();
    }
    else {
        struct_name = jQuery(this).find(":selected").val();
    }
    for (struct in structures) {
        var name = structures[struct][0];
        if (name === struct_name) {
            var attributes = structures[struct][2];
            for (attr in attributes) {
                var label = attributes[attr][1];
                var value = attributes[attr][0].replace(name + ".","");
                jQuery(".cql_builder #StructAttribTemplate [name=struct_attrib]").append("<option class=\"dynam\" value=" + value +" >" + label + "</option>");
            }
        }
    }
});

function GetTemplate(a) {
    var jQueryhtml = jQuery(a).clone();
    return jQueryhtml.html();
}

jQuery(document).on('click', '#addAttribValue', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#AttributeValueTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).find("[name=attr]").change();
});

jQuery(document).on('click', '#addAnyToken', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#AnyTokenTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    out();
});

jQuery(document).on('click', '#addPosition', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#PositionTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).find("[name=attr]").change();
    jQuery(html).find(".position2").hide();
    out();
});

jQuery(document).on('click', '#addThesaurus', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#ThesaurusTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).find("[name=thesaurAttr]").change();
});

jQuery(document).on('click', '#addWordSketch', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#WordSketchTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).find(".seek").hide();
    out();
});

jQuery(document).on('click', '#addTerm', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#TermTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    out();
});

jQuery(document).on('click', '#addWithin', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#WithinTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    out();
    jQuery(html).find(".parallel").invisible();
});

jQuery(document).on('click', '#addContaining', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#ContainingTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    out();
    jQuery(html).find(".parallel").invisible();
});

jQuery(document).on('click', '#addDocument', function() {
    jQuery(this).timedDisable();
    if (jQuery(".cql_builder #advanced:checked").length == 0 && jQuery("#cb_container").children().last().find(".within").length == 0) {
        jQuery(".cql_builder #addWithin").click();
    }
    var html = jQuery('<div/>', {
       'class' : 'container doc row_container',html: GetTemplate("#StructureTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).children(".structure").addClass("document");
    jQuery(html).find(".struct_name").hide();
    jQuery(html).find(".name").text("Document");
    jQuery(html).find("[name=struct_name]").change();
});

jQuery(document).on('click', '#addSentence', function() {
    jQuery(this).timedDisable();
    if (jQuery(".cql_builder #advanced:checked").length == 0 && jQuery("#cb_container").children().last().find(".within").length == 0) {
        jQuery(".cql_builder #addWithin").click();
    }
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#StructureTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).children(".structure").addClass("sentence");
    jQuery(html).find(".struct-add-attrib").hide();
    jQuery(html).find(".struct_name").hide();
    jQuery(html).find(".name").text("Sentence");
    out();
});

jQuery(document).on('click', '#addParagraph', function() {
    jQuery(this).timedDisable();
    if (jQuery(".cql_builder #advanced:checked").length == 0 && jQuery("#cb_container").children().last().find(".within").length == 0) {
        jQuery(".cql_builder #addWithin").click();
    }
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#StructureTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).children(".structure").addClass("paragraph");
    jQuery(html).find(".struct-add-attrib").hide();
    jQuery(html).find(".struct_name").hide();
    jQuery(html).find(".name").text("Paragraph");
    out();
});

jQuery(document).on('click', '#addStructure', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#StructureTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).find("[name=struct_name]").change();
});

jQuery(document).on('click', '#addMeet', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#MeetTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).find("[name=meet-type1]").change();
    jQuery(html).find("[name=meet-type2]").change();
});

jQuery(document).on('click', '#addUnion', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#UnionTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).find("[name=union-type1]").change();
    jQuery(html).find("[name=union-type2]").change();
});

jQuery(document).on('click', '#addSwap', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#SwapTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).find("[name=swap-type]").change();
});

jQuery(document).on('click', '#addCcoll', function() {
    jQuery(this).timedDisable();
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#CcollTemplate")
    }).appendTo(jQuery(".cql_builder #cb_container"));
    jQuery(html).find("[name=ccoll-type]").change();
});

jQuery(document).on('click', '.remove', function() {
    jQuery(this).closest('.row_container').find(".number").hide();
    if (jQuery(this).closest('.row_container').parent("#cb_container").length > 0) { //is direct child ov cb_container
        jQuery(this).closest('.row_container').remove();
        out();
    }
    else if (jQuery(this).closest('.bool-container').length>0) { //is in boolean expresion
        var html = jQuery(this).closest('.row_container').siblings().first().detach();
        if (jQuery(this).closest('.bool-container').parent().closest('.bool-container').length==0) { //the boolean expr is not in other boolean
            jQuery(this).closest('.bool-container').closest('.row_container').after(jQuery(html).removeClass("bool"));
            if (jQuery(this).closest('.bool-container').parent().parent('.meetOrUnion-container,.swapOrCcoll-container').length>0) { //boolean is child of meet or union or swap or ccoll
                jQuery(html).children(".dynam").find(".remove").invisible();
                jQuery(html).children(".dynam").find(".negation").hide();
                jQuery(html).children(".dynam").find(".interval").hide();
            }
            else {
                if (jQuery(".cql_builder #advanced:checked").length > 0) {
                    jQuery(html).find(".interval").show();
                    jQuery(html).find("[name=repetitions]").val(1);
                    jQuery(html).find(".intervalN").hide();
                    jQuery(html).find(".intervalK").hide();
                }
            }
        }
        else {
            jQuery(this).closest('.bool-container').closest('.row_container').after(jQuery(html));
        }
        jQuery(this).closest('.bool-container').closest('.row_container').remove();
        out();
    }
    else if (jQuery(this).closest('.attriblist').length>0) { //is structure attributte
        if (jQuery(this).closest('.row_container').parent('.attriblist').length>0) { //is not in boolean
            jQuery(this).closest('.attriblist').parent().find(".struct-add-attrib").show();
            jQuery(this).closest('.row_container').remove();
            out();
        }
        else { //is in boolean
            var html = jQuery(this).closest('.row_container').siblings().first().detach();
            if (jQuery(this).closest('.attrib_bool').parent().closest('.attrib_bool').length==0) { //the boolean is in another boolean
                jQuery(this).closest('.attrib_bool').closest('.row_container').after(jQuery(html).removeClass("bool"));
            }
            else {
                jQuery(this).closest('.attrib_bool').closest('.row_container').after(jQuery(html));
            }
            jQuery(this).closest('.attrib_bool').closest('.row_container').remove();
        }
        out();
    }
    else if (jQuery(this).closest("#condition_container").length > 0) { //is a condition
        jQuery(this).closest('.row_container').remove();
        out();
    }
});

jQuery(document).on('click', '.boolAnd', function() {
    var html = jQuery('<div/>', {
       'class' : 'container row_container AND',html: GetTemplate("#BooleanTemplate")
    }).insertAfter(jQuery(this).closest('.row_container'));
    jQuery(html).find(".operatorLabel").text("AND");
    jQuery(this).closest('.row_container').detach().appendTo(jQuery(html).children(".bool-container")).addClass("bool");
    jQuery(this).closest(".row_container").clone().appendTo(jQuery(html).children(".bool-container")).find("[name=attr]").change();
    if (jQuery(html).closest('.bool-container').length>0) {
        jQuery(html).find(".interval").hide();
    }
    else {
        jQuery(html).children(".bool-container").find(".interval").hide();
    }
    if (jQuery(html).parent('.meetOrUnion-container').length>0 || jQuery(html).parent('.swapOrCcoll-container').length>0) {
        jQuery(html).find(".interval").hide();
        jQuery(html).children(".boolean").find(".remove").invisible();
        jQuery(html).find(".bool-container").find(".remove").visible();
        jQuery(html).find(".bool-container").find(".negation").show();
    }
    out();
});

jQuery(document).on('click', '.boolOr', function() {
    var html = jQuery('<div/>', {
       'class' : 'container row_container OR',html: GetTemplate("#BooleanTemplate")
    }).insertAfter(jQuery(this).closest('.row_container'));
    jQuery(html).find(".operatorLabel").text("OR");
    jQuery(this).closest('.row_container').detach().appendTo(jQuery(html).children(".bool-container")).addClass("bool");
    jQuery(this).closest(".row_container").clone().appendTo(jQuery(html).children(".bool-container")).find("[name=attr]").change();
    if (jQuery(html).closest('.bool-container').length>0) {
        jQuery(html).find(".interval").hide();
    }
    else {
        jQuery(html).children(".bool-container").find(".interval").hide();
    }
    if (jQuery(html).parent('.meetOrUnion-container').length>0 || jQuery(html).parent('.swapOrCcoll-container').length>0) {
        jQuery(html).find(".interval").hide();
        jQuery(html).children(".boolean").find(".remove").invisible();
        jQuery(html).find(".bool-container").find(".remove").visible();
        jQuery(html).find(".bool-container").find(".negation").show();
    }
    out();
});

jQuery(document).on('click', '.struct-add-attrib', function() {
    var html = jQuery('<div/>', {
       'class' : 'container row_container',html: GetTemplate("#StructAttribTemplate")});
    jQuery(this).hide();
    jQuery(html).appendTo(jQuery(this).closest(".row_container").children(".attriblist"));
    jQuery(html).find('.struct_value').hide();
    jQuery(html).find('.struct_position').hide();
    jQuery(html).find('.struct_position_range').hide();
    jQuery(html).find('[name=struct_attrib]').trigger("change");
});

jQuery(document).on('click', '.structAttribAnd', function() {
    var html = jQuery('<div/>', {
       'class' : 'container row_container AND',html: GetTemplate("#StructAttribBoolTemplate")
    }).insertAfter(jQuery(this).closest('.row_container'));
    jQuery(html).find(".operatorLabel").text("AND");
    jQuery(this).closest('.row_container').detach().appendTo(jQuery(html).children(".attrib_bool")).addClass("bool");
    jQuery(this).closest('.row_container').clone().appendTo(jQuery(html).children(".attrib_bool")).find("[name=struct_attrib]").change();
});

jQuery(document).on('click', '.structAttribOr', function() {
    var html = jQuery('<div/>', {
       'class' : 'container row_container OR',html: GetTemplate("#StructAttribBoolTemplate")
    }).insertAfter(jQuery(this).closest('.row_container'));
    jQuery(html).find(".operatorLabel").text("OR");
    jQuery(this).closest('.row_container').detach().appendTo(jQuery(html).children(".attrib_bool")).addClass("bool");
    jQuery(this).closest('.row_container').clone().appendTo(jQuery(html).children(".attrib_bool")).find("[name=struct_attrib]").change();
});

jQuery(document).on('click', '#AddCondition', function() {
    var html = jQuery('<div/>', {
        'class' : ' row_container container', html: GetTemplate('#ConditionTemplate')
        }).appendTo(jQuery(".cql_builder #condition_container"));
    html.find('.conditionValue').hide();
    html.find("[name=conditionOper] .function").hide();
    out();
});

jQuery(document).on('change', '#advanced', function() {
    jQuery(".cql_builder").find(".advanced").each(function(element) {
        if (jQuery(this).closest('.meetOrUnion-container').length==0) {
            if (jQuery(this).hasClass("interval")) {
                if (jQuery(this).closest('.bool-container').length>0) {
                    jQuery(this).hide();
                }
                else {
                    if (jQuery(".cql_builder #advanced:checked").length > 0) {
                        jQuery(this).show();
                    }
                    else {
                        jQuery(this).hide();
                    }
                }
            }
            else if (jQuery(this).hasClass("within_parallel")) {
                if (jQuery(".cql_builder #advanced:checked").length > 0) {
                    jQuery(this).show();
                }
                else {
                    jQuery(this).hide();
                }
                jQuery(this).prop('checked', false);
            }
            else if (jQuery(this).hasClass("struct_pos")) {
                if (jQuery(".cql_builder #advanced:checked").length > 0) {
                    jQuery(this).show();
                }
                else {
                    jQuery(this).hide();
                }
                jQuery(this).children("[name=struct_pos]").val(3);
            }
            else {
                if (jQuery(".cql_builder #advanced:checked").length > 0) {
                    jQuery(this).show();
                }
                else {
                    jQuery(this).hide();
                }
            }
        }
    });
    if (jQuery(this).is(':checked')) {
        jQuery.cookies.set('cql_builder_advanced', '1');
    }
    else {
        jQuery.cookies.set('cql_builder_advanced', '0');
    }
});

jQuery(document).on('keyup', '.cql_builder input', function() {
    out();
});

jQuery(document).on('keyup', '.cql_builder select', function() {
    out();
});

jQuery(document).on('change', '[name=default_attr]', function() {
    out();
});

jQuery(document).on('change', '.row', function() {
    out();
});

jQuery(document).on('change', '[name=range]', function() {
    jQuery(this).closest(".dynam").find(".position2").toggle();
    out();
});

jQuery(document).on('change', '[name=ws_type]', function() {
    jQuery(this).closest(".dynam").find(".seek").toggle();
    jQuery(this).closest(".dynam").find(".triple").toggle();
    out();
});

jQuery(document).on('change', '[name=struct_position_range]', function() {
    jQuery(this).closest(".dynam").find(".struct_position_range").toggle();
    out();
});

jQuery(document).on('change', '[name=within_parallel]', function() {
    jQuery(this).closest(".dynam").find(".parallel").visibilityToggle();
    out();
});

jQuery(document).on('change', '[type=checkbox]', function() {
    out();
});

jQuery(document).on('change', '[name=meet-type1]', function() {
    addMember(jQuery(this).closest(".dynam").find("[data-name=meet1]"),jQuery(this).val());
});

jQuery(document).on('change', '[name=meet-type2]', function() {
    addMember(jQuery(this).closest(".dynam").find("[data-name=meet2]"),jQuery(this).val());
});

jQuery(document).on('change', '[name=union-type1]', function() {
    addMember(jQuery(this).closest(".dynam").find("[data-name=union1]"),jQuery(this).val());
});

jQuery(document).on('change', '[name=union-type2]', function() {
    addMember(jQuery(this).closest(".dynam").find("[data-name=union2]"),jQuery(this).val());
});

jQuery(document).on('change', '[name=swap-type]', function() {
    addMember(jQuery(this).closest(".dynam").find("[data-name=swap]"),jQuery(this).val());
});

jQuery(document).on('change', '[name=ccoll-type]', function() {
    addMember(jQuery(this).closest(".dynam").find("[data-name=ccoll]"),jQuery(this).val());
});

function addMember(element, type) {
    jQuery(element).empty();
    var html;
    var number = parseInt(type,10);
    switch (number) {
        case 1:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#AttributeValueTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            jQuery(html).find("[name=attr]").change();
            break;
        case 2:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#AnyTokenTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            break;
        case 3:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#PositionTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            jQuery(html).find("[name=attr]").change();
            jQuery(html).find(".position2").hide();
            break;
        case 4:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#ThesaurusTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            break;
        case 5:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#WordSketchTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            jQuery(html).find(".seek").hide();
            break;
        case 6:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#TermTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            break;
        case 7:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#MeetTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            jQuery(html).find("[name=meet-type1]").change();
            jQuery(html).find("[name=meet-type2]").change();
            break;
        case 8:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#UnionTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            jQuery(html).find("[name=union-type1]").change();
            jQuery(html).find("[name=union-type2]").change();
            break;
        case 9:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#SwapTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            jQuery(html).find("[name=swap-type]").change();
            break;
        case 10:
            html = jQuery('<div/>', {
               'class' : 'container row_container',html: GetTemplate("#CcollTemplate")
            });
            jQuery(html).appendTo(jQuery(element));
            if (!jQuery(html).parent().hasClass("swapOrCcoll-container")) {
                jQuery(html).find(".negation").hide();
            }
            jQuery(html).find(".interval").hide();
            jQuery(html).find(".remove").invisible();
            jQuery(html).find("[name=ccoll-type]").change();
            break;
        default:
    }
}

jQuery(document).on('change', '[name=repetitions]', function() {
    if (jQuery(this).val() == 1) {
        jQuery(this).closest('.table').find('.intervalN').hide();
        jQuery(this).closest('.table').find('.intervalK').hide();
    }
    else if (jQuery(this).val() == 2) {
        jQuery(this).closest('.table').find('.intervalN').hide();
        jQuery(this).closest('.table').find('.intervalK').hide();
    }
    else if (jQuery(this).val() == 3) {
        jQuery(this).closest('.table').find('.intervalN').hide();
        jQuery(this).closest('.table').find('.intervalK').hide();
    }
    else if (jQuery(this).val() == 4) {
        jQuery(this).closest('.table').find('.intervalN').hide();
        jQuery(this).closest('.table').find('.intervalK').hide();
    }
    else if (jQuery(this).val() == 5) {
        jQuery(this).closest('.table').find('.intervalN').show();
        jQuery(this).closest('.table').find('.intervalK').hide();
    }
    else if (jQuery(this).val() == 6) {
        jQuery(this).closest('.table').find('.intervalN').show();
        jQuery(this).closest('.table').find('.intervalK').show();
    }
});

jQuery(document).on('change', '[name=conditionType]', function() {
    if (jQuery(this).val() == 1) {
        jQuery(this).closest('.table').find('.conditionValue').hide();
        jQuery(this).closest('.table').find('.positionNumber2').show();
        jQuery(this).closest('.table').find('.positionAttrib2').show();
        jQuery(this).closest('.table').find('[name=conditionOper]').find(".function").hide();
        jQuery(this).closest('.table').find('[name=conditionOper]').val("1");
    }
    else {
        jQuery(this).closest('.table').find('.conditionValue').show();
        jQuery(this).closest('.table').find('.positionNumber2').hide();
        jQuery(this).closest('.table').find('.positionAttrib2').hide();
        jQuery(this).closest('.table').find('[name=conditionOper]').find(".function").show();
    }
});

jQuery(document).on('change', '[name=struct_attrib]', function() {
    if (jQuery(this).val() == 1) {
        jQuery(this).closest('.row_container').find('.struct_value').hide();
        jQuery(this).closest('.row_container').find('.struct_position').show();
        jQuery(this).closest('.row_container').find('.attrib-oper').hide();
        jQuery(this).closest('.row_container').find('.struct_value').hide();
    }
    else {
        jQuery(this).closest('.row_container').find('.struct_position_range').hide();
        jQuery(this).closest('.row_container').find('[name=struct_position_range]').prop('checked', false);
        jQuery(this).closest('.row_container').find('.struct_position').hide();
        jQuery(this).closest('.row_container').find('.attrib-oper').show();
        jQuery(this).closest('.row_container').find('.struct_value').show();
    }
});


// creating output

function addTooltip(element,tooltip) {
    jQuery(element).children(".tooltip").remove();
    jQuery(element).append(jQuery('<span/>', {
        'class' : 'tooltip',html: tooltip
    }));
}

function removeTooltip(element) {
    jQuery(element).children(".tooltip").remove();
}

function out() {
    if (jQuery(".cql_builder:visible").length>0) {
        assignNumbers();
        loadNumbers();
        var str = "";
        if (jQuery(".cql_builder #condition_container").children().length > 0) {
            str = "(";
        }
        jQuery(".cql_builder #cb_container").children().each(function(element) {
              str = str + rowToText(jQuery(this));
        });
        if (jQuery(".cql_builder #condition_container").children().length > 0) {
            str = str + ") ";
        }
        jQuery(".cql_builder #condition_container").children().each(function(element) {
            str = str + conditionToText(jQuery(this));
        });
        jQuery("input#cql").val(str);
    }
}

function conditionToText(element) {
    var str = "";
    if (jQuery(element).find("[name=conditionType]").val() == 1) {
        str = str + "& ";
        str = str + jQuery(element).find("[name=positionNumber1] :selected").text() + "." + jQuery(element).find("[name=positionAttrib1] :selected").val() + " ";
        str = str + jQuery(element).find("[name=conditionOper] :selected").text() + " ";
        str = str + jQuery(element).find("[name=positionNumber2] :selected").text() + "." + jQuery(element).find("[name=positionAttrib2] :selected").val() + " ";
    }
    else {
        if (jQuery(element).find("[name=conditionValue]").val().match(/^[0-9]\d*$/)) {
            str = str + "& " + jQuery(element).find("[name=conditionType]").val() +"(";
            str = str + jQuery(element).find("[name=positionNumber1] :selected").text() + "." + jQuery(element).find("[name=positionAttrib1] :selected").text() + ") ";
            str = str + jQuery(element).find("[name=conditionOper] :selected").text() + " " + jQuery(element).find("[name=conditionValue]").val() + " ";
            jQuery(element).find("[name=conditionValue]").parent().removeClass("error");
            removeTooltip(jQuery(element).find("[name=conditionValue]").parent());
        }
        else {
            jQuery(element).find("[name=conditionValue]").parent().addClass("error");
            addTooltip(jQuery(element).find("[name=conditionValue]").parent(),jQuery("#conditionValue").text());
        }
    }
    return str;
}

// make sure str does not contain any unescaped characters
function fixSpecChars(str) {
    var out = str;
    var count = 0;
    var q = [];
    var help = true;
    for (i=str.length-1; i>=0; i--) {
        if (help && str[i]==="\\") {
            count++;
        }
        else {
            help = false;
        }
        if (str[i]==="\"") {
            if (i!= 0 && str[i-1]!=="\\") q.push(i);
            else if (i==0) q.push(i);
        }
    }
    for (i = 0; i<q.length; i++) {
        out = out.substr(0, q[i]) + "\\" + out.substr(q[i], out.length);
    }
    if (count%2 != 0) {
        out = out + "\\";
    }
    return out;
}

// returns generated CQL query of one row container
function rowToText(element) {
    var str = "";
    if (jQuery(element).children(".attributeValue").length == 1) {
        if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).find("[name=negation]:checked").length > 0) str = str + "!" ;
        if ((!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) && (jQuery(".cql_builder #condition_container").children().length > 0)) {
            str = str + jQuery(element).find(".number").text() +":";
        }
        if (jQuery(".cql_builder #advanced:checked").length > 0 &&(jQuery(element).find("[name=attr] :selected").val() === jQuery("[name=default_attr] :selected").val()) && (jQuery(element).find("[name=oper] :selected").text() == "=") && !jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
            str = str + "\"";
            if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).find("[name=case]:checked").length > 0) {
                str = str + "(?i)";
            }
            str = str + fixSpecChars(jQuery(element).find("[name=val]").val()) + "\"";
        }
        else {
            if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
                str = str + "[";
            }
            str = str + jQuery(element).find("[name=attr] :selected").val();
            str = str + jQuery(element).find("[name=oper] :selected").text();
            str = str + "\"";
            if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).find("[name=case]:checked").length > 0) {
                str = str + "(?i)";
            }
            str = str + fixSpecChars(jQuery(element).find("[name=val]").val()) + "\"";
            if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
                str = str + "]";
            }
        }
        if (jQuery(".cql_builder #advanced:checked").length > 0 && (!jQuery(element).parent().hasClass("bool-container") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) && jQuery(element).find("[name=repetitions]").val() != 1) {
            if (jQuery(element).find("[name=repetitions]").val() == 2) {
                str = str + "? ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 3) {
                str = str + "* ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 4) {
                str = str + "+ ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 5) {
                str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intn]"));
            }
            else str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intk]"));
        }
        else {
            str = str + " ";
        }
    }
    else if (jQuery(element).children(".anyToken").length == 1) {
        if (jQuery(".cql_builder #condition_container").children().length > 0) {
            str = str + jQuery(element).find(".number").text() +":";
        }
        str = str + "[]";
        if (jQuery(".cql_builder #advanced:checked").length > 0 && (!jQuery(element).parent().hasClass("bool-container") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) && jQuery(element).find("[name=repetitions]").val() != 1) {
            if (jQuery(element).find("[name=repetitions]").val() == 2) {
                str = str + "? ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 3) {
                str = str + "* ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 4) {
                str = str + "+ ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 5) {
                str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intn]"));
            }
            else {
                str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intk]"));
            }
        }
        else {
            str = str + " ";
        }
    }
    else if (jQuery(element).children(".boolean").length == 1) {
        if (!jQuery(element).parent().hasClass("bool-container") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
            if (jQuery(".cql_builder #condition_container").children().length > 0) {
                str = str + jQuery(element).children(".boolean").find(".number").text() +":";
            }
            str = str + "[";
            if (jQuery(element).children(".boolean").find("[name=negation]:checked").length > 0) {
                str = str + "!(";
            }
        }
        else if (jQuery(element).children(".boolean").find("[name=negation]:checked").length > 0) {
            str = str + "!(";
        }
        else {
            str = str + "(";
        }
        var oper;
        if (jQuery(element).hasClass("AND")) {
            oper = "&";
        }
        else {
            oper = "|";
        }
        var isValid = true;
        var last = jQuery(element).children(".rules-list").children().filter(':last');
        jQuery(element).children(".rules-list").children().each(function(element) {
            var bool = rowToText(jQuery(this));
            if (bool!="") {
                str = str + bool;
            }
            else {
                isValid = false;
            }
            if (!jQuery(this).is(last)) {
                str = str + oper + " ";
            }
        });
        if (jQuery(element).children(".boolean").find("[name=negation]:checked").length > 0) {
            str = str + ") ";
        }
        if (!jQuery(element).parent().hasClass("bool-container") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
            str = str + "]";
        }
        else if (jQuery(element).children(".boolean").find("[name=negation]:checked").length == 0) {
            str = str + ") ";
        }
        if (jQuery(".cql_builder #advanced:checked").length > 0 && (!jQuery(element).parent().hasClass("bool-container") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) && jQuery(element).children(".boolean").find("[name=repetitions]").val() != 1) {
            if (jQuery(element).children(".boolean").find("[name=repetitions]").val() == 2) {
                str = str + "? ";
            }
            else if (jQuery(element).children(".boolean").find("[name=repetitions]").val() == 3) {
                str = str + "* ";
            }
            else if (jQuery(element).children(".boolean").find("[name=repetitions]").val() == 4) {
                str = str + "+ ";
            }
            else if (jQuery(element).children(".boolean").find("[name=repetitions]").val() == 5) {
                str = str + intervalFunc(jQuery(element).children(".boolean").find("[name=intn]"),jQuery(element).children(".boolean").find("[name=intn]"));
            }
            else {
                str = str + intervalFunc(jQuery(element).children(".boolean").find("[name=intn]"),jQuery(element).children(".boolean").find("[name=intk]"));
            }
        }
        else {
            str = str + " ";
        }
        if (!isValid) {
            str = "";
        }
    }
    else if (jQuery(element).children(".position").length == 1) {
        if (jQuery(element).find("[name=pos1]").val().match(/^[0-9]\d*$/)) {
            if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
                if (jQuery(".cql_builder #condition_container").children().length > 0) {
                    str = str + jQuery(element).find(".number").text() +":";
                }
                str = str + "[";
            }
            if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).find("[name=negation]:checked").length > 0) {
                str = str + "!";
            }
            str = str + "#" + jQuery(element).find("[name=pos1]").val();
            if (jQuery(element).find("[name=range]:checked").length > 0) {
                if (jQuery(element).find("[name=pos2]").val().match(/^[0-9]\d*$/)) {
                    str = str + "-" + jQuery(element).find("[name=pos2]").val();
                    jQuery(element).find("[name=pos2]").parent().removeClass("error");
                    removeTooltip(jQuery(element).find("[name=pos2]").parent());
                }
                else {
                    jQuery(element).find("[name=pos2]").parent().addClass("error");
                    addTooltip(jQuery(element).find("[name=pos2]").parent(),jQuery("#position").text());
                }
            }
            if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
                str = str + "]";
            }
            str = str + " ";
            jQuery(element).find("[name=pos1]").parent().removeClass("error");
            removeTooltip(jQuery(element).find("[name=pos1]").parent());
        }
        else {
            if (!jQuery(element).find("[name=pos1]").val().match(/^[0-9]\d*$/)) {
                jQuery(element).find("[name=pos1]").parent().addClass("error");
                addTooltip(jQuery(element).find("[name=pos1]").parent(),jQuery("#position").text());
            }
            if (!jQuery(element).find("[name=pos2]").val().match(/^[0-9]\d*$/)) {
                jQuery(element).find("[name=pos2]").parent().addClass("error");
                addTooltip(jQuery(element).find("[name=pos2]").parent(),jQuery("#position").text());
            }
            else {
                jQuery(element).find("[name=pos2]").parent().removeClass("error");
                removeTooltip(jQuery(element).find("[name=pos2]").parent());
            }
        }
    }
    else if (jQuery(element).children(".thesaurus").length == 1) {
        if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).find("[name=negation]:checked").length > 0) {
            str = str + "!" ;
        }
        if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
            if (jQuery(".cql_builder #condition_container").children().length > 0) {
                str = str + jQuery(element).find(".number").text() +":";
            }
            str = str + "[";
        }
        str = str + jQuery(element).find("[name=thesaurAttr] :selected").val();
        str = str + "~";
        if (jQuery(element).find("[name=number]").val().match(/^[0-9]*$/)) {
            str = str + jQuery(element).find("[name=number]").val();
            jQuery(element).find("[name=number]").parent().removeClass("error");
            removeTooltip(jQuery(element).find("[name=number]").parent());
        }
        else {
            jQuery(element).find("[name=number]").parent().addClass("error");
            addTooltip(jQuery(element).find("[name=number]").parent(),jQuery("#number").text());
        }
        str = str + "\"" +  fixSpecChars(jQuery(element).find("[name=val]").val()) + "\"";
        if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
            str = str + "]";
        }
        if (jQuery(".cql_builder #advanced:checked").length > 0 && !jQuery(element).parent().hasClass("bool-container") && (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) && jQuery(element).find("[name=repetitions]").val() != 1) {
            // TODO: fix this inefficiency!
            if (jQuery(element).find("[name=repetitions]").val() == 2) {
                str = str + "? ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 3) {
                str = str + "* ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 4) {
                str = str + "+ ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 5) {
                str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intn]"));
            }
            else {
                str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intk]"));
            }
        }
        else {
            str = str + " ";
        }
    }
    else if (jQuery(element).children(".wordSketch").length == 1) {
        if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).find("[name=negation]:checked").length > 0) {
            str = str + "!" ;
        }
        if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
            if (jQuery(".cql_builder #condition_container").children().length > 0) {
                str = str + jQuery(element).find(".number").text() +":";
            }
            str = str + "[";
        }
        str = str + "ws(";
        if (jQuery(element).find("[name=ws_type]").val() == 1) {
            str = str + "\"" + fixSpecChars(jQuery(element).find("[name=head]").val()) + "\",";
            str = str + "\"" + jQuery(element).find("[name=rel] :selected").text() + "\",";
            str = str + "\"" + fixSpecChars(jQuery(element).find("[name=coll]").val()) + "\"";
        }
        else if (jQuery(element).find("[name=seek]").val().match(/^[0-9]\d*$/)) {
            str = str + jQuery(element).find("[name=level] :selected").text() + ",";
            str = str + jQuery(element).find("[name=seek]").val();
            jQuery(element).find("[name=seek]").parent().removeClass("error");
            removeTooltip(jQuery(element).find("[name=seek]").parent());
        }
        else {
            str = str + jQuery(element).find("[name=level] :selected").text() + ",";
            str = str + "0";
            jQuery(element).find("[name=seek]").parent().addClass("error");
            addTooltip(jQuery(element).find("[name=seek]").parent(),jQuery("#seek").text());
        }
        str = str + ")";
        if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
            str = str + "]";
        }
        if (jQuery(".cql_builder #advanced:checked").length > 0 && (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) && jQuery(element).find("[name=repetitions]").val() != 1) {
            // TODO: rewrite!
            if (jQuery(element).find("[name=repetitions]").val() == 2) {
                str = str + "? ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 3) {
                str = str + "* ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 4) {
                str = str + "+ ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 5) {
                str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intn]"));
            }
            else {
                str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intk]"));
            }
        }
        else {
            str = str + " ";
        }
    }
    else if (jQuery(element).children(".structure").length == 1) {
        if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).children(".structure").find("[name=negation]:checked").length > 0) {
            str = str + "!";
        }
        str = str + "<";
        if (jQuery(element).find("[name=struct_pos]").val() == 2) {
            str = str + "/";
        }
        if (jQuery(element).children(".document").length > 0) {
            str = str + jQuery(element).find("[name=struct_name]").children("[value$=doc]").val();
        }
        else if (jQuery(element).children(".sentence").length > 0) {
            str = str + "s";
        }
        else if (jQuery(element).children(".paragraph").length > 0) {
            str = str + "p";
        }
        else {
            str = str + jQuery(element).find("[name=struct_name] :selected").val();
        }
        if (jQuery(element).children('.attriblist').children().length > 0) {
            str = str + " ";
            jQuery(element).children(".attriblist").children().each(function(element) {
                str = str + structAttribToText(jQuery(this)) + " ";
            });
        }
        if (jQuery(element).find("[name=struct_pos]").val() == 3) {
            str = str + "/";
        }
        str = str +"> ";
    }
    else if (jQuery(element).children(".within").length == 1) {
        if (checkWithinAndContaining(jQuery(element))) {
            if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).find("[name=negation]:checked").length > 0) {
                str = str + "!";
            }
            str = str + "within ";
            if (jQuery(element).find("[name=within_parallel]:checked").length > 0) {
                str = str + jQuery(element).find("[name=parallel]").find(":selected").val() + ": ";
            }
        }
    }
    else if (jQuery(element).children(".containing").length == 1) {
        if (checkWithinAndContaining(jQuery(element))) {
            if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).find("[name=negation]:checked").length > 0) {
                str = str + "!";
            }
            str = str + "containing ";
        }
    }
    else if (jQuery(element).children(".meet").length == 1) {
        if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).children(".dynam").children(".table").find("[name=negation]:checked").length > 0) {
            str = str + "!";
        }
        var meet1 = rowToText(jQuery(element).children().children("[data-name=meet1]").children());
        var meet2 = rowToText(jQuery(element).children().children("[data-name=meet2]").children());
        if (jQuery(element).children().children(".table").find("[name=context-neg]").val().match(/^-?[0-9]\d*$/) && jQuery(element).children().children(".table").find("[name=context-pos]").val().match(/^-?[0-9]\d*$/)) {
            str = str + "(meet ";
            if (meet1!=="" && meet2!=="") {
                str = str + meet1 + meet2;
                str = str + jQuery(element).children(".dynam").find("[name=context-neg]").val() + " ";
                str = str + jQuery(element).children(".dynam").find("[name=context-pos]").val() + ") ";
            }
            else {
                str = "";
            }
            jQuery(element).children().children(".table").find("[name=context-neg]").parent().removeClass("error");
            removeTooltip(jQuery(element).children().children(".table").find("[name=context-neg]").parent());
            jQuery(element).children().children(".table").find("[name=context-pos]").parent().removeClass("error");
            removeTooltip(jQuery(element).find("[name=context-pos]").parent());
        }
        else {
            if (!jQuery(element).children().children(".table").find("[name=context-neg]").val().match(/^-?[0-9]\d*$/)) {
                jQuery(element).children().children(".table").find("[name=context-neg]").parent().addClass("error");
                addTooltip(jQuery(element).children().children(".table").find("[name=context-neg]").parent(),jQuery("#context-neg").text());
            }
            else {
                jQuery(element).children().children(".table").find("[name=context-neg]").parent().removeClass("error");
                removeTooltip(jQuery(element).children().children(".table").find("[name=context-neg]").parent());
            }
            if (!jQuery(element).children().children(".table").find("[name=context-pos]").val().match(/^-?[0-9]\d*$/)) {
                jQuery(element).children().children(".table").find("[name=context-pos]").parent().addClass("error");
                addTooltip(jQuery(element).children().children(".table").find("[name=context-pos]").parent(),jQuery("#context-pos").text());
            }
            else {
                jQuery(element).children().children(".table").find("[name=context-pos]").parent().removeClass("error");
                removeTooltip(jQuery(element).children().children(".table").find("[name=context-pos]").parent());
            }
        }
    }
    else if (jQuery(element).children(".union").length == 1) {
        if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).children(".dynam").children(".table").find("[name=negation]:checked").length > 0) {
            str = str + "!";
        }
        str = str + "(union ";
        var union1 = rowToText(jQuery(element).children().children("[data-name=union1]").children());
        var union2 = rowToText(jQuery(element).children().children("[data-name=union2]").children());
        if (union1!=="" && union2!=="") {
            str = str + union1 + union2;
            str = str + ") ";
        }
        else {
            str = "";
        }
    }
    else if (jQuery(element).children(".swap").length == 1) {
        var swap = rowToText(jQuery(element).find(".rules-list").children().filter(":first"));
        if (jQuery(element).children().children(".table").find("[name=swapnum]").val().match(/^[0-9]\d*$/)) {
            if (jQuery(".cql_builder").find("#advanced:checked").length > 0 && jQuery(element).children().children(".table").find("[name=negation]:checked").length > 0) {
                str = str + "!" ;
            }
            if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
                if (jQuery(".cql_builder").find("#condition_container").children().length > 0) {
                    str = str + jQuery(element).find(".number").text() +":";
                }
                str = str + "[";
            }
            str = str + "swap (";
            str = str + jQuery(element).find("[name=swapnum]").val() + ", ";
            if (swap!=="") {
                str = str + swap + ")";
                if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
                    str = str + "]";
                }
                str = str +" ";
            }
            else {
                str = "";
            }
            jQuery(element).children().children(".table").find("[name=swapnum]").parent().removeClass("error");
            removeTooltip(jQuery(element).children().children(".table").find("[name=swapnum]").parent());
        }
        else {
            jQuery(element).children().children(".table").find("[name=swapnum]").parent().addClass("error");
            addTooltip(jQuery(element).children().children(".table").find("[name=swapnum]").parent(),jQuery("#swapnum").text());
        }
    }
    else if (jQuery(element).children(".ccoll").length == 1) {
        var ccoll = rowToText(jQuery(element).find(".rules-list").children().filter(":first"));
        if (jQuery(element).children().children(".table").find("[name=ccolnum1]").val().match(/^[0-9]\d*$/) && jQuery(element).children().children(".table").find("[name=ccolnum2]").val().match(/^[0-9]\d*$/)) {
            if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).children().children(".table").find("[name=negation]:checked").length > 0) {
                str = str + "!" ;
            }
            if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
                if (jQuery(".cql_builder #condition_container").children().length > 0) {
                    str = str + jQuery(element).find(".number").text() +":";
                }
                str = str + "[";
            }
            str = str + "ccoll (";
            str = str + jQuery(element).find("[name=ccolnum1]").val() + ", ";
            str = str + jQuery(element).find("[name=ccolnum2]").val() + ", ";
            if (ccoll!=="") {
                str = str + ccoll + ")";
                if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
                    str = str + "]";
                }
                str = str +" ";
            }
            else {
                str = "";
            }
            jQuery(element).children().children(".table").find("[name=ccolnum1]").parent().removeClass("error");
            removeTooltip(jQuery(element).children().children(".table").find("[name=ccolnum1]").parent());
            jQuery(element).children().children(".table").find("[name=ccolnum2]").parent().removeClass("error");
            removeTooltip(jQuery(element).children().children(".table").find("[name=ccolnum2]").parent());
        }
        else {
            if (!jQuery(element).children().children(".table").find("[name=ccolnum1]").val().match(/^[0-9]\d*$/)) {
                jQuery(element).children().children(".table").find("[name=ccolnum1]").parent().addClass("error");
                addTooltip(jQuery(element).children().children(".table").find("[name=ccolnum1]").parent(),jQuery("#ccolnum").text());
            }
            else {
                jQuery(element).children().children(".table").find("[name=ccolnum1]").parent().removeClass("error");
                removeTooltip(jQuery(element).children().children(".table").find("[name=ccolnum1]").parent());
            }
            if (!jQuery(element).children().children(".table").find("[name=ccolnum2]").val().match(/^[0-9]\d*$/)) {
                jQuery(element).children().children(".table").find("[name=ccolnum2]").parent().addClass("error");
                addTooltip(jQuery(element).children().children(".table").find("[name=ccolnum2]").parent(),jQuery("#ccolnum").text());
            }
            else {
                jQuery(element).children().children(".table").find("[name=ccolnum2]").parent().removeClass("error");
                removeTooltip(jQuery(element).children().children(".table").find("[name=ccolnum2]").parent());
            }
        }
    }
    else if (jQuery(element).children(".term").length == 1) {
        if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).find("[name=negation]:checked").length > 0) {
            str = str + "!" ;
        }
        if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
            if (jQuery(".cql_builder #condition_container").children().length > 0) {
                str = str + jQuery(element).find(".number").text() +":";
            }
            str = str + "[";
        }
        str = str + "term(";
        str = str + "\"" + fixSpecChars(jQuery(element).find("[name=head]").val()) + "\",";
        str = str + "\"" + jQuery(element).find("[name=term_rel]").find(":selected").val() + "\",";
        str = str + "\"" + fixSpecChars(jQuery(element).find("[name=coll]").val()) + "\"";
        str = str + ")";
        if (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) {
            str = str + "]";
        }
        if (jQuery(".cql_builder #advanced:checked").length > 0 && (!jQuery(element).hasClass("bool") && !jQuery(element).parent().hasClass("swapOrCcoll-container")) && jQuery(element).find("[name=repetitions]").val() != 1) {
            // TODO: rewrite!
            if (jQuery(element).find("[name=repetitions]").val() == 2) {
                str = str + "? ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 3) {
                str = str + "* ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 4) {
                str = str + "+ ";
            }
            else if (jQuery(element).find("[name=repetitions]").val() == 5) {
                str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intn]"));
            }
            else {
                str = str + intervalFunc(jQuery(element).find("[name=intn]"),jQuery(element).find("[name=intk]"));
            }
        }
        else {
            str = str + " ";
        }
    }
    return str;
}

function structAttribToText(element) {
    var str = "";
    if (jQuery(element).children(".boolean").length > 0) {
        if (jQuery(".cql_builder #advanced:checked").length > 0 && jQuery(element).children(".dynam").find("[name=negation]:checked").length > 0) {
            str = str + "!";
        }
        str = str + "(";
        var oper;
        if (jQuery(element).hasClass(".And")) {
            oper = "&";
        }
        else {
            oper = "|";
        }
        var isValid = true;
        var last = jQuery(element).children(".attrib_bool").children().filter(':last');
        jQuery(element).children(".attrib_bool").children().each(function(element) {
            bool = structAttribToText(jQuery(this));
            if (bool!="") {
                str = str + bool;
            }
            else {
                isValid = false;
            }
            if (!jQuery(this).is(last)) {
                str = str + oper + " ";
            }
        });
        str = str + ") ";
        if (!isValid) {
            str = "";
        }
    }
    else if (jQuery(element).find("[name=struct_attrib]").val() == 1) {
        if (jQuery(element).find("[name=struct_value1]").val().match(/^[0-9]\d*$/)) {
            if (jQuery(element).children(".dynam").find("[name=negation]:checked").length > 0) {
                str = str + "!";
            }
            str = str + "#" + jQuery(element).find("[name=struct_value1]").val();
            if (jQuery(element).find("[name=struct_position_range]:checked").length > 0) {
                if (jQuery(element).find("[name=struct_value2]").val().match(/^[0-9]\d*$/)) {
                    str = str + "-" + jQuery(element).find("[name=struct_value2]").val();
                    jQuery(element).find("[name=struct_value2]").parent().removeClass("error");
                    removeTooltip(jQuery(element).find("[name=struct_value2]").parent());
                }
                else {
                    jQuery(element).find("[name=struct_value2]").parent().addClass("error");
                    addTooltip(jQuery(element).find("[name=struct_value2]").parent(),jQuery("#struct_value").text());
                }
            }
            str = str + " ";
            jQuery(element).find("[name=struct_value1]").parent().removeClass("error");
            removeTooltip(jQuery(element).find("[name=struct_value1]").parent());
        }
        else {
            if (!jQuery(element).find("[name=struct_value1]").val().match(/^[0-9]\d*$/)) {
                jQuery(element).find("[name=struct_value1]").parent().addClass("error");
                addTooltip(jQuery(element).find("[name=struct_value1]").parent(),jQuery("#position").text());
            }
            if (!jQuery(element).find("[name=struct_value2]").val().match(/^[0-9]\d*$/)) {
                jQuery(element).find("[name=struct_value2]").parent().addClass("error");
                addTooltip(jQuery(element).find("[name=struct_value2]").parent(),jQuery("#position").text());
            }
            else {
                jQuery(element).find("[name=struct_value2]").parent().removeClass("error");
                removeTooltip(jQuery(element).find("[name=struct_value2]").parent());
            }
        }
    }
    else {
        if (jQuery(element).children(".dynam").find("[name=negation]:checked").length > 0) {
            str = str + "!";
        }
        str = str + jQuery(element).find("[name=struct_attrib] :selected").val();
        str = str + jQuery(element).find("[name=attrib-oper] :selected").text();
        str = str + "\"";
        str = str + fixSpecChars(jQuery(element).find("[name=struct_value]").val()) + "\" ";
    }
    return str;
}

// check if the numbers in interval are valid
function intervalFunc(a,b) {
    var val = " ";
    if (jQuery(a).val().match(/^[0-9]\d*$/)) {
        jQuery(a).parent().removeClass("error");
        removeTooltip(jQuery(a).parent());
        if (jQuery(b).val().match(/^[0-9]\d*$/)) {
            if (parseInt(jQuery(a).val())<parseInt(jQuery(b).val())) {
                val = "{"+ jQuery(a).val() + "," + jQuery(b).val() +"} ";
                jQuery(b).parent().removeClass("error");
                removeTooltip(jQuery(b).parent());
            }
            else if (parseInt(jQuery(a).val()) == parseInt(jQuery(b).val())) {
                val = "{"+ jQuery(a).val() + "} ";
                jQuery(b).parent().removeClass("error");
                removeTooltip(jQuery(b).parent());
            }
            else {
                jQuery(b).parent().addClass("error");
                addTooltip(jQuery(b).parent(),jQuery("#k").text());
                val =  " ";
            }
        }
        else {
            jQuery(b).parent().addClass("error");
            addTooltip(jQuery(b).parent(),jQuery("#k").text());
            val = " ";
        }
    }
    else {
        jQuery(a).parent().addClass("error");
        addTooltip(jQuery(a).parent(),jQuery("#n").text());
        if (jQuery(b).val().match(/^[0-9]\d*$/)) {
            jQuery(b).parent().removeClass("error");
            removeTooltip(jQuery(b).parent());
        }
        else {
            jQuery(b).parent().addClass("error");
            addTooltip(jQuery(b).parent(),jQuery("#k").text());
            val = " ";
        }
    }
    return val;
}

// assigns numbers to queries for use with conditions
function assignNumbers() {
    var help = jQuery(".cql_builder #cb_container .row_container").filter(":not(.bool)");
    var number = 1;
    jQuery(".cql_builder #cb_container .row_container").each(function(element) {
        if ((!jQuery(this).parent().hasClass("bool-container") && !jQuery(this).parent().hasClass("swapOrCcoll-container") && (jQuery(this).closest(".attriblist").length==0))
                && ((jQuery(this).children(".structure").length == 0) && (jQuery(this).children(".within").length == 0) && (jQuery(this).children(".containing").length == 0)
                && (jQuery(this).children(".meet").length == 0)    && (jQuery(this).children(".union").length == 0))) {
            jQuery(this).find(".number").html(number);
            number = number + 1;
        }
        else {
            jQuery(this).find(".number").html("");
        }
    });
    row_number = number-1;
    if (row_number == 0) {
        jQuery(".cql_builder .global_conditions_header").hide();
        jQuery(".cql_builder #condition_container").empty();
    }
    else {
        jQuery(".cql_builder .global_conditions_header").show();
    }
}

// adds numbers to select boxes in conditions
function loadNumbers() {
    if (jQuery(".cql_builder #condition_container").children().length > 0) {
        var help = jQuery(".cql_builder .template .posNumber").first().children().length;
        for (var i = help; i > row_number; i--) {
            jQuery(".cql_builder .posNumber").each(function(element) {
                jQuery(this).children().last().remove();
            });
        }
        for (var i = help+1; i <= row_number; i++) {
            jQuery(".cql_builder .posNumber").append("<option>" + i + "</option>");
        }
    }
}

function checkWithinAndContaining(item) {
    var result = false;
    var element;
    if (jQuery(item).children(".within").length > 0) {
        element = jQuery(item);
        rowToText(jQuery(element).next());
        if (jQuery(".cql_builder #cb_container").children().filter(":first").is(jQuery(element))) { //within is first
            jQuery(element).addClass("error");
            addTooltip(jQuery(element),jQuery("#within_both").text());
        }
        else if (jQuery(".cql_builder #cb_container").children().filter(":last").is(jQuery(element))) { //within is last
            jQuery(element).addClass("error");
            addTooltip(jQuery(element),jQuery("#within_both").text() );
        }
        else if (jQuery(element).prev().find(".containing").length > 0 || jQuery(element).next().find(".containing").length > 0) { //within is imidietly precceded or followed by containng
            jQuery(element).addClass("error");
            addTooltip(jQuery(element),jQuery("#within_containing").text() );
        }
        else if (jQuery(element).prev().find(".within").length > 0  || jQuery(element).next().find(".within").length > 0 ) { //within is preceded or oflowed by other within
            jQuery(element).addClass("error");
            addTooltip(jQuery(element),jQuery("#within_within").text() );
        }
        else if (jQuery(element).next().find(".structure [name=struct_pos]").val()==1) { //within is followed by begining of structure
            jQuery(element).addClass("error");
            addTooltip(jQuery(element), jQuery("#within_structure").text() );
        }
        else if (jQuery(element).prev().find(".error:not(.interval, .thes-num, .position2)").length>0
                || jQuery(element).next().find(".error:not(.interval, .thes-num, .position2)").length>0) { //within is preceded or followed by element with error
            jQuery(element).addClass("error");
            addTooltip(jQuery(element), jQuery("#within_next_to_error").text() );
        }
        else {
            jQuery(element).removeClass("error");
            removeTooltip(jQuery(element));
            result = true;
        }
    }
    else if (jQuery(item).children(".containing").length > 0) {
        element = jQuery(item).children(".containing").parent();
        if (jQuery(".cql_builder #cb_container").children().filter(":first").is(jQuery(element))) { //containing is first
            jQuery(element).addClass("error");
            addTooltip(jQuery(element), jQuery("#containing_both").text() );
        }
        else if (jQuery(".cql_builder #cb_container").children().filter(":last").is(jQuery(element))) { //cotaining is last
            jQuery(element).addClass("error");
            addTooltip(jQuery(element), jQuery("#containing_both").text() );
        }
        else if (jQuery(element).prev().find(".within").length > 0 || jQuery(element).next().find(".within").length > 0) { //is preced or followed by within
            jQuery(element).addClass("error");
            addTooltip(jQuery(element), jQuery("#containing_within").text() );
        }
        else if (jQuery(element).prev().find(".containing").length > 0  || jQuery(element).next().find(".containing").length > 0 ) { //preceded or folllowed by other containg
            jQuery(element).addClass("error");
            addTooltip(jQuery(element), jQuery("#containing_containing").text() );
        }
        else if (jQuery(element).prev().find(".error:not(.interval, .thes-num, .position2)").length>0
                || jQuery(element).next().find(".error:not(.interval, .thes-num, .position2)").length>0) { //preceded or followed by element with error
            jQuery(element).addClass("error");
            addTooltip(jQuery(element), jQuery("#containing_next_to_error").text() );
        }
        else {
            jQuery(element).removeClass("error");
            removeTooltip(jQuery(element));
            result = true;
        }
    }
    return result;
}
